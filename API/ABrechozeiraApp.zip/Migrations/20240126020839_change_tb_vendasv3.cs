﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ABrechozeiraApp.Migrations
{
    /// <inheritdoc />
    public partial class change_tb_vendasv3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Venda_Origem_OrigemID",
                table: "Venda");

            migrationBuilder.AlterColumn<int>(
                name: "OrigemID",
                table: "Venda",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddForeignKey(
                name: "FK_Venda_Origem_OrigemID",
                table: "Venda",
                column: "OrigemID",
                principalTable: "Origem",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Venda_Origem_OrigemID",
                table: "Venda");

            migrationBuilder.AlterColumn<int>(
                name: "OrigemID",
                table: "Venda",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Venda_Origem_OrigemID",
                table: "Venda",
                column: "OrigemID",
                principalTable: "Origem",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
