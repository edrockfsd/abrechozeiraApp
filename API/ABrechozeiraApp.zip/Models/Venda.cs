﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ABrechozeiraApp.Models;

public partial class Venda
{
    public int Id { get; set; }

    public int Quantidade { get; set; }

    public decimal PrecoVenda { get; set; }

    public decimal? Desconto { get; set; }
    [ForeignKey("Pessoa")]
    public int ClienteId { get; set; }

    public Pessoa? Cliente { get; set; }

    [ForeignKey("Produto")]
    public int ProdutoId { get; set; }

    public Produto? Produto { get; set; }
    
    public int? OrigemID { get; set; }

    public Origem? Origem { get; set; }

    public int? CodigoLive { get; set; }

    public DateTime? DataOperacao { get; set; }
}
