-- MySQL dump 10.13  Distrib 5.6.40, for Linux (x86_64)
--
-- Host: mysql26-farm1.kinghost.net    Database: abrechozeira01
-- ------------------------------------------------------
-- Server version	5.5.5-10.2.36-MariaDB-log
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Arremate`
--

DROP TABLE IF EXISTS `Arremate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Arremate` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `LiveId` int(11) NOT NULL DEFAULT 0,
  `ProdutoId` int(11) DEFAULT NULL,
  `Arrematante` varchar(50) NOT NULL,
  `ValorArremate` decimal(65,30) DEFAULT NULL,
  `Observacoes` longtext DEFAULT NULL,
  `DataArremate` datetime(6) NOT NULL,
  `DataAlteracao` datetime(6) NOT NULL,
  `CodigoLive` int(11) DEFAULT NULL,
  `DescricaoManual` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_Arremate_ProdutoId` (`ProdutoId`),
  KEY `IX_Arremate_LiveId` (`LiveId`),
  CONSTRAINT `FK_Arremate_Live_LiveId` FOREIGN KEY (`LiveId`) REFERENCES `Live` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_Arremate_Produto_ProdutoId` FOREIGN KEY (`ProdutoId`) REFERENCES `Produto` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Arremate`
--

LOCK TABLES `Arremate` WRITE;
/*!40000 ALTER TABLE `Arremate` DISABLE KEYS */;
/*!40000 ALTER TABLE `Arremate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Caixa`
--

DROP TABLE IF EXISTS `Caixa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Caixa` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `UsuarioId` int(11) NOT NULL,
  `DataAbertura` datetime(6) NOT NULL,
  `SaldoInicial` decimal(65,30) NOT NULL,
  `DataFechamento` datetime(6) DEFAULT NULL,
  `SaldoFechamento` decimal(65,30) DEFAULT NULL,
  `Observacao` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Caixa`
--

LOCK TABLES `Caixa` WRITE;
/*!40000 ALTER TABLE `Caixa` DISABLE KEYS */;
/*!40000 ALTER TABLE `Caixa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CaixaMovimento`
--

DROP TABLE IF EXISTS `CaixaMovimento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CaixaMovimento` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CaixaId` int(11) NOT NULL,
  `Tipo` longtext NOT NULL,
  `Valor` decimal(65,30) NOT NULL,
  `ReferenciaId` int(11) DEFAULT NULL,
  `Observacao` longtext DEFAULT NULL,
  `DataRegistro` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_CaixaMovimento_CaixaId` (`CaixaId`),
  CONSTRAINT `FK_CaixaMovimento_Caixa_CaixaId` FOREIGN KEY (`CaixaId`) REFERENCES `Caixa` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CaixaMovimento`
--

LOCK TABLES `CaixaMovimento` WRITE;
/*!40000 ALTER TABLE `CaixaMovimento` DISABLE KEYS */;
/*!40000 ALTER TABLE `CaixaMovimento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ComentarioLive`
--

DROP TABLE IF EXISTS `ComentarioLive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ComentarioLive` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(200) NOT NULL,
  `CommentText` longtext NOT NULL,
  `CommentTimestamp` datetime(6) NOT NULL,
  `CreatedAt` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `LiveSessionId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ComentarioLive`
--

LOCK TABLES `ComentarioLive` WRITE;
/*!40000 ALTER TABLE `ComentarioLive` DISABLE KEYS */;
INSERT INTO `ComentarioLive` VALUES (32,'lukbrax','Vai trabalhar','2026-05-19 13:51:44.917272','2026-05-19 13:51:44.917343',18340690102174016),(33,'setterbrazil','?','2026-05-19 13:51:44.924345','2026-05-19 13:51:44.924347',18340690102174016),(34,'r0cha_pr','065','2026-05-19 13:56:11.952821','2026-05-19 13:56:11.952824',18340690102174016),(35,'r0cha_pr','...','2026-05-19 13:56:46.271586','2026-05-19 13:56:46.271588',18340690102174016),(36,'r0cha_pr','olá','2026-05-19 14:02:06.714875','2026-05-19 14:02:06.714877',18340690102174016),(37,'r0cha_pr','135','2026-05-19 14:02:18.551766','2026-05-19 14:02:18.551768',18340690102174016),(38,'r0cha_pr','dddd','2026-05-19 14:05:06.845195','2026-05-19 14:05:06.845198',18340690102174016),(39,'r0cha_pr','teste','2026-05-19 14:08:40.486096','2026-05-19 14:08:40.486099',18340690102174016),(40,'r0cha_pr','025','2026-05-19 14:09:46.728320','2026-05-19 14:09:46.728322',18340690102174016),(41,'setterbrazil','Teste','2026-05-19 14:10:27.431995','2026-05-19 14:10:27.431997',18340690102174016),(42,'r0cha_pr','olá','2026-05-19 14:22:19.579349','2026-05-19 14:22:19.579351',18340690102174016),(43,'r0cha_pr','131','2026-05-19 14:22:50.213372','2026-05-19 14:22:50.213375',18340690102174016),(44,'r0cha_pr','mais uma msg','2026-05-19 14:27:47.323770','2026-05-19 14:27:47.323772',18340690102174016),(45,'r0cha_pr','...','2026-05-19 14:28:12.227527','2026-05-19 14:28:12.227530',18340690102174016),(46,'r0cha_pr','131','2026-05-19 14:28:55.099967','2026-05-19 14:28:55.099971',18340690102174016),(47,'r0cha_pr','teste de mensagem','2026-05-19 14:29:23.155535','2026-05-19 14:29:23.155538',18340690102174016),(48,'r0cha_pr','olá','2026-05-19 14:32:40.586455','2026-05-19 14:32:40.586459',18340690102174016),(49,'r0cha_pr','teste chrome','2026-05-19 14:34:40.396618','2026-05-19 14:34:40.396619',18340690102174016),(50,'r0cha_pr','bora lá','2026-05-19 14:35:12.667980','2026-05-19 14:35:12.667981',18340690102174016),(51,'r0cha_pr','003','2026-05-19 14:36:42.722299','2026-05-19 14:36:42.722300',18340690102174016),(52,'r0cha_pr','bla bla bla','2026-05-19 14:39:03.243178','2026-05-19 14:39:03.243179',18340690102174016),(53,'r0cha_pr','008','2026-05-19 14:39:15.407657','2026-05-19 14:39:15.407658',18340690102174016),(54,'r0cha_pr','Oi','2026-05-19 14:42:44.179481','2026-05-19 14:42:44.179482',18340690102174016),(55,'inn0c0n','008','2026-05-19 14:47:24.175621','2026-05-19 14:47:24.175622',18340690102174016),(56,'setterbrazil','Oi','2026-05-19 14:50:08.057890','2026-05-19 14:50:08.057892',18068350871694601),(57,'r0cha_pr','156','2026-05-19 15:05:35.957721','2026-05-19 15:05:35.957722',18340690102174016),(58,'inn0c0n','021','2026-05-19 15:23:36.470444','2026-05-19 15:23:36.470444',18081032246531003),(59,'r0cha_pr','olá','2026-05-19 15:23:38.307255','2026-05-19 15:23:38.307256',18081032246531003),(60,'r0cha_pr','021','2026-05-19 15:24:19.020039','2026-05-19 15:24:19.020040',18081032246531003),(61,'0peregrin0','opa','2026-05-19 15:57:27.720284','2026-05-19 15:57:27.720285',17938490892229686),(62,'inn0c0n','Oi','2026-05-19 15:58:42.428138','2026-05-19 15:58:42.428139',17938490892229686),(63,'r0cha_pr','oi','2026-05-19 15:58:53.966198','2026-05-19 15:58:53.966200',17938490892229686),(64,'nayzinho.0202','Queria estar ai?','2026-05-28 22:59:17.007160','2026-05-28 22:59:17.007183',17969118570109855),(65,'maricosteds','Esse central camisa 11 joga muito','2026-05-28 22:59:18.387697','2026-05-28 22:59:18.387700',17969118570109855),(66,'nayzinho.0202','Tá quanto o jogo?','2026-05-28 23:03:46.829419','2026-05-28 23:03:46.829424',17969118570109855),(67,'setterbrazil','Final ld 5 x 1 Snakes','2026-05-28 23:10:06.681351','2026-05-28 23:10:06.681354',17969118570109855),(68,'maricosteds','??','2026-05-28 23:10:17.888796','2026-05-28 23:10:17.888800',17969118570109855),(69,'g.chinski','Como faz pra treinar ai????','2026-06-13 16:24:02.318424','2026-06-13 16:24:02.318493',18148913704507636),(70,'aninhaaa_betrz','Oii é d donde?','2026-06-13 18:02:27.595601','2026-06-13 18:02:27.595604',18148913704507636),(71,'felliipeh_souza','Chamar que e bom nada ??','2026-06-13 18:11:32.967448','2026-06-13 18:11:32.967450',18148913704507636),(72,'felliipeh_souza','Cic','2026-06-13 18:14:55.055678','2026-06-13 18:14:55.055681',18148913704507636),(73,'setterbrazil','Só chegar pessoal, rua colomba Merlin 140 Ld vôlei entrem em contato','2026-06-13 18:20:02.159943','2026-06-13 18:20:02.159945',18148913704507636);
/*!40000 ALTER TABLE `ComentarioLive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CondicaoPagamento`
--

DROP TABLE IF EXISTS `CondicaoPagamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CondicaoPagamento` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Descricao` longtext NOT NULL,
  `DataAlteracao` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CondicaoPagamento`
--

LOCK TABLES `CondicaoPagamento` WRITE;
/*!40000 ALTER TABLE `CondicaoPagamento` DISABLE KEYS */;
INSERT INTO `CondicaoPagamento` VALUES (1,'A vista','2025-04-29 00:00:00.000000'),(2,'2x','2025-04-20 19:39:33.000000'),(3,'3x','2025-04-29 19:39:56.000000');
/*!40000 ALTER TABLE `CondicaoPagamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EmpresaFiscal`
--

DROP TABLE IF EXISTS `EmpresaFiscal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EmpresaFiscal` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CNPJ` varchar(14) NOT NULL,
  `InscricaoEstadual` varchar(15) NOT NULL,
  `RazaoSocial` varchar(100) NOT NULL,
  `NomeFantasia` varchar(100) DEFAULT NULL,
  `Logradouro` varchar(100) DEFAULT NULL,
  `Numero` varchar(10) DEFAULT NULL,
  `Complemento` varchar(60) DEFAULT NULL,
  `Bairro` varchar(60) DEFAULT NULL,
  `CodigoMunicipio` varchar(7) DEFAULT NULL,
  `Municipio` varchar(60) DEFAULT NULL,
  `UF` varchar(2) NOT NULL,
  `CEP` varchar(8) DEFAULT NULL,
  `Telefone` varchar(14) DEFAULT NULL,
  `Ambiente` int(11) NOT NULL,
  `CRT` int(11) NOT NULL,
  `Serie` int(11) NOT NULL,
  `ProximoNumero` int(11) NOT NULL,
  `TipoEmissao` int(11) NOT NULL,
  `CSC` varchar(36) DEFAULT NULL,
  `CSCId` varchar(6) DEFAULT NULL,
  `CertificadoPath` varchar(500) DEFAULT NULL,
  `CertificadoSenha` varchar(100) DEFAULT NULL,
  `CertificadoValidade` datetime(6) DEFAULT NULL,
  `Ativo` tinyint(1) NOT NULL,
  `DataCriacao` datetime(6) NOT NULL,
  `DataAlteracao` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EmpresaFiscal`
--

LOCK TABLES `EmpresaFiscal` WRITE;
/*!40000 ALTER TABLE `EmpresaFiscal` DISABLE KEYS */;
/*!40000 ALTER TABLE `EmpresaFiscal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Endereco`
--

DROP TABLE IF EXISTS `Endereco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Endereco` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PessoaID` int(11) NOT NULL,
  `CEP` varchar(8) DEFAULT NULL,
  `Logradouro` varchar(100) NOT NULL,
  `Unidade` varchar(8) NOT NULL,
  `Complemento` varchar(50) DEFAULT NULL,
  `Bairro` varchar(50) NOT NULL,
  `Localidade` varchar(50) NOT NULL,
  `CodigoLocalidadeIBGE` int(11) NOT NULL,
  `Estado` varchar(30) NOT NULL,
  `DataAlteracao` datetime(6) DEFAULT NULL,
  `TipoEnderecoId` int(11) NOT NULL,
  `Observacoes` longtext DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_Endereco_PessoaID` (`PessoaID`),
  KEY `IX_Endereco_TipoEnderecoId` (`TipoEnderecoId`),
  CONSTRAINT `FK_Endereco_Pessoa_PessoaID` FOREIGN KEY (`PessoaID`) REFERENCES `Pessoa` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_Endereco_TipoEndereco_TipoEnderecoId` FOREIGN KEY (`TipoEnderecoId`) REFERENCES `TipoEndereco` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=217 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Endereco`
--

LOCK TABLES `Endereco` WRITE;
/*!40000 ALTER TABLE `Endereco` DISABLE KEYS */;
INSERT INTO `Endereco` VALUES (12,3,'81930576','Rua Júlia Huga Maria Negrello','521','casa 32','Umbará','Curitiba',4106902,'PR',NULL,1,''),(13,22,'81930576','Rua Júlia Huga Maria Negrello','291','casa 32','Umbará','Curitiba',4106902,'PR',NULL,1,'dasdas'),(14,26,'89283356','Rua Bertholdo Fischer','200','','Centenário','São Bento do Sul',4215802,'SC',NULL,1,''),(21,33,'89400000','Rua Francisco de Paula Dias ','155','Casa',' Santa Rosa ','Porto União',0,'SC','2026-05-23 16:25:27.322505',1,NULL),(22,34,'07243040','Rua Deise','195','Casa','Cidade Parque Brasília','Guarulhos',0,'SP','2026-05-23 16:26:24.810016',1,NULL),(23,35,'89460056','Rua Coronel Albuquerque','850','Sala','Centro','Canoinhas',0,'SC','2026-05-23 16:30:12.138762',1,NULL),(24,36,'81230130','Rua Cidade de Pomerode','8','Casa','Cidade Industrial','Curitiba',0,'PR','2026-05-23 16:26:34.407757',1,NULL),(25,37,'81820000','Rua Cid Marcondes de Albuquerque','552 ','Casa 41','Pinheirinho','Curitiba',0,'PR','2026-05-23 16:27:41.320031',1,NULL),(26,38,'84240000','Rua Gumercindo Sguario ','589','Distribuidora Cristiana ','Centro ','Piraí do Sul',0,'PR','2026-05-25 16:07:49.641552',1,NULL),(27,39,'04089014','Alameda dos Maracatins','1217','Sala 901','Indianópolis','São Paulo',0,'SP','2026-05-23 16:28:11.103121',1,NULL),(28,40,'09450000','Rua Santa Helena ','303','Casa','Santa Teresa','Rio Grande da Serra',0,'SP','2026-05-23 16:28:27.329788',1,NULL),(29,41,'82820250','Rua Guglielmo Marconi','1295','Casa3','Bairro Alto','Curitiba',0,'PR','2026-05-23 16:28:39.630266',1,NULL),(30,42,'11677199','Rua Antonio Alécio Pigosso','300','','Loteamento Ibisco','Caraguatatuba',0,'SP','2026-05-23 16:29:08.254330',1,NULL),(31,43,'81130190','Rua José Pereira de Araújo','1055','Casa','Capão Raso','Curitiba',0,'PR','2026-05-23 16:30:11.260992',1,NULL),(32,44,'09060140','Rua Tupi','299','apto 194-1','Vila Valparaíso','Santo André',0,'SP','2026-05-23 16:31:07.232335',1,NULL),(33,45,'65950000','Rua Enfermeira Zizi','12','Próximo ao TRT ','Vila Canadá ','Barra do Corda',0,'MA','2026-05-23 16:33:40.382593',1,NULL),(34,46,'35042843','Rua Um','463','Casa / portão preto ','Vale do Sol II','Governador Valadares',0,'MG','2026-05-23 16:38:53.295548',1,NULL),(35,47,'85140000','Rua Gervasio Hitoshi Doi','192','Gaucho Agropecuaria, caixa postal 19','Centro','Candói',0,'PR','2026-05-23 19:43:38.491811',1,NULL),(36,48,'81590370','Rua Avelino Mantovani','215','Sobrado 1','Uberaba','Curitiba',0,'PR','2026-05-23 16:39:57.706638',1,NULL),(37,49,'96570000','Rua João Pinós de Freitas','385','Casa','São Judas Tadeu','Caçapava do Sul',0,'RS','2026-05-23 16:40:01.348224',1,NULL),(38,50,'95084370','Rua Plácido de Castro','1038','901','Exposição','Caxias do Sul',0,'RS','2026-05-23 16:44:19.802079',1,NULL),(39,51,'91781200','Avenida Juca Batista','8000','452','Chapéu do Sol','Porto Alegre',0,'RS','2026-05-23 16:42:38.002665',1,NULL),(40,52,'89509257','Rua Henrique Vebber da Silva','15','No posto de saúde','Rancho Fundo','Caçador',0,'SC','2026-05-23 16:47:13.712686',1,NULL),(41,53,'79833250','Rua Darcy Pedroso de Almeida','1765','Casa ','Vila São Francisco','Dourados',0,'MS','2026-05-23 16:49:45.131110',1,NULL),(42,54,'83322170','Rua Rio Tocantins','1200','Casa 3','Weissópolis','Pinhais',0,'PR','2026-05-23 16:52:47.167433',1,NULL),(43,55,'84015460','Avenida Bonifácio Vilela','1104','032','Jardim Carvalho','Ponta Grossa',0,'PR','2026-05-23 16:54:47.686199',1,NULL),(44,56,'88101150','Rua Altamiro di Bernardi','662','Apto 302','Campinas','São José',0,'SC','2026-05-24 21:31:19.867957',1,NULL),(45,57,'04916005','Travessa Professora Maria T. Prado de Mendonça','01','Casa','Jardim Figueira Grande','São Paulo',0,'SP','2026-05-23 17:01:54.977166',1,NULL),(46,58,'82515260','Rua Nicarágua','2730','Apto 41','Bacacheri','Curitiba',0,'PR','2026-05-23 17:03:06.715693',1,NULL),(47,59,'21210760','Rua Cacequi','291','Casa2','Brás de Pina','Rio de Janeiro',0,'RJ','2026-05-23 17:06:03.539965',1,NULL),(48,60,'13343100','Alameda Doutor José Cardeal','360','Barracão comercial','Jardim Pedroso','Indaiatuba',0,'SP','2026-05-23 17:06:15.188560',1,NULL),(49,61,'83325630','Rua Domingos Maceno','166','Casa 6','Alto Tarumã ','Pinhais',0,'PR','2026-05-23 17:07:57.517967',1,NULL),(50,62,'84530000','PR 438 KM 29, Sítio Daniele ','01','Casa','Guaraúna','Teixeira Soares',0,'PR','2026-05-25 14:49:24.174908',1,NULL),(51,63,'83255000','Rodovia Darci Gomes de Moraes','151','Loja Moça Biju','Praia de Leste','Pontal do Paraná',0,'PR','2026-05-23 17:13:40.393440',1,NULL),(52,64,'14600063','Praça 7 de Setembro','191','Apto 31','Centro','São Joaquim da Barra',0,'SP','2026-05-23 17:18:11.580379',1,NULL),(53,65,'83506295','Travessa Kauani Ferreira Pontes','77','Casa','Bonfim','Almirante Tamandaré',0,'PR','2026-05-23 17:19:11.364134',1,NULL),(54,66,'95032318','Avenida Ruben Bento Alves','4626','LOJA MA | AC PIERRE','Santa Catarina','Caxias do Sul',0,'RS','2026-05-23 17:33:08.832454',1,NULL),(55,67,'84040130','Rua Nestor Guimarães','77','Ed Infinity','Estrela','Ponta Grossa',0,'PR','2026-05-23 17:39:30.831422',1,NULL),(56,68,'12975132','Rua Cid Bueno','11','Casa','São Brás (Batatuba)','Piracaia',0,'SP','2026-05-23 17:48:00.358785',1,NULL),(57,69,'38970000','Rua Jesus Guimarães ','342','Casa ','Camposaltinho','Campos Altos',0,'MG','2026-05-23 17:48:02.515328',1,NULL),(58,70,'84172450','Rua José Bonifácio','1367','','Vila Rio Branco','Castro',0,'PR','2026-05-23 17:49:36.241398',1,NULL),(59,71,'85035410','Rua Amadeu Karpinski Rocha','215','Ap 204','Bonsucesso','Guarapuava',0,'PR','2026-05-23 17:53:41.275265',1,NULL),(60,72,'88813568','Rua Xavante','358','Casa final da rua ','Argentina','Criciúma',0,'SC','2026-05-23 18:02:30.745667',1,NULL),(61,73,'82120310','Rua Manife Tacla','990','Casa','Pilarzinho','Curitiba',0,'PR','2026-05-23 18:04:18.052534',1,NULL),(62,74,'80035250','Rua Pedro Fabri','165','Apto 704 Bl A ','Cabral','Curitiba',0,'PR','2026-05-23 18:06:07.235958',1,NULL),(63,75,'96508010','Rua Sete de Setembro','1392','','Centro','Cachoeira do Sul',0,'RS','2026-05-23 18:15:48.612625',1,NULL),(64,76,'84400000','Avenida Sao Joao','2708','Agencia Sicoob','Centro','Prudentópolis',0,'PR','2026-05-23 18:16:42.104464',1,NULL),(65,77,'81930165','Estrada do Ganchinho','2530','Casa 96','Umbará','Curitiba',0,'PR','2026-05-23 18:19:32.434661',1,NULL),(66,78,'80630068','Avenida Presidente Wenceslau Braz','2750','Casa do Isopor','Guaíra','Curitiba',0,'PR','2026-05-23 18:22:26.901774',1,NULL),(67,79,'81520290','Rua João Carlos de Souza Castro','358','sobrado 19','Guabirotuba','Curitiba',0,'PR','2026-05-23 18:23:58.827249',1,NULL),(68,80,'85063200','Rua Carla Selhorst de Souza','245','Casa','São Cristóvão','Guarapuava',0,'PR','2026-05-23 18:25:08.135699',1,NULL),(69,81,'87203212','Rua do Agrônomo ','123',NULL,'Jardim nova Itália ','Cianorte',0,'PR','2026-05-23 18:26:03.027401',1,NULL),(70,82,'82930280','Rua São João Eudes','155','Sobrado 3','Cajuru','Curitiba',0,'PR','2026-05-23 18:27:44.555876',1,NULL),(71,83,'09350000','Avenida Itapark','2941','Apto 86b','Jardim Itapark','Mauá',0,'SP','2026-05-23 18:31:10.028878',1,NULL),(72,84,'81220190','Rua João Alencar Guimarães','225','503 B','Campo Comprido','Curitiba',0,'PR','2026-05-23 18:43:48.748546',1,NULL),(73,85,'90110000','Avenida Praia de Belas','1212','1119','Praia de Belas','Porto Alegre',0,'RS','2026-05-23 18:45:05.594132',1,NULL),(74,86,'13735390','Rua Aparecida Boa Ventura Rodrigues','261','Casa','Residencial Mais Parque Mococa','Mococa',0,'SP','2026-05-23 18:46:06.022788',1,NULL),(75,87,'13690000','Rua Luiz Terci ','61','','Bosque do tamanduá ','Descalvado',0,'SP','2026-05-23 19:00:20.527631',1,NULL),(76,88,'81130310','Rua Laudelino Ferreira Lopes','1240','','Capão Raso','Curitiba',0,'PR','2026-05-23 19:07:30.951916',1,NULL),(77,89,'84072110','Rua Antônio Garcia Valentim','674','Casa ','Boa Vista','Ponta Grossa',0,'PR','2026-05-23 19:10:43.698184',1,NULL),(78,90,'81870680','Rua Miguel Couto dos Santos','229','','Pinheirinho','Curitiba',0,'PR','2026-05-23 19:30:06.759920',1,NULL),(79,91,'80210000','Avenida Prefeito Omar Sabbag','894','','Jardim Botânico','Curitiba',0,'PR','2026-05-23 19:32:07.150380',1,NULL),(80,92,'91225100','Rua Alfredo Miranda Obino','274','Casa ','Jardim Itu','Porto Alegre',0,'RS','2026-05-23 19:35:56.659371',1,NULL),(81,93,'35171382','Avenida Cananeia','29','Apto 101','Júlia Kubitschek','Coronel Fabriciano',0,'MG','2026-05-23 19:49:45.694572',1,NULL),(82,94,'84504778','Avenida Noé Rebesco','214','Aj motocenter','Lagoa','Irati',0,'PR','2026-05-23 19:58:14.915614',1,NULL),(83,95,'85200023','Avenida Presidente Getulio Vargas','551','Diferencial Corretora','Centro','Pitanga',0,'PR','2026-05-23 20:10:58.929794',1,NULL),(84,96,'81250615','Rua Frei Eurico de Mello','270','','Cidade Industrial','Curitiba',0,'PR','2026-05-23 21:24:07.444678',1,NULL),(85,97,'89825000','Rua Avelino Lunardi ','1316','Casa','Guarani','Xaxim',0,'SC','2026-05-24 09:17:41.769863',1,NULL),(86,98,'04143040','Rua General Camisão','290','Ap121','Saúde','São Paulo',0,'SP','2026-05-24 13:14:31.148210',1,NULL),(87,99,'18074751','Rua Selma Aparecida Said','801','B5 41','Horto Florestal','Sorocaba',0,'SP','2026-05-24 13:19:41.654531',1,NULL),(88,100,'86010380','Rua Sergipe','309','Loja 286','Centro','Londrina',0,'PR','2026-05-24 14:05:07.330618',1,NULL),(89,101,'85140000','Rua Gervasio hitochi doi','192','Agropecuária do gaúcho ','Centro','Candói',0,'PR','2026-05-24 14:19:51.651811',1,NULL),(90,102,'11730386','Rua Manoel Fialho de Araujo','800','Sobrado','Pedreira','Mongaguá',0,'SP','2026-05-24 16:22:48.614572',1,NULL),(91,103,'89252130','Rua Leopoldo Janssen','404','Casa de esquina, acesso pela rua Leopoldo Janssen,','Nova Brasília','Jaraguá do Sul',0,'SC','2026-05-24 17:15:06.259045',1,NULL),(92,104,'95270000','Rua Sixto Gabriel Schiavenin ','2938','Em frente pavilhão Gava','União ','Flores da Cunha',0,'RS','2026-05-24 17:53:49.148382',1,NULL),(93,105,'81930165','Estrada do Ganchinho','660','Carretao','Umbará','Curitiba',0,'PR','2026-05-24 19:03:51.996650',1,NULL),(94,106,'80630280','Rua Assis Figueiredo','1315','Apto 92 torre 02 fase A ','Guaíra','Curitiba',0,'PR','2026-05-24 19:29:28.905614',1,NULL),(95,107,'89840000','Rua Minas Gerais ','105','Casa','Centro','Coronel Freitas',0,'SC','2026-05-24 19:44:11.614645',1,NULL),(96,108,'99950000','Vila Campos ','Sn ','Casa ','Vila Campos ','Tapejara',0,'RS','2026-05-24 19:56:53.394422',1,NULL),(97,109,'84600140','Rua Professor Cleto','537','','Centro','União da Vitória',0,'PR','2026-05-24 19:58:45.511922',1,NULL),(98,110,'27213220','Rua José de Anchieta','25','apto 704','Aterrado','Volta Redonda',0,'RJ','2026-05-24 19:59:47.728561',1,NULL),(99,111,'32240260','Rua Antônio Pires','149','Casa','Bandeirantes','Contagem',0,'MG','2026-05-24 21:15:53.165499',1,NULL),(100,112,'01303020','Praça Franklin Roosevelt','222','Ap 801','Consolação','São Paulo',0,'SP','2026-05-24 22:16:14.630011',1,NULL),(101,113,'83709470','Rua Flor-de-lis','1146','Casa','Campina da Barra','Araucária',0,'PR','2026-05-25 06:53:03.568389',1,NULL),(102,114,'95059740','Rua Júlio Prestes','1571','Casa','Serrano','Caxias do Sul',0,'RS','2026-05-25 08:00:59.657203',1,NULL),(103,115,'81810610','Rua José Campanelli','65','Casa','Xaxim','Curitiba',0,'PR','2026-05-25 08:18:05.818214',1,NULL),(104,116,'84020440','Rua Senador Albuquerque Maranhão','27','Casa cinza','Neves','Ponta Grossa',0,'PR','2026-05-25 08:59:14.011161',1,NULL),(105,117,'84263330','Rua Madre de Deus','22','','Vila Santa Rita','Telêmaco Borba',0,'PR','2026-05-25 09:15:55.019009',1,NULL),(106,118,'89480000','Luiz Davet','1635','Casa','Nova Brasília ','Major Vieira',0,'SC','2026-05-25 09:30:36.032845',1,NULL),(107,119,'95185000','RUA BUARQUE DE MACEDO','3211','PRIMEIRO SUBSOLO - SEC. DE PLANEJAMENTO','CENTRO','Carlos Barbosa',0,'RS','2026-05-25 10:27:24.930349',1,NULL),(108,120,'95680588','Rua Tio Elias','401','Escola Sylvio Hoffmann ','Leodoro de Azevedo','Canela',0,'RS','2026-05-25 10:49:24.996766',1,NULL),(109,121,'83708270','Rua Valentim Wall','231','Casa','Tindiquera','Araucária',0,'PR','2026-05-25 12:38:27.585006',1,NULL),(110,122,'98170000','Avenida Rio Branco','539','Casa ','Centro ','Tupanciretã',0,'RS','2026-05-25 12:46:35.671844',1,NULL),(111,123,'89509257','Rua Henrique Vebber da Silva','15','Posto de saúde ','Rancho Fundo','Caçador',0,'SC','2026-05-25 12:47:25.701351',1,NULL),(112,124,'14020380','Avenida Portugal','1400','Ap 21','Jardim São Luiz','Ribeirão Preto',0,'SP','2026-05-25 12:59:15.870978',1,NULL),(113,125,'84010290','Rua Coronel Bittencourt','177','Sala 1 ','Centro','Ponta Grossa',0,'PR','2026-05-25 14:40:03.825546',1,NULL),(114,126,'81930030','Rua Profeta Isaías','359','Casa ','Umbará','Curitiba',0,'PR','2026-05-25 14:40:47.540215',1,NULL),(115,127,'88210000','Dos samagaias ','890','Apto 48A','Vila nova ','Porto Belo',0,'SC','2026-05-25 14:42:03.763338',1,NULL),(116,128,'13724230','Rua Olímpio Marçal Nogueira','169','Casa','Jardim Bela Vista','São José do Rio Pardo',0,'SP','2026-05-25 14:44:41.946106',1,NULL),(117,129,'09060370','Rua Gonçalves Crespo','51','Casa 2','Vila Valparaíso','Santo André',0,'SP','2026-05-25 14:44:52.668331',1,NULL),(118,130,'85812260','Rua Erechim','1354 ','ap 1501 torre 1','Centro','Cascavel',0,'PR','2026-05-25 14:45:09.386068',1,NULL),(119,131,'06720450','Estrada do Taboleiro Verde','210','Casa51','Taboleiro Verde','Cotia',0,'SP','2026-05-25 14:47:18.455659',1,NULL),(120,132,'85010330','Rua Pedro Siqueira','1417','','Centro','Guarapuava',0,'PR','2026-05-25 14:47:33.568621',1,NULL),(121,133,'18170668','Rua Doutor Adolfo Bezerra de Menezes','285','275','Vila Olinda','Piedade',0,'SP','2026-05-25 14:48:04.945858',1,NULL),(122,134,'93534000','Avenida Victor Hugo Kunz','2057','Casa','Hamburgo Velho','Novo Hamburgo',0,'RS','2026-05-25 14:50:59.254747',1,NULL),(123,135,'89560031','Rua Iomerê','1041','Casa','Floresta','Videira',0,'SC','2026-05-25 14:51:00.160840',1,NULL),(124,136,'96085000','Avenida Ferreira Viana','2719','214-B','Areal','Pelotas',0,'RS','2026-05-25 14:51:43.919080',1,NULL),(125,137,'88803660','Rua Interlagos','205','Casa10, condomínio vivendas do parque','Recanto Verde','Criciúma',0,'SC','2026-05-25 14:55:17.430505',1,NULL),(126,138,'81270100','Rua Maria Homan Wisniewski','525','Casa','Cidade Industrial','Curitiba',0,'PR','2026-05-25 14:59:17.134704',1,NULL),(127,139,'88047483','Servidão Gervásio José da Silva','244','Casa ','Carianos','Florianópolis',0,'SC','2026-05-25 15:04:19.994370',1,NULL),(128,140,'81940090','Rua Napoleão Lyrio Teixeira','32','Sobrado ','Tatuquara','Curitiba',0,'PR','2026-05-25 15:04:20.992655',1,NULL),(129,141,'02801000','Avenida Elísio Teixeira Leite','2119','apto 43','Vila Brasilândia','São Paulo',0,'SP','2026-05-25 15:17:39.816175',1,NULL),(130,142,'36201026','Rua Francisco Sales','154','Casa','Boa Morte','Barbacena',0,'MG','2026-05-25 15:28:06.889266',1,NULL),(131,143,'08180100','Rua Cachoeira Itaguassava','483','casa Cinza','Jardim Noemia','São Paulo',0,'SP','2026-05-25 15:47:16.418215',1,NULL),(132,144,'85900020','Rua Almirante Barroso','2788','','Centro','Toledo',0,'PR','2026-05-25 15:49:40.103076',1,NULL),(133,145,'18013004','Avenida São Paulo','2264','64','Além Ponte','Sorocaba',0,'SP','2026-05-25 15:51:21.965096',1,NULL),(134,146,'84172070','Rua Stephano Rudeck','152',NULL,'Jardim dos Bancários','Castro',0,'PR','2026-05-25 15:53:08.086455',1,NULL),(135,147,'87302140','Rua Mamborê','1500','Regional de Saúde','Centro','Campo Mourão',0,'PR','2026-05-25 15:58:49.720300',1,NULL),(136,148,'91790800','Avenida Luiz Francisco Zanella','760','Casa','Restinga','Porto Alegre',0,'RS','2026-05-25 16:11:28.509147',1,NULL),(137,149,'13214205','Avenida Antônio Frederico Ozanan','9600','Casa 151','Jardim Shangai','Jundiaí',0,'SP','2026-05-25 16:19:34.420733',1,NULL),(138,150,'19167570','Rua Bernardino Carmello Aranda Sanches','215','Casa H3','Residencial Valência','Álvares Machado',0,'SP','2026-05-25 16:20:03.811987',1,NULL),(139,151,'82310347','Rua Alberto Panek','528','Casa 9','Orleans','Curitiba',0,'PR','2026-05-25 16:21:39.366513',1,NULL),(140,152,'88420000','Rua. Rudolfo Theilacker ','159','escola','Ipiranga ','Agrolândia',0,'SC','2026-05-25 16:34:14.406875',1,NULL),(141,153,'88345036','Rua Amazonas','568','Apt 201','Areias','Camboriú',0,'SC','2026-05-25 18:37:45.910126',1,NULL),(142,154,'88330422','Rua 2350','476','de 258/259 a 1268/1269','Centro','Balneário Camboriú',4202008,'SC',NULL,1,''),(143,155,'04890400','Rua Maria Roschel Schunck','796','','Jardim Novo Parelheiros','São Paulo',0,'SP','2026-05-25 19:12:49.951956',1,NULL),(144,156,'84640000','Avenida João Agustini ','746','','Jardim Andréia','Bituruna',4102901,'PR',NULL,1,''),(145,157,'95020181','Rua Visconde de Pelotas','782','Escola 5 Estrelas ','Centro','Caxias do Sul',0,'RS','2026-05-25 19:28:36.319675',1,NULL),(146,158,'18310043','Rua Deputado Cunha Bueno','340','','Centro','Guapiara',0,'SP','2026-05-25 22:11:08.052951',1,NULL),(147,159,'88495000','Rodovia 434 km 03','602','Casa | mini mercado catarina ','Campo duna ','Garopaba',0,'SC','2026-05-26 06:57:33.938286',1,NULL),(148,160,'12917030','Rua Pamplona de Navarra','135','Cond ','Condomínio Residencial Euroville','Bragança Paulista',0,'SP','2026-05-26 07:17:03.145239',1,NULL),(149,161,'85065050','Rua Padre Chagas','2349','Casa','Alto da XV','Guarapuava',0,'PR','2026-05-26 08:21:11.163637',1,NULL),(150,162,'94691500','Avenida Paraguassu','420','Sopro Work','Zona Nova','Capão da Canoa',0,'RS','2026-05-26 14:49:32.137605',1,NULL),(151,163,'24445300','Rua Doutor Nilo Peçanha','895','Casa','Antonina','São Gonçalo',0,'RJ','2026-05-26 15:35:17.205290',1,NULL),(152,164,'84970000','Rua São Paulo ','139','Mercado Ferraz ','Centro ','Santana do Itararé',0,'PR','2026-05-28 09:47:14.837948',1,NULL),(153,165,'89306079','Rua São José','425','Apto 301','Jardim do Moinho','Mafra',0,'SC','2026-05-28 17:36:43.812483',1,NULL),(154,166,'85301040','Avenida Santos Dumont','2617','sala 02, escritório de advocacia Peterson Barbosa','Centro','Laranjeiras do Sul',0,'PR','2026-05-28 22:52:53.222554',1,NULL),(155,167,'89609000','Rua Vigário Frei João ','711','Borracharia Luzerna ','Centro ','Luzerna',0,'SC','2026-05-28 23:29:45.733043',1,NULL),(156,168,'40260485','Rua Luiz Anselmo','159','Lado escola luis anselmo ','Luiz Anselmo','Salvador',0,'BA','2026-06-09 15:53:23.870693',1,NULL),(157,169,'97670000','Coronel Aparício Mariense da Silva','2510','Apto 201','Centeo','São Borja',0,'RS','2026-05-30 13:55:47.448173',1,NULL),(158,170,'89610000','Rua treze de maio ','770','Casa ','Nossa senhora de Fátima ','Herval D\'Oeste',0,'SC','2026-05-30 22:13:38.278828',1,NULL),(159,171,'86340114','Avenida Sete de Setembro','919','Sala 2','Centro','Sertaneja',0,'PR','2026-05-31 21:57:03.921559',1,NULL),(160,172,'89490000','Vitorino Ferreira ','449','Casa ','Vila Nova ','Três Barras',0,'SC','2026-06-01 12:44:32.172481',1,NULL),(161,173,'89300366','Avenida Coronel José Severiano Maia','1498','Valerio seguros','Vila Buenos Aires','Mafra',0,'SC','2026-06-01 14:00:03.453532',1,NULL),(162,174,'89805001','Avenida Getúlio Dorneles Vargas ','2553 ','Centro Adm Sicoob ','Passo dos Fortes','Chapecó',0,'SC','2026-06-01 15:33:48.741874',1,NULL),(163,175,'03058000','Rua Conselheiro Cotegipe','294','Ap 94 C','Belenzinho','São Paulo',0,'SP','2026-06-01 15:35:29.123128',1,NULL),(164,176,'82840240','Rua Arthur Ramos','683','','Bairro Alto','Curitiba',0,'PR','2026-06-01 15:36:07.729754',1,NULL),(165,177,'84145000','São Paulo','317','Em frente igreja católica ','Jardim Brasília ','Carambeí',0,'PR','2026-06-01 15:37:28.971292',1,NULL),(166,178,'93950000','Av dez de setembro ','241','203 ','Centro ','Dois Irmãos',0,'RS','2026-06-01 15:45:35.163135',1,NULL),(167,179,'81860140','Rua Guairacá','146','','Alto Boqueirão','Curitiba',0,'PR','2026-06-01 15:53:34.951778',1,NULL),(168,180,'84010220','Rua Júlio de Castilho','126','Casa ','Centro','Ponta Grossa',0,'PR','2026-06-01 16:02:03.922672',1,NULL),(169,181,'83701225','Rua Antônio Ribeiro dos Santos','15','Bloco 6 - apartamento 2','Iguaçu','Araucária',0,'PR','2026-06-01 16:14:02.683105',1,NULL),(170,182,'17603090','Rua Ernesto Martins Silva','84',NULL,'Vila Tupã Mirim I','Tupã',0,'SP','2026-06-01 16:23:06.148366',1,NULL),(171,183,'85301050','Rua Quinze de Novembro','2151','Caixa','Centro','Laranjeiras do Sul',0,'PR','2026-06-01 16:42:00.143324',1,NULL),(172,184,'82840540','Rua Ângelo Breseghello','422','Condominio Boulevard Elegance, Casa 29','Bairro Alto','Curitiba',0,'PR','2026-06-01 16:58:11.040963',1,NULL),(173,185,'89460094','Rua Antônio Bugardt','50','Prédio comercial (no salão  Josi cabeleireira) ','Centro','Canoinhas',0,'SC','2026-06-01 17:06:18.593244',1,NULL),(174,186,'96820040','Rua Rio Branco','468','Apto 201','Centro','Santa Cruz do Sul',0,'RS','2026-06-01 17:57:18.507263',1,NULL),(175,187,'88142150','Rua Pedro Neri Schwinden','1681','LOJA MINI KALZONE - Harley Mesquita','Vargem dos Pinheiros','Santo Amaro da Imperatriz',0,'SC','2026-06-01 19:10:33.068989',1,NULL),(176,188,'83206000','Alameda Coronel Elysio Pereira','457','A/C CLÊNIO na Fiat Florença ','Estradinha','Paranaguá',0,'PR','2026-06-02 08:34:02.467951',1,NULL),(177,189,'85065050','Rua Padre Chagas','2349','','Alto da XV','Guarapuava',0,'PR','2026-06-02 10:13:57.713794',1,NULL),(178,190,'85065050','Rua Padre Chagas','2349','','Alto da XV','Guarapuava',0,'PR','2026-06-02 10:15:51.925531',1,NULL),(179,191,'03317001','Rua Serra de Botucatu','1631','Telefonica vivo','Vila Gomes Cardim','São Paulo',0,'SP','2026-06-03 07:45:14.675514',1,NULL),(180,192,'13277590','Rua Ângelo Barbisan','379','','Jardim Maracanã','Valinhos',0,'SP','2026-06-05 14:20:46.938216',1,NULL),(181,193,'85660000','Av Rio Grande do Sul ','283','Matheus foto color','Centro','Dois Vizinhos',0,'PR','2026-06-08 13:39:34.994877',1,NULL),(182,194,'88215000','Rua pavao','158','Residencial Jardim das americas bloco 2 apto 203','Bombas','Bombinhas',0,'SC','2026-06-08 13:47:42.052503',1,NULL),(183,195,'89520000','Rua João Manoel Carlos ','9','Clínica odonto excellence ','Centro','Curitibanos',0,'SC','2026-06-08 14:40:34.582797',1,NULL),(184,196,'89022140','Rua Frederico Riemer','274','Casa','Garcia','Blumenau',0,'SC','2026-06-15 14:15:49.671971',1,NULL),(185,197,'84600280','Avenida Manoel Ribas','503','Chaveiro Elite','Centro','União da Vitória',0,'PR','2026-06-08 16:50:53.400555',1,NULL),(186,198,'81010310','Avenida Santa Bernadethe','101','Bloco 1 ap 45','Portão','Curitiba',0,'PR','2026-06-09 15:54:05.251637',1,NULL),(187,199,'89295019','Rua Pedro Simões de Oliveira','215','Procon ','Centro','Rio Negrinho',0,'SC','2026-06-09 16:05:56.141143',1,NULL),(188,200,'18532126','Rua Oscar Pesce','175','Casa','Jardim São Francisco','Tietê',0,'SP','2026-06-09 16:52:50.339527',1,NULL),(189,201,'73083140','Quadra ES 4A rua 06','14','Cond. mini chacara','Setor de Mansões de Sobradinho','Brasília',0,'DF','2026-06-09 16:54:40.711419',1,NULL),(190,202,'88032005','Rodovia José Carlos Daux','2040','SL Projeta loja de churrasqueira ','Saco Grande','Florianópolis',0,'SC','2026-06-09 17:37:38.407558',1,NULL),(191,203,'82520570','Rua Coronel Francisco de Paula Moura Brito','935','Casa','Bacacheri','Curitiba',0,'PR','2026-06-09 20:44:04.838582',1,NULL),(192,204,'97542440','Rua Marquês de Alegrete','92','Casa','Centro','Alegrete',0,'RS','2026-06-09 23:50:29.262755',1,NULL),(193,205,'88960000','Rua breno Cardoso ','870','Casa','São luiz ','Sombrio',0,'SC','2026-06-10 08:43:45.310559',1,NULL),(194,206,'03813370','Rua Rio Farias','27','A','Vila Jacuí','São Paulo',0,'SP','2026-06-10 18:36:58.680233',1,NULL),(195,207,'27330052','Via Sérgio Braga','1600','Trend Auto','Barbara','Barra Mansa',0,'RJ','2026-06-10 20:48:19.066729',1,NULL),(196,208,'27350160','Rua Evaristo Resende','113','','Jardim Boa Vista','Barra Mansa',0,'RJ','2026-06-10 23:40:25.889529',1,NULL),(197,209,'83420415','Rua Durval Ribeiro da Costa','700','','Centro','Quatro Barras',0,'PR','2026-06-12 10:47:37.653769',1,NULL),(198,210,'84172236','Travessa Levi Saldanha','20','Casa','Morada do Sol','Castro',0,'PR','2026-06-15 14:33:20.133346',1,NULL),(199,211,'95700356','Travessa Manaus','114','Ap 103','Cidade Alta','Bento Gonçalves',0,'RS','2026-06-15 14:36:34.132512',1,NULL),(200,212,'13205737','Rua Regina Dellacqua Visnardi','40','','Jardim Marambaia','Jundiaí',0,'SP','2026-06-15 14:36:34.548426',1,NULL),(201,213,'84990000','Rua dos Expedicionários','196','Lara & Negrão Advogados Associados ','Centro','Arapoti',0,'PR','2026-06-15 14:37:25.493573',1,NULL),(202,214,'83802512','Rua Presidente Getúlio Vargas','285','Casa','Vila Brasília','Mandirituba',0,'PR','2026-06-15 14:38:40.179914',1,NULL),(203,215,'84015900','Rua Vereador Ernâni Batista Rosas','3131','AP 31 Booco 08','Jardim Carvalho','Ponta Grossa',0,'PR','2026-06-15 16:05:39.060727',1,NULL),(204,216,'18703668','Rua José da Silva Duarte','108','','Jardim di Fiori','Avaré',0,'SP','2026-06-15 14:40:44.095990',1,NULL),(205,217,'13848807','Rua Hélio Pereira de Lima','234','Casa','Jardim Santa Cecília','Mogi Guaçu',0,'SP','2026-06-15 14:51:13.208929',1,NULL),(206,218,'18213650','Rua Pedro Rogachesey','111','Casa','Jardim Marabá','Itapetininga',0,'SP','2026-06-15 14:49:20.156923',1,NULL),(207,219,'88200100','Rua Florianópolis','400','Sala 02 - Verde Azul urbanismo ','Centro','Tijucas',0,'SC','2026-06-15 15:43:49.620352',1,NULL),(208,220,'18310029','Rua Deputado Diógenes Ribeiro de Lima','134','Casa ','Centro','Guapiara',0,'SP','2026-06-22 12:07:29.365732',1,NULL),(209,221,'85012320','Rua Tiradentes','331','','Trianon','Guarapuava',0,'PR','2026-06-22 17:00:59.448603',1,NULL),(210,222,'27251260','Rua Doutor Miguel Couto','150','Apto 201','Jardim Amália','Volta Redonda',0,'RJ','2026-06-22 17:15:23.667467',1,NULL),(211,223,'95650000','Rua Lili Kunst','69','','Moinho','Igrejinha',0,'RS','2026-06-22 17:04:45.808193',1,NULL),(212,224,'90020004','Rua dos Andradas','846','Afpergs ','Centro Histórico','Porto Alegre',0,'RS','2026-06-23 08:54:43.149078',1,NULL),(213,225,'85170001','Rua XV de Dezembro','162','Sobrado rosa ','Centro','Pinhão',0,'PR','2026-06-23 12:54:58.407684',1,NULL),(214,226,'84635000','Rua Mariano Zacharias ','47 ','Casa ','São Francisco de Lima ','Paulo Frontin',0,'PR','2026-06-22 17:11:38.802639',1,NULL),(215,227,'89280490','Rua Jorge Zipperer','234','','Centro','São Bento do Sul',0,'SC','2026-06-22 17:25:14.576559',1,NULL),(216,228,'84182284','Rua Otacilio Alves','30','','Santa Terezinha','Castro',0,'PR','2026-06-22 21:15:09.054158',1,NULL);
/*!40000 ALTER TABLE `Endereco` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Estoque`
--

DROP TABLE IF EXISTS `Estoque`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Estoque` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Quantidade` int(11) NOT NULL,
  `Localizacao` varchar(100) DEFAULT NULL,
  `DataAlteracao` datetime(6) DEFAULT NULL,
  `ProdutoId` int(11) NOT NULL DEFAULT 0,
  `CodigoEstoque` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_Estoque_ProdutoId` (`ProdutoId`),
  CONSTRAINT `FK_Estoque_Produto_ProdutoId` FOREIGN KEY (`ProdutoId`) REFERENCES `Produto` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Estoque`
--

LOCK TABLES `Estoque` WRITE;
/*!40000 ALTER TABLE `Estoque` DISABLE KEYS */;
INSERT INTO `Estoque` VALUES (31,1,'Loja Principal','2026-01-01 21:33:38.000000',57,57),(32,1,'Loja Principal','2026-01-01 21:35:49.000000',58,58),(33,1,'Loja Principal','2026-01-01 21:42:37.000000',59,59),(34,1,'Loja Principal','2026-01-11 11:49:28.000000',60,60),(35,1,'Loja Principal','2026-01-25 15:39:30.000000',61,61),(37,1,'Loja Principal','2026-01-25 18:00:16.000000',63,63),(38,1,'Loja Principal','2026-01-25 18:13:46.000000',64,64),(39,1,'Loja Principal','2026-02-08 13:20:03.000000',65,65),(40,1,'Loja Principal','2026-02-08 13:32:45.000000',66,66),(41,1,'Loja Principal','2026-02-08 13:32:45.000000',67,67),(42,1,'Loja Principal','2026-02-08 13:32:45.000000',68,68),(43,1,'Loja Principal','2026-02-08 13:45:58.000000',69,69),(44,1,'Loja Principal','2026-02-08 13:45:58.000000',70,70),(45,1,'Loja Principal','2026-02-08 13:45:58.000000',71,71),(46,1,'Loja Principal','2026-02-08 14:29:17.000000',72,72),(47,1,'Loja Principal','2026-02-08 14:29:17.000000',73,73),(48,1,'Loja Principal','2026-02-08 19:04:38.000000',74,74),(49,1,'Loja Principal','2026-02-09 14:23:39.000000',75,75),(50,1,'Loja Principal','2026-02-09 14:23:47.000000',76,76),(51,1,'Loja Principal','2026-02-09 14:23:55.000000',77,77),(52,1,'',NULL,78,78);
/*!40000 ALTER TABLE `Estoque` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FormaPagamento`
--

DROP TABLE IF EXISTS `FormaPagamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FormaPagamento` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Descricao` longtext NOT NULL,
  `DataAlteracao` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FormaPagamento`
--

LOCK TABLES `FormaPagamento` WRITE;
/*!40000 ALTER TABLE `FormaPagamento` DISABLE KEYS */;
INSERT INTO `FormaPagamento` VALUES (1,'Dinheiro','2025-04-29 19:40:29.000000'),(2,'Pix','2025-04-29 19:40:46.000000'),(3,'Cartão','2025-04-29 19:41:02.000000');
/*!40000 ALTER TABLE `FormaPagamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FormaPagamentoConfigPDV`
--

DROP TABLE IF EXISTS `FormaPagamentoConfigPDV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FormaPagamentoConfigPDV` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `FormaPagamentoId` int(11) NOT NULL,
  `ExibirNoPDV` tinyint(1) NOT NULL,
  `PermiteParcelamento` tinyint(1) NOT NULL,
  `MaxParcelas` int(11) DEFAULT NULL,
  `TaxaAdmPerc` decimal(65,30) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_FormaPagamentoConfigPDV_FormaPagamentoId` (`FormaPagamentoId`),
  CONSTRAINT `FK_FormaPagamentoConfigPDV_FormaPagamento_FormaPagamentoId` FOREIGN KEY (`FormaPagamentoId`) REFERENCES `FormaPagamento` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FormaPagamentoConfigPDV`
--

LOCK TABLES `FormaPagamentoConfigPDV` WRITE;
/*!40000 ALTER TABLE `FormaPagamentoConfigPDV` DISABLE KEYS */;
INSERT INTO `FormaPagamentoConfigPDV` VALUES (1,1,1,0,NULL,NULL),(2,2,1,0,NULL,NULL),(3,3,1,0,NULL,NULL);
/*!40000 ALTER TABLE `FormaPagamentoConfigPDV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Live`
--

DROP TABLE IF EXISTS `Live`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Live` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Titulo` varchar(50) NOT NULL,
  `Observacoes` longtext DEFAULT NULL,
  `DataLive` datetime(6) NOT NULL DEFAULT '0001-01-01 00:00:00.000000',
  `DataAlteracao` datetime(6) NOT NULL DEFAULT '0001-01-01 00:00:00.000000',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Live`
--

LOCK TABLES `Live` WRITE;
/*!40000 ALTER TABLE `Live` DISABLE KEYS */;
/*!40000 ALTER TABLE `Live` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LiveSession`
--

DROP TABLE IF EXISTS `LiveSession`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LiveSession` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `LiveVideoId` bigint(20) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `StartedAt` datetime(6) NOT NULL,
  `EndedAt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LiveSession`
--

LOCK TABLES `LiveSession` WRITE;
/*!40000 ALTER TABLE `LiveSession` DISABLE KEYS */;
/*!40000 ALTER TABLE `LiveSession` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Nfce`
--

DROP TABLE IF EXISTS `Nfce`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Nfce` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Numero` int(11) NOT NULL,
  `Serie` int(11) NOT NULL,
  `ChaveAcesso` varchar(44) DEFAULT NULL,
  `Protocolo` varchar(20) DEFAULT NULL,
  `Status` varchar(20) NOT NULL,
  `CodigoRetorno` int(11) DEFAULT NULL,
  `MensagemRetorno` varchar(500) DEFAULT NULL,
  `ValorProdutos` decimal(65,30) NOT NULL,
  `ValorDesconto` decimal(65,30) DEFAULT NULL,
  `ValorTotal` decimal(65,30) NOT NULL,
  `VendaPdvId` int(11) DEFAULT NULL,
  `PedidoId` int(11) DEFAULT NULL,
  `ClienteId` int(11) DEFAULT NULL,
  `ClienteCpfCnpj` varchar(14) DEFAULT NULL,
  `ClienteNome` varchar(100) DEFAULT NULL,
  `XmlEnvio` longtext DEFAULT NULL,
  `XmlRetorno` longtext DEFAULT NULL,
  `DataCancelamento` datetime(6) DEFAULT NULL,
  `JustificativaCancelamento` varchar(255) DEFAULT NULL,
  `ProtocoloCancelamento` varchar(20) DEFAULT NULL,
  `DataEmissao` datetime(6) NOT NULL,
  `DataAutorizacao` datetime(6) DEFAULT NULL,
  `UsuarioId` int(11) DEFAULT NULL,
  `Ambiente` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_Nfce_ClienteId` (`ClienteId`),
  KEY `IX_Nfce_PedidoId` (`PedidoId`),
  KEY `IX_Nfce_VendaPdvId` (`VendaPdvId`),
  CONSTRAINT `FK_Nfce_Pedido_PedidoId` FOREIGN KEY (`PedidoId`) REFERENCES `Pedido` (`Id`),
  CONSTRAINT `FK_Nfce_Pessoa_ClienteId` FOREIGN KEY (`ClienteId`) REFERENCES `Pessoa` (`Id`),
  CONSTRAINT `FK_Nfce_VendaPdv_VendaPdvId` FOREIGN KEY (`VendaPdvId`) REFERENCES `VendaPdv` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Nfce`
--

LOCK TABLES `Nfce` WRITE;
/*!40000 ALTER TABLE `Nfce` DISABLE KEYS */;
/*!40000 ALTER TABLE `Nfce` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NfceItem`
--

DROP TABLE IF EXISTS `NfceItem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `NfceItem` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NfceId` int(11) NOT NULL,
  `NumeroItem` int(11) NOT NULL,
  `ProdutoId` int(11) DEFAULT NULL,
  `CodigoProduto` varchar(60) NOT NULL,
  `Descricao` varchar(120) NOT NULL,
  `NCM` varchar(8) NOT NULL,
  `CFOP` varchar(4) NOT NULL,
  `Unidade` varchar(6) NOT NULL,
  `Quantidade` decimal(65,30) NOT NULL,
  `ValorUnitario` decimal(65,30) NOT NULL,
  `ValorDesconto` decimal(65,30) DEFAULT NULL,
  `ValorTotal` decimal(65,30) NOT NULL,
  `CSOSN` varchar(3) NOT NULL,
  `OrigemMercadoria` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_NfceItem_NfceId` (`NfceId`),
  KEY `IX_NfceItem_ProdutoId` (`ProdutoId`),
  CONSTRAINT `FK_NfceItem_Nfce_NfceId` FOREIGN KEY (`NfceId`) REFERENCES `Nfce` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_NfceItem_Produto_ProdutoId` FOREIGN KEY (`ProdutoId`) REFERENCES `Produto` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NfceItem`
--

LOCK TABLES `NfceItem` WRITE;
/*!40000 ALTER TABLE `NfceItem` DISABLE KEYS */;
/*!40000 ALTER TABLE `NfceItem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NfcePagamento`
--

DROP TABLE IF EXISTS `NfcePagamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `NfcePagamento` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NfceId` int(11) NOT NULL,
  `TipoPagamento` varchar(2) NOT NULL,
  `Valor` decimal(65,30) NOT NULL,
  `TipoIntegracao` int(11) NOT NULL,
  `BandeiraCartao` varchar(2) DEFAULT NULL,
  `AutorizacaoCartao` varchar(20) DEFAULT NULL,
  `CNPJCredenciadora` varchar(14) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_NfcePagamento_NfceId` (`NfceId`),
  CONSTRAINT `FK_NfcePagamento_Nfce_NfceId` FOREIGN KEY (`NfceId`) REFERENCES `Nfce` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NfcePagamento`
--

LOCK TABLES `NfcePagamento` WRITE;
/*!40000 ALTER TABLE `NfcePagamento` DISABLE KEYS */;
/*!40000 ALTER TABLE `NfcePagamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NivelAcesso`
--

DROP TABLE IF EXISTS `NivelAcesso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `NivelAcesso` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Descricao` varchar(200) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NivelAcesso`
--

LOCK TABLES `NivelAcesso` WRITE;
/*!40000 ALTER TABLE `NivelAcesso` DISABLE KEYS */;
INSERT INTO `NivelAcesso` VALUES (1,'Master'),(2,'Consulta'),(3,'string'),(4,'string'),(5,'string'),(6,'string'),(7,'string'),(8,'string'),(9,'string'),(10,'string'),(11,'string'),(12,'string');
/*!40000 ALTER TABLE `NivelAcesso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Origem`
--

DROP TABLE IF EXISTS `Origem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Origem` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Descricao` varchar(200) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Origem`
--

LOCK TABLES `Origem` WRITE;
/*!40000 ALTER TABLE `Origem` DISABLE KEYS */;
INSERT INTO `Origem` VALUES (1,'Live'),(2,'Loja Física');
/*!40000 ALTER TABLE `Origem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Pedido`
--

DROP TABLE IF EXISTS `Pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Pedido` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PedidoCodigo` int(11) NOT NULL,
  `DataLancamento` datetime(6) NOT NULL,
  `ClienteID` int(11) NOT NULL,
  `DescontoPorcentagem` decimal(18,3) DEFAULT NULL,
  `ValorFrete` decimal(18,3) DEFAULT NULL,
  `PedidoStatusID` int(11) NOT NULL,
  `ValorTotal` decimal(18,3) DEFAULT NULL,
  `CondicaoPagamentoID` int(11) DEFAULT NULL,
  `FormaPagamentoID` int(11) DEFAULT NULL,
  `EnderecoEntregaID` int(11) DEFAULT NULL,
  `Observacoes` longtext DEFAULT NULL,
  `DataAlteracao` datetime(6) NOT NULL DEFAULT '0001-01-01 00:00:00.000000',
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_Pedido_PedidoCodigo` (`PedidoCodigo`),
  KEY `IX_Pedido_ClienteID` (`ClienteID`),
  KEY `IX_Pedido_CondicaoPagamentoID` (`CondicaoPagamentoID`),
  KEY `IX_Pedido_EnderecoEntregaID` (`EnderecoEntregaID`),
  KEY `IX_Pedido_FormaPagamentoID` (`FormaPagamentoID`),
  KEY `IX_Pedido_PedidoStatusID` (`PedidoStatusID`),
  CONSTRAINT `FK_Pedido_CondicaoPagamento_CondicaoPagamentoID` FOREIGN KEY (`CondicaoPagamentoID`) REFERENCES `CondicaoPagamento` (`Id`),
  CONSTRAINT `FK_Pedido_Endereco_EnderecoEntregaID` FOREIGN KEY (`EnderecoEntregaID`) REFERENCES `Endereco` (`Id`),
  CONSTRAINT `FK_Pedido_FormaPagamento_FormaPagamentoID` FOREIGN KEY (`FormaPagamentoID`) REFERENCES `FormaPagamento` (`Id`),
  CONSTRAINT `FK_Pedido_PedidoStatus_PedidoStatusID` FOREIGN KEY (`PedidoStatusID`) REFERENCES `PedidoStatus` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_Pedido_Pessoa_ClienteID` FOREIGN KEY (`ClienteID`) REFERENCES `Pessoa` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Pedido`
--

LOCK TABLES `Pedido` WRITE;
/*!40000 ALTER TABLE `Pedido` DISABLE KEYS */;
/*!40000 ALTER TABLE `Pedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PedidoProduto`
--

DROP TABLE IF EXISTS `PedidoProduto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PedidoProduto` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PedidoId` int(11) NOT NULL,
  `ProdutoId` int(11) NOT NULL,
  `Quantidade` int(11) NOT NULL,
  `DescontoValor` decimal(18,3) DEFAULT NULL,
  `ValorFinalProduto` decimal(18,3) DEFAULT NULL,
  `DataAlteracao` datetime(6) NOT NULL DEFAULT '0001-01-01 00:00:00.000000',
  PRIMARY KEY (`Id`),
  KEY `IX_PedidoProduto_PedidoId` (`PedidoId`),
  KEY `IX_PedidoProduto_ProdutoId` (`ProdutoId`),
  CONSTRAINT `FK_PedidoProduto_Pedido_PedidoId` FOREIGN KEY (`PedidoId`) REFERENCES `Pedido` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_PedidoProduto_Produto_ProdutoId` FOREIGN KEY (`ProdutoId`) REFERENCES `Produto` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PedidoProduto`
--

LOCK TABLES `PedidoProduto` WRITE;
/*!40000 ALTER TABLE `PedidoProduto` DISABLE KEYS */;
/*!40000 ALTER TABLE `PedidoProduto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PedidoStatus`
--

DROP TABLE IF EXISTS `PedidoStatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PedidoStatus` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Descricao` longtext NOT NULL,
  `DataAlteracao` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PedidoStatus`
--

LOCK TABLES `PedidoStatus` WRITE;
/*!40000 ALTER TABLE `PedidoStatus` DISABLE KEYS */;
INSERT INTO `PedidoStatus` VALUES (1,'Pedido Recebido/Criado','2025-04-29 19:47:40.000000'),(2,'Aguardando Pagamento','2025-04-29 19:47:40.000000'),(3,'Pagamento Aprovado','2025-04-29 19:47:40.000000'),(4,'Em Separação','2025-04-29 19:47:40.000000'),(5,'Em Embalagem','2025-04-29 19:47:40.000000'),(6,'Enviado/Despachado','2025-04-29 19:47:40.000000'),(7,'Em Trânsito','2025-04-29 19:47:40.000000'),(8,'Entregue','2025-04-29 19:47:40.000000'),(9,'Cancelado','2025-04-29 19:47:40.000000'),(10,'Devolvido','2025-04-29 19:47:40.000000'),(11,'Troca Solicitada','2025-04-29 19:47:40.000000'),(12,'Troca em Processamento','2025-04-29 19:47:40.000000'),(13,'Troca Concluída','2025-04-29 19:47:40.000000'),(14,'Em Ajuste','2025-04-29 19:47:40.000000'),(15,'Personalização em Andamento','2025-04-29 19:47:40.000000');
/*!40000 ALTER TABLE `PedidoStatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Permission`
--

DROP TABLE IF EXISTS `Permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` longtext DEFAULT NULL,
  `resource` varchar(50) NOT NULL,
  `action` varchar(50) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IX_Permission_name` (`name`),
  KEY `IX_Permission_action` (`action`),
  KEY `IX_Permission_is_active` (`is_active`),
  KEY `IX_Permission_resource` (`resource`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Permission`
--

LOCK TABLES `Permission` WRITE;
/*!40000 ALTER TABLE `Permission` DISABLE KEYS */;
INSERT INTO `Permission` VALUES (1,'produtos_create','Criar produtos','produtos','CREATE',1,'2025-08-07 20:07:30.000000','2025-08-07 20:07:30.000000'),(2,'produtos_read','Visualizar produtos','produtos','READ',1,'2025-08-07 20:07:30.000000','2025-08-07 20:07:30.000000'),(3,'produtos_update','Atualizar produtos','produtos','UPDATE',1,'2025-08-07 20:07:30.000000','2025-08-07 20:07:30.000000'),(4,'produtos_delete','Deletar produtos','produtos','DELETE',1,'2025-08-07 20:07:30.000000','2025-08-07 20:07:30.000000'),(5,'estoque_manage','Gerenciar estoque','estoque','CREATE,UPDATE',1,'2025-08-07 20:09:29.000000','2025-08-07 20:09:29.000000'),(6,'estoque_read','Visualizar estoque','estoque','READ',1,'2025-08-07 20:09:29.000000','2025-08-07 20:09:29.000000'),(7,'pedidos_create','Criar pedidos','pedidos','CREATE',1,'2025-08-07 20:10:15.000000','2025-08-07 20:10:15.000000'),(8,'pedidos_read','Visualizar pedidos','pedidos','READ',1,'2025-08-07 20:10:15.000000','2025-08-07 20:10:15.000000'),(9,'pedidos_update','Atualizar pedidos','pedidos','UPDATE',1,'2025-08-07 20:10:15.000000','2025-08-07 20:10:15.000000'),(10,'pedidos_delete','Deletar pedidos','pedidos','DELETE',1,'2025-08-07 20:10:15.000000','2025-08-07 20:10:15.000000'),(11,'clientes_create','Cadastrar clientes','clientes','CREATE',1,'2025-08-07 20:10:55.000000','2025-08-07 20:10:55.000000'),(12,'clientes_read','Visualizar clientes','clientes','READ',1,'2025-08-07 20:10:55.000000','2025-08-07 20:10:55.000000'),(13,'clientes_update','Atualizar clientes','clientes','UPDATE',1,'2025-08-07 20:10:55.000000','2025-08-07 20:10:55.000000'),(14,'clientes_delete','Deletar clientes','clientes','DELETE',1,'2025-08-07 20:10:55.000000','2025-08-07 20:10:55.000000'),(15,'usuarios_create','Criar usuários','usuarios','CREATE',1,'2025-08-07 20:11:40.000000','2025-08-07 20:11:40.000000'),(16,'usuarios_read','Visualizar usuários','usuarios','READ',1,'2025-08-07 20:11:40.000000','2025-08-07 20:11:40.000000'),(17,'usuarios_update','Atualizar usuários','usuarios','UPDATE',1,'2025-08-07 20:11:40.000000','2025-08-07 20:11:40.000000'),(18,'usuarios_delete','Deletar usuários','usuarios','DELETE',1,'2025-08-07 20:11:40.000000','2025-08-07 20:11:40.000000'),(19,'full_access','Acesso completo a todos os recursos','*','*',1,'2025-08-07 20:11:40.000000','2025-08-07 20:11:40.000000');
/*!40000 ALTER TABLE `Permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Pessoa`
--

DROP TABLE IF EXISTS `Pessoa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Pessoa` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Nome` varchar(50) DEFAULT NULL,
  `DataNascimento` datetime(6) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Telefone` varchar(13) DEFAULT NULL,
  `PessoaCategoriaId` int(11) NOT NULL,
  `PessoaTipoId` int(11) NOT NULL,
  `NickName` longtext CHARACTER SET utf8mb4 DEFAULT NULL,
  `DataInclusao` datetime(6) DEFAULT NULL,
  `StatusId` int(11) NOT NULL DEFAULT 0,
  `PessoaGeneroId` int(11) NOT NULL DEFAULT 0,
  `CPF` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `RG` longtext CHARACTER SET utf8mb4 DEFAULT NULL,
  `Observacoes` longtext CHARACTER SET utf8mb4 DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_Pessoa_PessoaCategoriaId` (`PessoaCategoriaId`),
  KEY `IX_Pessoa_PessoaTipoId` (`PessoaTipoId`),
  KEY `IX_Pessoa_StatusId` (`StatusId`),
  KEY `IX_Pessoa_PessoaGeneroId` (`PessoaGeneroId`),
  CONSTRAINT `FK_Pessoa_PessoaCategoria_PessoaCategoriaId` FOREIGN KEY (`PessoaCategoriaId`) REFERENCES `PessoaCategoria` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_Pessoa_PessoaGenero_PessoaGeneroId` FOREIGN KEY (`PessoaGeneroId`) REFERENCES `PessoaGenero` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_Pessoa_PessoaStatus_StatusId` FOREIGN KEY (`StatusId`) REFERENCES `PessoaStatus` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_Pessoa_PessoaTipo_PessoaTipoId` FOREIGN KEY (`PessoaTipoId`) REFERENCES `PessoaTipo` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=229 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Pessoa`
--

LOCK TABLES `Pessoa` WRITE;
/*!40000 ALTER TABLE `Pessoa` DISABLE KEYS */;
INSERT INTO `Pessoa` VALUES (1,'Admin','2024-04-14 20:14:51.000000','admin@brechozeira.com.br','41985072178',1,1,'admin','2025-03-13 12:38:03.507290',1,1,'309.657.590-83','85818452',NULL),(3,'Sarah','1985-06-05 21:00:00.000000','sarah@brechozeira.com.br','41985072179',1,1,'Sarinha','2025-04-10 10:37:07.057093',1,1,'341.836.058-06','85844256','obs da sarah'),(22,'Eduardo Rocha','1984-01-27 09:00:00.000000','eduardo.cwbnet@gmail.com','41985072178',2,1,'r0cha_pr','2026-06-14 14:02:02.457235',1,2,'008.745.969-80','85818007',''),(26,'Letícia Alexandra Maia',NULL,NULL,'47997174860',2,1,'leti_alexandra','2026-05-23 11:58:46.799433',1,1,'092.028.219-92',NULL,''),(33,'Patricia F Reisdorfer Alves ',NULL,'pfreisdorfer@gmail.com','42999846076',2,1,'@Paty&digo','2026-05-23 16:25:27.278073',1,1,'036.419.899-06',NULL,NULL),(34,'Jennifer Alves da Silva',NULL,'jenniferalves1261@gmail.com','11952426713',2,1,'@Jennifer_alves_','2026-05-23 16:25:39.222972',1,1,'473.677.358-88',NULL,NULL),(35,'Natali',NULL,'natali.agrimapas@outlook.com','47984058446',2,1,'@Czerniak','2026-05-23 16:26:20.885014',1,1,'082.609.139-33',NULL,NULL),(36,'Flavia Cristina Lopes ',NULL,'flavinha_lopes2014@outlook.com','41988762288',2,1,'@flavia_lopes94','2026-05-23 16:26:34.394160',1,1,'097.955.169-22',NULL,NULL),(37,'Leisiane Degan ',NULL,'leisidegan@hotmail.com','41988600201',2,1,'@leisidegan','2026-05-23 16:27:41.314590',1,1,'076.134.279-60',NULL,NULL),(38,'Katielle Solek ',NULL,'katisolek@outlook.com','42999672680',2,1,'@katiellesolek','2026-05-23 16:27:57.720182',1,1,'058.789.529-20',NULL,NULL),(39,'Telma Ruth Silva Reis ',NULL,'telmareis212@gmail.com','11968296703',2,1,'@Telma reis.7906','2026-05-23 16:28:11.093938',1,1,'304.841.868-76',NULL,NULL),(40,'MARCELA GILLIAN LOPES',NULL,'magillian19@gmail.com','11964835796',2,1,'@Gillian Marcela','2026-05-23 16:28:27.325883',1,1,'316.420.918-55',NULL,NULL),(41,'Patrícia Gomes Vidal Corrêa ',NULL,'pgvc91@gmail.com','41997110264',2,1,'@patriciagomesvc','2026-05-23 16:28:39.622926',1,1,'036.249.611-01',NULL,NULL),(42,'Pamela Cristina Vieira',NULL,'pamelaluavieira@yahoo.com.br','12997221251',2,1,'@pamvieira','2026-05-23 16:29:08.251396',1,1,'351.363.148-00',NULL,NULL),(43,'Priscila Faria Alves',NULL,'prikafariaalves@hotmail.com','41997415447',2,1,'@priscilafaria','2026-05-23 16:30:11.258049',1,1,'043.011.649-79',NULL,NULL),(44,'Miriam H. Asano',NULL,'miriam_asano@hotmail.com','11991989653',2,1,'@mi_asano','2026-05-23 16:31:07.227682',1,1,'265.755.898-47',NULL,NULL),(45,'Raimunda Salete Sá de Morais Aquino ',NULL,'Saleteaquinocc@gmail.com','99984532828',2,1,'@Sademoraos','2026-05-23 16:33:40.379148',1,1,'402.816.633-00',NULL,NULL),(46,'Carolina Vieira Coimbra Botinha ',NULL,'carolacad@hotmail.com','27997262408',2,1,'@botinhacarol','2026-05-23 16:36:44.306207',1,1,'112.739.806-70',NULL,NULL),(47,'Ana Maria Deschk',NULL,'amdeschk@hotmail.com','42991074001',2,1,'@anadeschk','2026-05-23 16:38:20.361333',1,1,'104.558.599-81',NULL,NULL),(48,'Kethlyn Louise monteiro',NULL,'ketlouise@gmail.com','41988974922',2,1,'@Ketymonteiro','2026-05-23 16:38:29.293088',1,1,'010.380.359-96',NULL,NULL),(49,'Fernanda Trindade Dutra de Almeida',NULL,'fernandadutradealmeida@gmail.com','55991496059',2,1,'@fernandaalmeida3110','2026-05-23 16:40:01.340776',1,1,'552.681.530-72',NULL,NULL),(50,'Simone Eder',NULL,'simoneeder75@gmail.com','54996255083',2,1,'@simoneeder_','2026-05-23 16:42:31.315561',1,1,'896.457.070-72',NULL,NULL),(51,'Aniele Lima de Souzw',NULL,'anielelsouza@gmail.com','51991179047',2,1,'@anielelsouza','2026-05-23 16:42:37.995631',1,1,'966.352.400-63',NULL,NULL),(52,'Sabrina Antonioli',NULL,'sabrinaantonioli5@gmail.com','49991712505',2,1,'@sabrinantonioli','2026-05-23 16:47:13.710196',1,1,'075.990.289-51',NULL,NULL),(53,'Kallen CHRISTIANY Miranda Ferreira',NULL,'kallencmf@gmaul.com','67998513111',2,1,'@_kallenchristiany','2026-05-23 16:49:45.129054',1,1,'816.285.011-20',NULL,NULL),(54,'Pamela Bello',NULL,'bellopamela@gmail.com','41999548094',2,1,'@pamelasbello','2026-05-23 16:51:27.839760',1,1,'053.008.709-00',NULL,NULL),(55,'Paola Carzino ',NULL,'pacarzino@gmail.com','42999330380',2,1,'@pacarzino','2026-05-23 16:54:47.683277',1,1,'089.253.019-70',NULL,NULL),(56,'Larissa Hokama ',NULL,'lahokama@yahoo.com.br','48998189178',2,1,'@lari.hokama','2026-05-23 17:00:42.527821',1,1,'293.860.388-62',NULL,NULL),(57,'Caroline Silva Brandão ',NULL,'carolinebrando@gmail.com','11963648997',2,1,'@carolzytab','2026-05-23 17:01:54.974631',1,1,'363.782.278-45',NULL,NULL),(58,'PATRICIA CORREA DE BRITO ',NULL,'patriciacorrea.grhucsal@gmail.com','95991343626',2,1,'@Ticia','2026-05-23 17:03:06.713529',1,1,'032.791.479-30',NULL,NULL),(59,'Neuci Oliveira Viana',NULL,'neucivianaolive@gmail.com','21994729721',2,1,'@Neuviaana','2026-05-25 19:23:33.713767',1,1,'053.449.827-20',NULL,''),(60,'Nicholle Hawyanka',NULL,'hawyankannik@gmail.com','19998359273',2,1,'@Nickhawyanka','2026-05-23 17:06:15.186587',1,1,'438.598.808-02',NULL,NULL),(61,'Juliana Alejandra Penaloza Kozak ',NULL,'jupenaloza@gmail.com','41995232534',2,1,'@ju_kozak','2026-05-23 17:07:57.515541',1,1,'011.732.499-07',NULL,NULL),(62,'Luana Fidelis da Silva Stanislavski ',NULL,'luana_fidelis@hotmail.com','42999838060',2,1,'@_luanafidelis','2026-05-23 17:09:09.483190',1,1,'104.779.549-36',NULL,NULL),(63,'Carla Letícia Mendes',NULL,'neticia4@hotmail.com','41995504328',2,1,'@mocabijupontaldoparana','2026-05-23 17:13:40.390579',1,1,'047.988.409-98',NULL,NULL),(64,'LIGIA OLIVATTO RODRIGUES TEIXEIRA',NULL,'liginhateixeira@hotmail.com','16992373803',2,1,'@liginhaort','2026-05-23 17:18:11.576915',1,1,'221.996.648-80',NULL,NULL),(65,'Fernanda Rodrigues de Sousa ',NULL,'souusa.rodrigues@gmail.com','41999792059',2,1,'@fernanda.r.desousa','2026-05-23 17:19:11.361409',1,1,'012.317.522-46',NULL,NULL),(66,'Nicolle Roxo Sartori',NULL,'nicollesartori@hotmail.com','54991981668',2,1,'@nicollesartoriyoga','2026-05-23 17:33:08.679970',1,1,'034.842.840-56',NULL,NULL),(67,'Môlagra Karoline de Goes',NULL,'molagra_karoline@hotmail.con','42991381629',2,1,'@Molagra_Goes','2026-05-23 17:39:30.826439',1,1,'066.179.379-61',NULL,NULL),(68,'Michelly de Amorim Silva paschoal',NULL,'myxamorim@gmail.com','11974162731',2,1,'@myxamorim','2026-05-23 17:48:00.123057',1,1,'394.065.978-96',NULL,NULL),(69,'Maria Júlia Corrêa Lima ',NULL,'maria.kz@hotmail.com','37991292888',2,1,'@majuukz','2026-05-23 17:48:02.510321',1,1,'114.646.166-63',NULL,NULL),(70,'Adriana Antunes de mello ',NULL,'adrianaamello@hotmail.com','42999717363',2,1,'@adrianaamello1','2026-05-23 17:49:36.234220',1,1,'848.469.419-49',NULL,NULL),(71,'Sabrina Oliveira do Nascimento ',NULL,'drasabrina_oliveira@hotmail.com','43991791173',2,1,'@Eusabrinaoliver','2026-05-23 17:53:41.149195',1,1,'008.918.242-19',NULL,NULL),(72,'Francine peres vefago ',NULL,'leandroeletrica1@hotmail.com','48999219001',2,1,'@franvefago','2026-05-23 18:02:30.572516',1,1,'042.423.529-30',NULL,NULL),(73,'Ana Paula Rosa dos Santos Cardozo ',NULL,'ana-paula-2608@hotmail.com','41996153042',2,1,'@anapaularosasc','2026-05-23 18:04:17.932577',1,1,'063.893.279-35',NULL,NULL),(74,'Patricia Gil Martins dos Santos ',NULL,'paty.gil@hotmail.com','41996275600',2,1,'@Paty.gilmartins','2026-05-23 18:06:07.230366',1,1,'064.030.359-59',NULL,NULL),(75,'Telma Thomaz ',NULL,'telmathomazf@hotmail.com','51999244667',2,1,'@telmathomaz','2026-05-23 18:15:48.609415',1,1,'741.404.770-91',NULL,NULL),(76,'Luzia Litvin',NULL,'luzialitvin@yahoo.com.br','42999660366',2,1,'@lu_litvin','2026-05-23 18:16:42.100616',1,1,'066.391.329-23',NULL,NULL),(77,'Karin Chiuchetta ',NULL,'kkvieira@gmail.com','41984951127',2,1,'@kkvieira','2026-05-23 18:19:32.431000',1,1,'062.643.939-67',NULL,NULL),(78,'Amanda Gelenski Teixeira ',NULL,'amanda.teixeira8@icloud.com','41989026590',2,1,'@amandag.teixeira_','2026-05-23 18:22:26.898028',1,1,'098.921.409-58',NULL,NULL),(79,'Aretusa Moraes',NULL,'aretusamoraes@hotmail.com','41984932970',2,1,'@aretusa.moraes','2026-05-23 18:23:58.824172',1,1,'017.157.109-67',NULL,NULL),(80,'Michelle stempniak',NULL,'michellestempniak@hotmail.com','42991173306',2,1,'@Michellestempniak','2026-05-23 18:25:08.127711',1,1,'069.158.609-83',NULL,NULL),(81,'Iraci souza de sarges gavron ',NULL,'irasarges@hotmail.com','44999444845',2,1,'@Iradesarges','2026-05-23 18:26:03.024817',1,1,'852.889.347-20',NULL,NULL),(82,'Elisângela lima',NULL,'elisangela-lima@hotmail.com.br','41996039053',2,1,'@elisangela1606','2026-05-23 18:27:44.552812',1,1,'004.124.089-88',NULL,NULL),(83,'Ana Lucia Silva de Oliveira ',NULL,'naanobasam@hotmail.com','11983084761',2,1,'@naanobasam','2026-05-23 18:31:10.003310',1,1,'272.284.008-10',NULL,NULL),(84,'Ana Carolina Ferreira de Sá Melo',NULL,'carolzinha_0411@hotmail.com','41996754582',2,1,'@anacarolina_0411','2026-05-23 18:43:48.744994',1,1,'029.701.139-10',NULL,NULL),(85,'Caroline schossler ',NULL,'caroline.schossler@gmail.com','51981866530',2,1,'@carolineschossler','2026-05-23 18:45:05.590232',1,1,'973.550.970-91',NULL,NULL),(86,'Karla Fernanda Gomes Benetti',NULL,'karla.fernanda.benetti@gmail.com','19989544263',2,1,'@karla_benetti','2026-05-23 18:46:06.020539',1,1,'350.843.518-07',NULL,NULL),(87,'Beatriz Cavalcante da Silva ',NULL,'beatrizcs28@outlook.com','19993367092',2,1,'@cavalcante.beatriz','2026-05-23 19:00:20.521745',1,1,'406.208.648-42',NULL,NULL),(88,'Rafaella Safanelli ',NULL,'rsafanelli@hotmail.com','41992131968',2,1,'@rsafanelli','2026-05-23 19:06:29.197086',1,1,'045.633.179-42',NULL,NULL),(89,'Patricia Cristiane de Almeida Ranchil',NULL,'ranchil.pati@hitmail.com','42999372316',2,1,'@pati_ranchil','2026-05-23 19:10:43.692721',1,1,'051.401.639-69',NULL,NULL),(90,'Adriele Pires  de Almeida ',NULL,'adrialmeida01@gmail.com','41992380478',2,1,'@adrialmeida01','2026-05-23 19:30:06.756437',1,1,'061.251.919-82',NULL,NULL),(91,'Sara Lourenço ',NULL,'saralourenco001@gmail.com','41998795630',2,1,'@saralourenco2018','2026-05-23 19:32:07.068011',1,1,'825.198.119-00',NULL,NULL),(92,'Daiane Brasil Dutra ',NULL,'daibrasill@hotmail.com','51984787176',2,1,'@Daibrasill','2026-05-23 19:35:56.655644',1,1,'803.218.870-34',NULL,NULL),(93,'scheila Carvalho Dos Reis',NULL,'scheilacarvalhodosreis@gmail.com','31989559738',2,1,'@Scheilacarvalhoreis','2026-05-23 19:49:45.691821',1,1,'042.623.706-40',NULL,NULL),(94,'Débora Cristine Jurkewicz',NULL,'debo_cris_j@hotmail.com','47988579236',2,1,'@deborajurkewicz','2026-05-23 19:58:14.913191',1,1,'099.024.719-86',NULL,NULL),(95,'Olivia Jaqueline Moreira dos Santos',NULL,'olivia.santos.ojms@gmail.com','42998150363',2,1,'@oliviajaque357','2026-05-23 20:07:06.530531',1,1,'067.048.859-35',NULL,NULL),(96,'Daniela Ouriques de sousa',NULL,'dani.uriques93@gmail.com','41999272906',2,1,'@iinadsousa','2026-05-23 21:24:07.441921',1,1,'061.047.099-07',NULL,NULL),(97,'Amanda Rosa da Rocha',NULL,'amandarocha_08@hotmail.com','49999351007',2,1,'@Amandarosadarocha','2026-05-24 09:17:41.599998',1,1,'027.198.100-88',NULL,NULL),(98,'SUELEN SCOTINI',NULL,'suhscotini@gmail.com','41996823938',2,1,'@suelen_scotini','2026-05-24 13:14:31.141711',1,1,'049.202.279-81',NULL,NULL),(99,'Monique Alves ',NULL,'mnk.fran@gmail.com','11976444900',2,1,'@Chacara_betel015','2026-05-24 13:19:41.651161',1,1,'348.931.888-95',NULL,NULL),(100,'Wesley henrique dos santos ',NULL,'wesleyhenri@icloud.com','43984997253',2,1,'@wesleythaisgranzottis','2026-05-24 14:05:07.325333',1,1,'067.796.429-32',NULL,NULL),(101,'Maria eduarda Deschk ',NULL,'eduardadeschk@hotmail.com','42991284001',2,1,'@Eduardeschk','2026-05-24 14:19:51.648294',1,1,'104.558.859-82',NULL,NULL),(102,'Iolanda Baracho de Oliveira',NULL,'barachoiolanda@gmail.com','13974053103',2,1,'@iolanda_baracho','2026-05-24 16:22:48.604301',1,1,'261.228.688-84',NULL,NULL),(103,'Anne Mery Barbosa Martins',NULL,'annebarbosam@gmail.com','42991348987',2,1,'@annemrtins','2026-05-24 17:14:09.509255',1,1,'103.334.179-76',NULL,NULL),(104,'Camila Marin @',NULL,'caamimarin@hotmail.com','54999416566',2,1,'@camilinhamarin','2026-05-24 17:53:49.145660',1,1,'024.000.960-66',NULL,NULL),(105,'Olinda Penteado',NULL,'celine.pente@gmail.com','41987330894',2,1,'@olindaPenteado','2026-05-24 19:03:51.989919',1,1,'051.225.159-21',NULL,NULL),(106,'Alessandra Brito Nanci',NULL,'alessandrabrito94@hotmail.com','41995576049',2,1,'@Alessandra Brito Nanci','2026-05-24 19:29:28.891985',1,1,'325.721.398-04',NULL,NULL),(107,'Moniky Carla mohr ',NULL,'monikypedagogia@gmail.com','49999948485',2,1,'@monikypedagogia@gmail.com','2026-05-24 19:44:11.609935',1,1,'073.800.459-62',NULL,NULL),(108,'Letícia Marcon ',NULL,'leticiamarcon2@gmail.com','54999949657',2,1,'@leti.marcon','2026-05-24 19:56:53.390725',1,1,'037.837.890-28',NULL,NULL),(109,'Caroline Buch Chagas ',NULL,'carolinebchagas@gmail.com','42998467647',2,1,'@carobuch','2026-05-24 19:58:45.509107',1,1,'055.949.889-63',NULL,NULL),(110,'Keicy Loretti ',NULL,'keicymiguelloretti@gmail.com','21999747364',2,1,'@eukeicyloretti','2026-05-24 19:59:47.722768',1,1,'146.886.047-00',NULL,NULL),(111,'Catia Simone Fernandes Machado ',NULL,'cacau5br@gmail.com','31986444569',2,1,'@catias_machado','2026-05-24 21:15:53.159070',1,1,'050.197.576-40',NULL,NULL),(112,'Flávia Harckbart de Oliveira ',NULL,'flaviaharckbart@gmail.com','61982079294',2,1,'@flaviaharckbart','2026-05-24 22:16:14.620094',1,1,'690.389.611-20',NULL,NULL),(113,'Bruna Thays Venancio ',NULL,'tbruna225@gmail.com','41999901672',2,1,'@Bruna_thays2025','2026-05-25 06:53:03.563876',1,1,'093.794.249-90',NULL,NULL),(114,'Silviane dos Santos Freitas ',NULL,'silvianes.freitas01@gmail.com','54999624141',2,1,'@sil_sfreitas','2026-05-25 08:00:59.653643',1,1,'013.917.790-61',NULL,NULL),(115,'Sônia Gai Coimbra ',NULL,'fatisonia@gmail.com','41984198369',2,1,'@soniagaicoimbra','2026-05-25 08:18:05.815118',1,1,'536.426.949-34',NULL,NULL),(116,'Thamiris Hartmann',NULL,'thamirishartmann92@gmail.com','42998401006',2,1,'@thamirishartmann','2026-05-25 08:59:14.007607',1,1,'084.680.459-00',NULL,NULL),(117,'Lidiane Lara da Luz',NULL,'Lidi_luz@hotmail.com','42429991875',2,1,'@Lidi.lara','2026-05-25 09:15:55.009374',1,1,'064.187.559-28',NULL,NULL),(118,'Janice Malicheski Krauss ',NULL,'farmajanicekrauss@gmail.com','47996112138',2,1,'@farmajanice','2026-05-25 09:30:36.018850',1,1,'040.224.469-94',NULL,NULL),(119,'VANESSA REINSTEIN ALNOCH',NULL,'vanessa.filipini@yahoo.com.br','55996331013',2,1,'@vanessa_alnoch','2026-05-25 10:27:24.926337',1,1,'002.472.630-36',NULL,NULL),(120,'Lisiane dos Santos Schell',NULL,'lisi.schell@hotmail.com','54997017257',2,1,'@lisischell','2026-05-25 10:49:24.992074',1,1,'812.416.310-34',NULL,NULL),(121,'Daiane dos Santos Kujbida ',NULL,'daianekujbida@hotmail.com','41996538938',2,1,'@daianekujbida','2026-05-25 12:38:27.575687',1,1,'070.877.679-50',NULL,NULL),(122,'Louise Peixoto Gomes',NULL,'louisepeixotogomes@gmail.com','55991038191',2,1,'@louisepgomes','2026-05-25 12:46:35.667305',1,1,'021.201.040-93',NULL,NULL),(123,'Izabela dos Santos Twardowski ',NULL,'twardowskiizabela74@yahoo.com','49999266087',2,1,'@izabelatwardowski','2026-05-25 12:47:25.698075',1,1,'116.875.609-00',NULL,NULL),(124,'Juliana Alves Guedes',NULL,'julianaalves_ml@hotmail.com','16988008050',2,1,'@juslvesguedes81','2026-05-25 12:59:15.866597',1,1,'221.640.778-06',NULL,NULL),(125,'Priscila Martins ',NULL,'pri.bijoux@hotmail.com','42999719188',2,1,'@Pribijoux.brecho','2026-05-25 14:40:03.636864',1,1,'025.282.119-02',NULL,NULL),(126,'Daniela Fernandes Rosa ',NULL,'dani77_rosa@outlook.com','41998568746',2,1,'@Dani.f.rosa','2026-05-25 14:40:47.533291',1,1,'024.190.919-81',NULL,NULL),(127,'Priscila bonaccorsi ',NULL,'priscilabonaccorsi@yahoo.com.br','47996293267',2,1,'@Pri_bonna2021','2026-05-25 14:42:03.758063',1,1,'043.265.449-61',NULL,NULL),(128,'Thais Priscilla Leite de Miranda Mendes ',NULL,'thaislmiranda@hotmail.com','11981597717',2,1,'@thaisldemiranda','2026-05-25 14:44:41.941461',1,1,'062.859.034-25',NULL,NULL),(129,'Thaís Helena dos santos soares ',NULL,'thaishss@gmail.com','11944484696',2,1,'@Thata_helena_','2026-05-25 14:44:52.664887',1,1,'299.916.028-36',NULL,NULL),(130,'Lediane Manfé de Souza',NULL,'teacherlediane@gmail.com','46991051110',2,1,'@ledianemanfe','2026-05-25 14:45:09.379535',1,1,'034.099.899-78',NULL,NULL),(131,'Angélica Ferretti Martins',NULL,'angelicaferretti@yahoo.com.br','11971016021',2,1,'@Angelicaferretti.m','2026-05-25 14:47:18.451705',1,1,'368.868.478-80',NULL,NULL),(132,'ANA PAULA ALEIXO',NULL,'paula2311ana@gmail.com','42999774150',2,1,'@ANA PAULA ALEIXO','2026-05-25 14:47:33.564711',1,1,'007.832.889-64',NULL,NULL),(133,'Claudia Reni Cardoso ',NULL,'claudiareni.cc@gmail.com','15991267272',2,1,'@claudiareni','2026-05-25 14:48:04.936868',1,1,'300.859.048-99',NULL,NULL),(134,'Camila Benetti Birk',NULL,'milabenetti@gmail.com','51991265858',2,1,'@camila.benetti.birk','2026-05-25 14:50:59.251128',1,1,'010.473.740-99',NULL,NULL),(135,'Ana Paula Pirolli',NULL,'anapaulasouzz89@gmail.com','49998220236',2,1,'@Ana Paula Pirolli','2026-05-25 14:51:00.157683',1,1,'073.433.769-85',NULL,NULL),(136,'Carla Andrada',NULL,'carla.andrada@gmail.com','53981150530',2,1,'@andradaca','2026-05-25 14:51:43.914945',1,1,'015.461.990-63',NULL,NULL),(137,'Bruna Alves Colonetti Nunes',NULL,'bacolonetti@gmail.com','48999147962',2,1,'@bruninhacolonetti','2026-05-25 14:55:17.427479',1,1,'045.941.379-11',NULL,NULL),(138,'Débora Gonçalves Jientara ',NULL,'deboragoncalves.dgs@gmail.com','41997561216',2,1,'@eu.deborajientara','2026-05-25 14:59:17.130885',1,1,'089.199.369-00',NULL,NULL),(139,'Regiane Sousa ',NULL,'rjjvmp@gmail.com','48998235098',2,1,'@Regiane_mana','2026-05-25 15:04:19.991575',1,1,'520.735.212-15',NULL,NULL),(140,'Giuliana Delaneza ',NULL,'giu.marmorariageogran@gmail.com','41995021111',2,1,'@giuu1210','2026-05-25 15:04:20.989463',1,1,'076.994.029-36',NULL,NULL),(141,'Andressa Souza',NULL,'andressaxscarrijo@hotmail.com','11954542160',2,1,'@andressa_souza','2026-05-25 15:17:39.801963',1,1,'370.828.658-80',NULL,NULL),(142,'Raquel Pimenta de oliveira',NULL,'raquelbqpimenta@hotmail.com','32999514743',2,1,'@raquelpimentafisio','2026-05-25 15:28:06.886439',1,1,'041.573.406-12',NULL,NULL),(143,'Priscila Montoya Coutinho',NULL,'priscila.mvespoli@gmail.com','11976396080',2,1,'@Primontoya','2026-05-25 15:47:16.404801',1,1,'314.655.478-00',NULL,NULL),(144,'Magda Regina Ferreira De Carli',NULL,'magdecarli@gmail.com','45991350211',2,1,'@Magda Regina Ferreira De Carli','2026-05-25 15:49:40.099014',1,1,'023.649.799-51',NULL,NULL),(145,'Cassia Balan',NULL,'cassia.i.balan@gmail.com','15997001666',2,1,'@Cassia Balan','2026-05-25 15:51:21.957090',1,1,'278.341.738-39',NULL,NULL),(146,'Ariany Rebonato ',NULL,'arianyprebonato@gmail.com','42999271001',2,1,'@Ariany Pereira Rebonato','2026-05-25 15:53:08.083824',1,1,'060.123.219-45',NULL,NULL),(147,'Anne Kulik',NULL,'kulikanne@gmail.com','4499108000',2,1,'@Anne Kulik','2026-05-25 15:58:49.716278',1,1,'021.381.229-05',NULL,NULL),(148,'Ana Paula Filipiak ',NULL,'paulinha_filipiak@hotmail.com','51985288803',2,1,'@anafilipiak','2026-05-25 16:11:28.505610',1,1,'026.594.560-70',NULL,NULL),(149,'Jaqueline Marcato Zanquini ',NULL,'jaquezanquini@hotmail.com','11989054929',2,1,'@not_frida_secrets','2026-05-25 16:17:30.539888',1,1,'074.938.926-52',NULL,NULL),(150,'Ana Azzólini',NULL,'ana.azzolini@gmail.com','19981847877',2,1,'@Ana_azzolini_','2026-05-25 16:20:03.809433',1,1,'285.557.968-65',NULL,NULL),(151,'Samantha Hornung ',NULL,'hrnng91@gmail.com','41998846075',2,1,'@samhornung','2026-05-25 16:21:39.348232',1,1,'009.340.189-28',NULL,NULL),(152,'ELIANE BERNARDI',NULL,'elianebenardi10@gmail.com','47988097212',2,1,'@elianebernardii','2026-05-25 16:34:14.386333',1,1,'027.313.259-84',NULL,NULL),(153,'Marli Terezinha Pinto',NULL,'marlivjsouza@gmail.com','47996734887',2,1,'@marlijvsouza','2026-05-25 18:37:45.907317',1,1,'089.518.809-07',NULL,NULL),(154,'Penelope Soares',NULL,NULL,'47988523453',2,1,NULL,'2026-05-25 19:03:51.513091',1,1,'042.533.341-80',NULL,''),(155,'Ana Carolina Correa Silva',NULL,'carolina.correasilva@outlook.com','11975348687',2,1,'@caah_correa','2026-05-25 19:12:49.948353',1,1,'477.965.568-45',NULL,NULL),(156,'Giovana Rodrigues Silva',NULL,NULL,'42933008576',2,1,'@giovana.rodrigues','2026-05-25 19:22:30.116403',1,1,'045.330.989-59',NULL,''),(157,'Lilia Marcia Karpinski ',NULL,'liliakarpinski68@gmail.com','54981220106',2,1,'@liliamkarpinski','2026-05-25 19:28:36.314005',1,1,'499.872.750-87',NULL,NULL),(158,'Luciana Mitsue Nagamati Kido',NULL,'lu.tinkerbell@gmail.com','15996150323',2,1,'@lu.kido','2026-05-25 22:11:07.852465',1,1,'335.954.598-22',NULL,NULL),(159,'Natane Pires',NULL,'natanepires8@gmail.com','55999231145',2,1,'@Natane__','2026-05-26 06:57:33.762198',1,1,'034.321.360-56',NULL,NULL),(160,'Caroline manganelli nagatani',NULL,'carolline.manganelli@hotmail.com','11999765983',2,1,'@Carol manganelli','2026-05-26 07:17:03.138508',1,1,'294.429.768-69',NULL,NULL),(161,'Vyvian Chamma',NULL,'vi_chamma2@hotmail.com','42999535095',2,1,'@vyvianchamma','2026-05-26 08:21:11.158165',1,1,'078.907.139-83',NULL,NULL),(162,'Juliana Baum Nolibos Leffa',NULL,'nolibos.phi@gmail.com','51982419992',2,1,'@Juliananolibos','2026-05-26 14:45:48.253785',1,1,'029.455.900-00',NULL,NULL),(163,'Flavia Carvalho de lima',NULL,'flaviacarvalho19@gmail.com','21964432582',2,1,'@flaviacdlima','2026-05-26 15:35:17.199930',1,1,'112.570.907-39',NULL,NULL),(164,'Luciana Ferraz de Oliveira ',NULL,'luferraz78@gmail.com','43991855097',2,1,'@luferraz','2026-05-28 09:47:14.753036',1,1,'872.000.589-04',NULL,NULL),(165,'Angela Radol',NULL,'angelradol@yahoo.com.br','47997501599',2,1,'@angela_radol','2026-05-28 17:36:43.634149',1,1,'005.671.029-12',NULL,NULL),(166,'MARIA VILIANE WACHAK',NULL,'m.viliane@hotmail.com','42998502187',2,1,'@psicologamariaviliane','2026-05-28 22:52:53.210324',1,1,'061.949.309-77',NULL,NULL),(167,'Elana Schmitz ',NULL,'elanaschmitz@hotmail.com','49988656470',2,1,'@elanaschmitz','2026-05-28 23:29:45.702633',1,1,'080.868.889-83',NULL,NULL),(168,'Erika Moreira Föppel',NULL,'erikafoppel@gmail.com','71981290217',2,1,'@ErikaFöppel','2026-05-29 14:15:10.853439',1,1,'989.928.055-00',NULL,NULL),(169,'Mariângela Escobar Gonçalves',NULL,'dramariangelaescobar@gmail.com','55996946460',2,1,'@dra_mariescobar','2026-05-30 13:55:47.293785',1,1,'023.729.300-52',NULL,NULL),(170,'Ana Gabriela Locatelli Picoli ',NULL,'anapicoli01@gmail.com','49991196960',2,1,'@gabinhaana','2026-05-30 22:13:38.076954',1,1,'114.547.939-10',NULL,NULL),(171,'Mario sergio massaki kimura',NULL,'mario@trxassessoria.com.br','43991261661',2,1,'@Trx_corretora_sertaneja','2026-05-31 21:55:23.393784',1,1,'029.918.249-56',NULL,NULL),(172,'Adílio Borges Oliva ',NULL,'adilio.oliva@gmail.com','47997096702',2,1,'@adiliooliva','2026-06-01 12:44:31.977201',1,1,'058.606.979-88',NULL,NULL),(173,'Juliana semmer ',NULL,'semmerju@gmail.com','47988519691',2,1,'@Jusemmer','2026-06-01 13:43:47.695602',1,1,'100.832.829-47',NULL,NULL),(174,'Eduarda Pozzo Ribeiro ',NULL,'eduardapzz@hotmail.com','49991478926',2,1,'@Eduardapzz','2026-06-01 15:33:48.737384',1,1,'018.872.650-07',NULL,NULL),(175,'Claudia Lima da Silva Passari',NULL,'claudiapassari@gmail.com','11997252683',2,1,'@claudiapassari','2026-06-01 15:35:29.104216',1,1,'186.933.208-31',NULL,NULL),(176,'VANESSA FACHINELLO SCOTINI',NULL,'va.fachinello@gmail.com','41985402110',2,1,'@vane.scotini','2026-06-01 15:36:07.725344',1,1,'025.925.589-00',NULL,NULL),(177,'Ângela Maria Carneiro ',NULL,'angelamc.ventura@hotmail.com','42998607750',2,1,'@angela_mcstar','2026-06-01 15:37:28.884023',1,1,'029.507.279-21',NULL,NULL),(178,'Lilian Maria Muller linke ',NULL,'lilian.linke@santander.com.br','51997390187',2,1,'@lilian._Muller','2026-06-01 15:40:59.553598',1,1,'927.704.790-91',NULL,NULL),(179,'Ana Carla Cravo Marascki ',NULL,'anamarascki12@hotmail.com','41992796404',2,1,'@anamarascki','2026-06-01 15:52:29.610543',1,1,'080.884.479-25',NULL,NULL),(180,'Giselli Ivancheski ',NULL,'giselli.ivancheski@hotmail.com','41997965126',2,1,'@giselliivanch_','2026-06-01 16:02:03.907189',1,1,'089.950.899-54',NULL,NULL),(181,'Hellen Shileid',NULL,'hshileid@gmail.com','41988026381',2,1,'@hellensshileid','2026-06-01 16:14:02.658351',1,1,'062.986.029-76',NULL,NULL),(182,'Eveline Batista Rodrigues',NULL,'evelinerodrigues@yahoo.com','14996316321',2,1,'@eveline.prof','2026-06-01 16:23:06.145282',1,1,'303.808.018-76',NULL,NULL),(183,'Fábio Fukamachi ',NULL,'fabio.fukamachi@gmail.com','45988009303',2,1,'@fabio_ma_fkmch','2026-06-01 16:42:00.137301',1,1,'142.096.308-29',NULL,NULL),(184,'Francieli Toniello',NULL,'frantoniello@gmail.com','49991518357',2,1,'@frantoniello','2026-06-01 16:58:11.038180',1,1,'046.473.649-84',NULL,NULL),(185,'Suliane Quadros ',NULL,'suliane_1999.03@hotmail.com','47996874371',2,1,'@suhquadros2','2026-06-01 17:04:08.658731',1,1,'106.868.239-66',NULL,NULL),(186,'Caroline Martin Kaufmann',NULL,'caroline.kretzmann01@gmail.com','51998938531',2,1,'@_kaufmann.caroline','2026-06-01 17:57:18.503855',1,1,'033.806.420-61',NULL,NULL),(187,'Janaína Mesquita ',NULL,'arqjanainamesquita@gmail.com','48984117046',2,1,'@soujanainalinharesdemesquita','2026-06-01 19:10:33.063559',1,1,'909.197.340-49',NULL,NULL),(188,'Ligia Cordova',NULL,'ligia.manu@hotmail.com','41998386262',2,1,'@ligia_manu','2026-06-02 08:34:02.193722',1,1,'031.964.999-79',NULL,NULL),(189,'Najla Chamma',NULL,'najlachamma@hotmail.com','42999273117',2,1,'@najlachamma','2026-06-02 10:13:57.708625',1,1,'031.555.089-90',NULL,NULL),(190,'Hamilton de Freitas Cunha',NULL,'hamiltondefreitas@yahoo.com.br','42999273117',2,1,'@hamilton.cunha.1806','2026-06-02 10:15:51.920306',1,1,'373.380.999-87',NULL,NULL),(191,'Jessica Ferraz Pujol',NULL,'jessicaferraz92@hotmail.com','11934202654',2,1,'@jessicaferrazpujol','2026-06-03 07:45:14.461246',1,1,'401.857.688-90',NULL,NULL),(192,'NADIA CRISTINA MARCHETTI BERGAMO MANSINI',NULL,'nadia_bergamo@yahoo.com.br','19992912170',2,1,'@nadiabergamomansini','2026-06-05 14:20:46.755619',1,1,'369.355.038-76',NULL,NULL),(193,'Sayane Joenck',NULL,'sahjoenck@gmail.com','46999758323',2,1,'@sajoenck','2026-06-08 13:39:34.787437',1,1,'072.493.469-38',NULL,NULL),(194,'Ydalmis arleira montero bolan̈os',NULL,'ydalmismontero182@gmail.com','47996281299',2,1,'@Chikillamontero','2026-06-08 13:47:42.047645',1,1,'801.459.439-84',NULL,NULL),(195,'Bruna Flávia Montovani ',NULL,'bruninha_montovani@hotmail.com','49989230594',2,1,'@brumontovani','2026-06-08 14:40:34.526733',1,1,'085.733.489-17',NULL,NULL),(196,'Leticia Hoss Schwaderer ',NULL,'leticia.schwaderer@gmail.com','47991377475',2,1,'@leticiahschwaderer','2026-06-08 14:41:54.862346',1,1,'037.058.249-70',NULL,NULL),(197,'Vanessa C M Silva',NULL,'vcmsfono@yahoo.com.br','42984041500',2,1,'@vanessa_fonoo','2026-06-08 16:50:53.397097',1,1,'023.948.189-56',NULL,NULL),(198,'Gabriela Granatto ',NULL,'ggranatto@icloud.com','41992420520',2,1,'@Gabrielagranatto_','2026-06-09 15:54:05.145848',1,1,'107.930.189-51',NULL,NULL),(199,'Camila Lima de Azevedo',NULL,'camila.azevedo111@gmail.com','47992392819',2,1,'@camlss','2026-06-09 16:05:56.135073',1,1,'061.724.199-60',NULL,NULL),(200,'Caroline Guilherme Pinto ',NULL,'21.caroline9@gmail.com','15997658767',2,1,'@fisiocarolinegp','2026-06-09 16:52:50.323796',1,1,'377.425.218-14',NULL,NULL),(201,'Adriana Ricarda da Silva',NULL,'adrianaricarda81@gmail.com','61991165173',2,1,'@adryyannah','2026-06-09 16:54:40.696219',1,1,'963.880.481-53',NULL,NULL),(202,'Luciana De Paula',NULL,'lucianapaulas123@gmail.com','48984041573',2,1,'@Luciana De Paula','2026-06-09 17:37:38.397879',1,1,'150.068.538-08',NULL,NULL),(203,'Miria Cassol Seiixas',NULL,'Miriaseixas@gmail.com','41992092313',2,1,'@miriaseixas','2026-06-09 20:44:04.834486',1,1,'755.219.119-87',NULL,NULL),(204,'Francine Fernandes Pereira ',NULL,'franppereira00@gmail.com','55996058382',2,1,'@franfpp','2026-06-09 23:50:29.253444',1,1,'022.006.590-08',NULL,NULL),(205,'Tuane Custódio Américo ',NULL,'tuanecustodioam@gmail.com','48999023527',2,1,'@Tuanecustodioam','2026-06-10 08:43:45.150788',1,1,'090.918.889-03',NULL,NULL),(206,'Angela Carla de Souza Ferreira Piaia ',NULL,'angela_piaia@hotmail.com','11971911738',2,1,'@Angela Piaia','2026-06-10 18:36:58.674594',1,1,'308.213.288-08',NULL,NULL),(207,'Pollyana Alencar dos Santos Maia ',NULL,'pollyana.alencar@gmail.com','24988050505',2,1,'@pollyanatrend','2026-06-10 20:48:19.057779',1,1,'105.431.857-37',NULL,NULL),(208,'Silvana De Almeida Rodrigues Elias',NULL,'silvana.yoga@hotmail.com','24998414291',2,1,'@Silvana De Almeida Rodrigues Elias','2026-06-10 23:40:25.870495',1,1,'789.406.807-15',NULL,NULL),(209,'Fernanda Morimoto',NULL,'fernanda_morimoto@hotmail.com','41999882031',2,1,'@nandamorimoto','2026-06-12 10:47:37.456327',1,1,'033.689.689-12',NULL,NULL),(210,'Jonathan Silva Ortiz ',NULL,'jonathanortiz2007@gmail.com','42999785778',2,1,'@jonathanortiz_caseih','2026-06-15 14:33:20.072695',1,1,'081.523.859-21',NULL,NULL),(211,'Kétlin Bordin manfroi',NULL,'ketlinbordinmanfroi@gmail.com','54999570215',2,1,'@kebordinmanfroi','2026-06-15 14:36:34.111286',1,1,'002.366.130-57',NULL,NULL),(212,'Tatiane Grandotti ',NULL,'tatigrandotti@gmail.com','11963855100',2,1,'@Tatigrandotti','2026-06-15 14:36:34.533337',1,1,'336.864.988-47',NULL,NULL),(213,'Silvio Lara Junior',NULL,'silvinhoadv@gmail.com','43988090421',2,1,'@silvinholara','2026-06-15 14:37:25.487496',1,1,'008.361.989-56',NULL,NULL),(214,'Andréia da Silva Meira Brunetti ',NULL,'meiraandreia8@gmail.com','41997203437',2,1,'@Andréia-brunetti','2026-06-15 14:38:40.173423',1,1,'085.998.019-70',NULL,NULL),(215,'Débora Geovana Schmitt',NULL,'deschmittt78@gmail.com','42999994665',2,1,'@debboraa_','2026-06-15 14:38:57.034181',1,1,'023.955.499-08',NULL,NULL),(216,'Camila Loiola',NULL,'camiladloiola@gmail.com','11984106080',2,1,'@camila_loiola25','2026-06-15 14:40:12.391603',1,1,'325.354.378-13',NULL,NULL),(217,'Nathany Thayse Mantoan Naliato',NULL,'nathany-mantoan@hotmail.com','19998404310',2,1,'@nathanymantoan','2026-06-15 14:48:06.167600',1,1,'429.431.278-50',NULL,NULL),(218,'Djenane Cristina de Almeida ',NULL,'cris_cristina2802@hotmail.com','11992198780',2,1,'@cris—_djenane','2026-06-15 14:49:20.153492',1,1,'263.553.788-71',NULL,NULL),(219,'Franciele Zarembski',NULL,'eng.francielefigueredo@gmail.com','47999719483',2,1,'@Franzinhaaf','2026-06-15 15:43:49.617329',1,1,'017.502.740-43',NULL,NULL),(220,'Priscila Maria Silvério de Lima Costa Mori ',NULL,'priscilalima.costa@icloud.com','15997418481',2,1,'@priscila_mori','2026-06-22 12:07:29.090099',1,1,'303.622.158-12',NULL,NULL),(221,'GEOVANNA DE OLIVEIRA ALBERTI',NULL,'profegeo3005@gmail.com','42999261090',2,1,'@geovanaalberti','2026-06-22 17:00:59.301784',1,1,'021.047.669-90',NULL,NULL),(222,'Mônica Candida Lugão Moraes ',NULL,'monicalug@yahoo.com.br','24999030323',2,1,'@mclugao','2026-06-22 17:03:08.290925',1,1,'091.916.497-81',NULL,NULL),(223,'Caroline Gabriela Krause',NULL,'c.krausee@live.com','34998201412',2,1,'@cgkrause_','2026-06-22 17:04:45.801276',1,1,'013.244.860-23',NULL,NULL),(224,'Daisy Antunes Costa ',NULL,'costadaisy494@gmail.com','51995956070',2,1,'@daisy.antunes19','2026-06-22 17:04:47.444720',1,1,'927.002.170-04',NULL,NULL),(225,'Luiza Delle ',NULL,'luiza_delle6@hotmail.com','42999270899',2,1,'@luizadelle','2026-06-22 17:05:31.881468',1,1,'069.606.579-70',NULL,NULL),(226,'Letícia Francisco de Lima ',NULL,'leticialima6743@gmail.com','42999563145',2,1,'@leeee_limaa','2026-06-22 17:10:08.325231',1,1,'112.878.499-89',NULL,NULL),(227,'Michele Vicente Michels Baptista ',NULL,'michele.michels@gmail.com','47984089487',2,1,'@mimichels','2026-06-22 17:25:14.565521',1,1,'052.736.009-01',NULL,NULL),(228,'Jessie Miranda Kubis ',NULL,'jessiekubis@outlook.com','42998424918',2,1,'@jessie_kubis','2026-06-22 21:15:08.811092',1,1,'094.787.379-10',NULL,NULL);
/*!40000 ALTER TABLE `Pessoa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PessoaCategoria`
--

DROP TABLE IF EXISTS `PessoaCategoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PessoaCategoria` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Descricao` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PessoaCategoria`
--

LOCK TABLES `PessoaCategoria` WRITE;
/*!40000 ALTER TABLE `PessoaCategoria` DISABLE KEYS */;
INSERT INTO `PessoaCategoria` VALUES (1,'Administrador'),(2,'Cliente');
/*!40000 ALTER TABLE `PessoaCategoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PessoaGenero`
--

DROP TABLE IF EXISTS `PessoaGenero`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PessoaGenero` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Sigla` varchar(1) NOT NULL,
  `Descricao` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PessoaGenero`
--

LOCK TABLES `PessoaGenero` WRITE;
/*!40000 ALTER TABLE `PessoaGenero` DISABLE KEYS */;
INSERT INTO `PessoaGenero` VALUES (1,'F','Feminino'),(2,'M','Masculino'),(3,'U','Unissex');
/*!40000 ALTER TABLE `PessoaGenero` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PessoaPerfil`
--

DROP TABLE IF EXISTS `PessoaPerfil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PessoaPerfil` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Descricao` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PessoaPerfil`
--

LOCK TABLES `PessoaPerfil` WRITE;
/*!40000 ALTER TABLE `PessoaPerfil` DISABLE KEYS */;
INSERT INTO `PessoaPerfil` VALUES (1,'Adulto'),(2,'Infantil');
/*!40000 ALTER TABLE `PessoaPerfil` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PessoaStatus`
--

DROP TABLE IF EXISTS `PessoaStatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PessoaStatus` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Descricao` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PessoaStatus`
--

LOCK TABLES `PessoaStatus` WRITE;
/*!40000 ALTER TABLE `PessoaStatus` DISABLE KEYS */;
INSERT INTO `PessoaStatus` VALUES (1,'Ativo'),(2,'Inativo'),(3,'string'),(4,'string'),(5,'string'),(6,'string'),(7,'string'),(8,'string'),(9,'string'),(10,'string'),(11,'string'),(12,'string');
/*!40000 ALTER TABLE `PessoaStatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PessoaTipo`
--

DROP TABLE IF EXISTS `PessoaTipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PessoaTipo` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Descricao` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PessoaTipo`
--

LOCK TABLES `PessoaTipo` WRITE;
/*!40000 ALTER TABLE `PessoaTipo` DISABLE KEYS */;
INSERT INTO `PessoaTipo` VALUES (1,'Física'),(2,'Jurídica'),(3,'string'),(4,'string'),(5,'string'),(6,'string'),(7,'string'),(8,'string'),(9,'string'),(10,'string'),(11,'string'),(12,'string');
/*!40000 ALTER TABLE `PessoaTipo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Produto`
--

DROP TABLE IF EXISTS `Produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Produto` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Descricao` varchar(100) NOT NULL,
  `Tamanho` varchar(50) DEFAULT NULL,
  `PrecoCusto` decimal(65,2) DEFAULT NULL,
  `PrecoVenda` decimal(18,3) DEFAULT NULL,
  `Origem` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `GrupoID` int(11) NOT NULL DEFAULT 0,
  `DataCompra` datetime(6) DEFAULT NULL,
  `DataAlteracao` datetime(6) DEFAULT NULL,
  `StatusId` int(11) NOT NULL DEFAULT 0,
  `MarcaId` int(11) DEFAULT NULL,
  `GeneroID` int(11) NOT NULL,
  `PerfilID` int(11) NOT NULL,
  `Condicao` varchar(1) CHARACTER SET utf8mb4 DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_Produto_StatusId` (`StatusId`),
  KEY `IX_Produto_MarcaId` (`MarcaId`),
  KEY `IX_Produto_PerfilID` (`PerfilID`),
  KEY `IX_Produto_GeneroID` (`GeneroID`),
  KEY `IX_Produto_GrupoID` (`GrupoID`),
  CONSTRAINT `FK_Produto_PessoaGenero_GeneroID` FOREIGN KEY (`GeneroID`) REFERENCES `PessoaGenero` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_Produto_ProdutoGrupo_GrupoID` FOREIGN KEY (`GrupoID`) REFERENCES `ProdutoGrupo` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_Produto_ProdutoMarca_MarcaId` FOREIGN KEY (`MarcaId`) REFERENCES `ProdutoMarca` (`Id`),
  CONSTRAINT `FK_Produto_ProdutoPerfil_PerfilID` FOREIGN KEY (`PerfilID`) REFERENCES `ProdutoPerfil` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_Produto_ProdutoStatus_StatusId` FOREIGN KEY (`StatusId`) REFERENCES `ProdutoStatus` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Produto`
--

LOCK TABLES `Produto` WRITE;
/*!40000 ALTER TABLE `Produto` DISABLE KEYS */;
INSERT INTO `Produto` VALUES (57,'Vestido Farm','GG',0.00,0.000,'Off Premium',5,'2026-01-01 21:33:38.000000','2026-01-01 21:33:38.000000',1,17,1,1,'U'),(58,'Vestido branco Zara','G',89.00,209.000,'Off Premium',5,'2026-01-01 21:35:49.000000','2026-01-01 21:35:49.000000',1,16,1,1,'U'),(59,'Calça Jeans Lança Perfume','M',79.90,199.900,'Off Premium',3,'2026-01-02 00:42:37.000000','2026-01-02 00:43:04.000000',1,4,2,1,NULL),(60,'Shorts branco Zara','G',75.00,150.000,'BBB',4,'2026-01-11 11:49:28.000000','2026-01-11 11:49:28.000000',1,16,1,1,'U'),(61,'Camiseta amarela Farm Feminina','P',119.00,209.000,'Loja física',1,'2026-01-25 15:39:30.000000','2026-01-25 15:39:30.000000',1,17,1,1,'U'),(63,'Vestido rosa Tommy Hilfiger','P',0.00,0.000,'Loja física',5,'2026-01-25 18:00:16.000000','2026-01-25 18:00:16.000000',1,1,1,1,'U'),(64,'Vestido Outros estampa tucano com banana','',0.00,69.900,'Loja física',5,'2026-01-25 18:13:46.000000','2026-01-25 18:13:46.000000',1,10,2,1,'U'),(65,'Camiseta salmão Columbia','G',0.00,159.900,'Loja física',1,'2026-02-08 13:20:03.000000','2026-02-08 13:20:03.000000',1,13,1,1,'N'),(66,'Camiseta Columbia','',0.00,159.900,'Loja física',1,'2026-02-08 13:32:45.000000','2026-02-08 13:32:45.000000',1,13,1,1,'N'),(67,'Camiseta estampa floral salmão Columbia','G',0.00,159.000,'Loja física',1,'2026-02-08 13:32:45.000000','2026-02-08 13:32:45.000000',1,13,1,1,'N'),(68,'Camiseta vermelho escuro Columbia','P',0.00,159.900,'Loja física',1,'2026-02-08 13:32:45.000000','2026-02-08 13:32:45.000000',1,13,1,1,'N'),(69,'Camiseta vermelho Clara Columbia','P',0.00,159.900,'Loja física',1,'2026-02-08 13:45:58.000000','2026-02-08 13:45:58.000000',1,13,1,1,'N'),(70,'Camiseta vermelho claro Tommy Hilfiger jeans','P',0.00,159.900,'Loja física',1,'2026-02-08 13:45:58.000000','2026-02-08 13:45:58.000000',1,1,1,1,'N'),(71,'Vestido azul com estampa de âncora','M',0.00,79.900,'Loja física',5,'2026-02-08 13:45:58.000000','2026-02-08 13:45:58.000000',1,10,1,1,'N'),(72,'Moletom Levis','P',0.00,269.000,'Loja física',7,'2026-02-08 14:29:17.000000','2026-02-08 14:29:17.000000',1,9,1,1,'N'),(73,'Jaqueta The North Face','MG',0.00,349.000,'Loja física',8,'2026-02-08 14:29:17.000000','2026-02-08 14:29:17.000000',1,14,1,1,'N'),(74,'Fleece TNF','36',0.00,299.000,'Excel Import',8,'2026-02-08 19:04:38.000000','2026-02-08 19:04:38.000000',1,14,2,1,'N'),(75,'The North Face azul','36',0.00,299.000,'Excel Import',8,'2026-02-09 14:23:39.000000','2026-02-09 14:23:39.000000',1,14,1,1,'N'),(76,'Lice rosa Columbia','M',0.00,249.000,'Excel Import',1,'2026-02-09 14:23:47.000000','2026-02-09 14:23:47.000000',1,13,1,1,'N'),(77,'Casaco preto Columbia','GG',0.00,99.000,'Excel Import',9,'2026-02-09 14:23:55.000000','2026-02-09 14:23:55.000000',1,13,1,1,'N'),(78,'Vestuário','G',10.00,10.000,'Loja física',18,'2026-05-23 03:00:00.000000','2026-05-23 15:03:33.000000',1,10,1,1,NULL);
/*!40000 ALTER TABLE `Produto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ProdutoGrupo`
--

DROP TABLE IF EXISTS `ProdutoGrupo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ProdutoGrupo` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Descricao` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProdutoGrupo`
--

LOCK TABLES `ProdutoGrupo` WRITE;
/*!40000 ALTER TABLE `ProdutoGrupo` DISABLE KEYS */;
INSERT INTO `ProdutoGrupo` VALUES (1,'Camisetas'),(2,'Camisas'),(3,'Calças'),(4,'Shorts e Bermudas'),(5,'Vestidos'),(6,'Saias'),(7,'Blusas'),(8,'Jaquetas'),(9,'Casacos'),(10,'Tops'),(11,'Roupas Íntimas'),(12,'Roupas de Dormir'),(13,'Roupas de Banho'),(14,'Acessórios'),(15,'Bolsas'),(16,'Calçados'),(17,'Brinquedos'),(18,'Outros');
/*!40000 ALTER TABLE `ProdutoGrupo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ProdutoMarca`
--

DROP TABLE IF EXISTS `ProdutoMarca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ProdutoMarca` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Descricao` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProdutoMarca`
--

LOCK TABLES `ProdutoMarca` WRITE;
/*!40000 ALTER TABLE `ProdutoMarca` DISABLE KEYS */;
INSERT INTO `ProdutoMarca` VALUES (1,'Tommy Hilfiger'),(2,'GAP'),(3,'Michael Kors'),(4,'Lança Perfume'),(5,'GUESS'),(6,'Adidas'),(7,'Nike'),(8,'Carmen Steffens'),(9,'Levis'),(10,'Outros'),(11,'Felini'),(12,'Animale'),(13,'Columbia'),(14,'The North Face'),(15,'Le Lis Blanc'),(16,'Zara'),(17,'Farm');
/*!40000 ALTER TABLE `ProdutoMarca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ProdutoPerfil`
--

DROP TABLE IF EXISTS `ProdutoPerfil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ProdutoPerfil` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Descricao` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProdutoPerfil`
--

LOCK TABLES `ProdutoPerfil` WRITE;
/*!40000 ALTER TABLE `ProdutoPerfil` DISABLE KEYS */;
INSERT INTO `ProdutoPerfil` VALUES (1,'Adulto'),(2,'Infantil'),(3,'string'),(4,'string'),(5,'string'),(6,'string');
/*!40000 ALTER TABLE `ProdutoPerfil` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ProdutoStatus`
--

DROP TABLE IF EXISTS `ProdutoStatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ProdutoStatus` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Descricao` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProdutoStatus`
--

LOCK TABLES `ProdutoStatus` WRITE;
/*!40000 ALTER TABLE `ProdutoStatus` DISABLE KEYS */;
INSERT INTO `ProdutoStatus` VALUES (1,'Estoque'),(2,'Reservado'),(3,'Vendido'),(4,'Pago - Aguardando Retirada'),(5,'string'),(6,'string'),(7,'string'),(8,'string');
/*!40000 ALTER TABLE `ProdutoStatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Role`
--

DROP TABLE IF EXISTS `Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` longtext DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IX_Role_name` (`name`),
  KEY `IX_Role_is_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Role`
--

LOCK TABLES `Role` WRITE;
/*!40000 ALTER TABLE `Role` DISABLE KEYS */;
INSERT INTO `Role` VALUES (1,'MANAGER','Gerente com acesso a produtos, estoque e pedidos',1,'2025-08-07 20:15:55.000000','2025-10-26 01:05:43.040922'),(3,'SELLER','Vendedor com acesso a vendas e visualização',1,'2025-08-07 20:15:55.000000','2025-08-07 20:15:55.000000'),(4,'VIEWER','Apenas visualização de dados',1,'2025-08-07 20:15:55.000000','2025-10-28 01:08:39.078304'),(5,'ADMIN','Administrador',1,'2025-10-19 02:30:21.924099','2025-10-27 22:41:53.908404');
/*!40000 ALTER TABLE `Role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RolePermission`
--

DROP TABLE IF EXISTS `RolePermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RolePermission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IX_RolePermission_role_id_permission_id` (`role_id`,`permission_id`),
  KEY `IX_RolePermission_permission_id` (`permission_id`),
  CONSTRAINT `FK_RolePermission_Permission_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `Permission` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_RolePermission_Role_role_id` FOREIGN KEY (`role_id`) REFERENCES `Role` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RolePermission`
--

LOCK TABLES `RolePermission` WRITE;
/*!40000 ALTER TABLE `RolePermission` DISABLE KEYS */;
INSERT INTO `RolePermission` VALUES (32,5,19,'2025-10-27 22:41:54.131708'),(33,4,2,'2025-10-28 01:08:39.337513');
/*!40000 ALTER TABLE `RolePermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TipoEndereco`
--

DROP TABLE IF EXISTS `TipoEndereco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TipoEndereco` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Descricao` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TipoEndereco`
--

LOCK TABLES `TipoEndereco` WRITE;
/*!40000 ALTER TABLE `TipoEndereco` DISABLE KEYS */;
INSERT INTO `TipoEndereco` VALUES (1,'Residencial'),(2,'Comercial'),(3,'Outro');
/*!40000 ALTER TABLE `TipoEndereco` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL DEFAULT '0001-01-01 00:00:00.000000',
  `Email` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `Name` varchar(100) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `updated_at` datetime(6) NOT NULL DEFAULT '0001-01-01 00:00:00.000000',
  `PessoaId` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IX_User_email` (`Email`),
  KEY `IX_User_created_at` (`created_at`),
  KEY `IX_User_is_active` (`is_active`),
  KEY `IX_User_PessoaId` (`PessoaId`)
) ENGINE=InnoDB AUTO_INCREMENT=213 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES (4,'2025-08-07 20:24:35.000000','admin@abrechozeira.com',1,'administrador','$2a$11$2svI1eSVMi/OLMrf1zqHOOYCq.oyp70.uLirCVNIgVrnEwML33RE2','2026-06-15 15:59:39.006103',1),(14,'2025-10-28 02:20:36.032079','sarah@abrechozeira.com.br',1,'sarah','$2a$11$uQNETGVUNuaJcly4tB6YSu6O19jLudhD3qRci3DeUPLt/vzVShq3q','2026-06-28 10:10:39.221687',3),(15,'2026-05-23 16:44:48.751199','eduardo.cwbnet@gmail.com',0,'Môlagra Karoline de Goes ','$2a$11$w6fGkISf.ngrzRkjSRhXguCoOTSPw0y27dc1idIVvg9kX.gdg.Hou','2026-05-23 16:56:26.520129',29),(19,'2026-05-23 19:25:27.478387','pfreisdorfer@gmail.com',1,'Patricia F Reisdorfer Alves ','$2a$11$a.ZXtggKFL.TuS6BebN9YuWN1D66XV6HDCqibnl4q8n59VzE/jzUS','2026-05-23 19:25:27.478388',33),(20,'2026-05-23 19:25:39.416670','jenniferalves1261@gmail.com',1,'Jennifer Alves da Silva','$2a$11$DzLhUmmxSSb1.AZTpmmTROdfXLvycEtPVgSmcOVh2qGWCBSMgvr6m','2026-05-23 19:26:21.483888',34),(21,'2026-05-23 19:26:21.033973','natali.agrimapas@outlook.com',1,'Natali','$2a$11$eWjZMTrzI86MW.qEn4s1Z.X49nY31HdysyBjr0nK2QFgFT7fyindS','2026-05-23 19:29:55.789002',35),(22,'2026-05-23 19:26:34.583139','flavinha_lopes2014@outlook.com',1,'Flavia Cristina Lopes ','$2a$11$bXAtFMaxVLD0pz21CHfEKOXpiDjFOaxpaN5T5aIhLWaQL89RLIFkG','2026-05-23 19:26:34.583140',36),(23,'2026-05-23 19:27:41.506488','leisidegan@hotmail.com',1,'Leisiane Degan ','$2a$11$WY5fLl8CQlXEiOC4FcI52OCfYSYTKT3ieGQRzVT3XNVlKozgrjlHm','2026-05-23 19:27:41.506489',37),(24,'2026-05-23 19:27:57.859239','katisolek@outlook.com',1,'Katielle Solek ','$2a$11$6oa3pdAYhhD6Ws81./goLuSP7ke9wC8Ung7sPc2ZN/yGGJ3FPYgoW','2026-05-25 19:05:27.965540',38),(25,'2026-05-23 19:28:11.288950','telmareis212@gmail.com',1,'Telma Ruth Silva Reis ','$2a$11$TI5YIK4HKyCui5VipQVYgeFibZzei3nXn8O4PyE9bmlI3PoS8qo06','2026-05-23 19:28:11.288950',39),(26,'2026-05-23 19:28:27.473296','magillian19@gmail.com',1,'MARCELA GILLIAN LOPES','$2a$11$xE9PldvCFRxCpQh.vGBHUO1YiDi5ZZ08TrsSeEMBWSfQTGqtSNiCK','2026-05-23 19:28:27.473296',40),(27,'2026-05-23 19:28:39.770277','pgvc91@gmail.com',1,'Patrícia Gomes Vidal Corrêa ','$2a$11$0XviWDIZrbaKZ5JGol4jQOyFRTXe.6mEHagIC2Rw2RO.E/feld.Yq','2026-05-23 19:28:39.770278',41),(28,'2026-05-23 19:29:08.391573','pamelaluavieira@yahoo.com.br',1,'Pamela Cristina Vieira','$2a$11$NpuoAAPCNlvEr.QZasSKGeXLY1gbj4WMzVcZ5sSCg7W4PehOZ63wy','2026-05-23 19:29:08.391574',42),(29,'2026-05-23 19:30:11.396801','prikafariaalves@hotmail.com',1,'Priscila Faria Alves','$2a$11$01NPdgR2tLh3..7nwcOs2eOt2C//X7x8oTdO02jyVwD28S/9qGw4W','2026-05-23 19:30:11.396802',43),(30,'2026-05-23 19:31:07.394898','miriam_asano@hotmail.com',1,'Miriam H. Asano','$2a$11$TxGl9lYgCdf95JIklV/Hluxn4/2f/QiPxQKCKL5mCrd6.O46a4m2e','2026-05-23 19:31:07.394899',44),(31,'2026-05-23 19:33:40.517461','Saleteaquinocc@gmail.com',1,'Raimunda Salete Sá de Morais Aquino ','$2a$11$6ztnCSwLPuxeaNdmYPWGZehxI/7QHUkgOs59lMQDjQj2NtGQNRE3K','2026-05-23 19:33:40.517462',45),(32,'2026-05-23 19:36:44.451323','carolacad@hotmail.com',1,'Carolina Vieira Coimbra Botinha ','$2a$11$JoiiGKDHH6QrGtx0/cUcL.uLcd4VaSpE1gEFZgLox/6THmsYdeLya','2026-05-23 19:38:25.310724',46),(33,'2026-05-23 19:38:20.513618','amdeschk@hotmail.com',1,'Ana Maria Deschk','$2a$11$zacVnU4HL9AMRWc7RY6VnOCUnxn3jUixZvivyRqWloweoUvwpRxj6','2026-05-23 22:43:22.276324',47),(34,'2026-05-23 19:38:29.475461','ketlouise@gmail.com',1,'Kethlyn Louise monteiro','$2a$11$wSSq1oTtNHLWBWV2lkiLA.p3qwFNfZkPXq1q0I9GSsPiikYFtPwEq','2026-05-23 19:39:50.574428',48),(35,'2026-05-23 19:40:01.485657','fernandadutradealmeida@gmail.com',1,'Fernanda Trindade Dutra de Almeida','$2a$11$tosFcAEHn4GANFV9A5rWzOAtkI3BircyMqgEZx9LGYt1NGjL3Azb6','2026-05-23 19:40:01.485657',49),(36,'2026-05-23 19:42:31.461503','simoneeder75@gmail.com',1,'Simone Eder','$2a$11$9UfLdbx7hpSb7JYkeD9ENuCL98tLFL2DXsMHigox/caj/zEa.B/a2','2026-05-23 19:44:07.656835',50),(37,'2026-05-23 19:42:38.212412','anielelsouza@gmail.com',1,'Aniele Lima de Souzw','$2a$11$Mz0FeJnF2t9HsrV70f3mr.98vNxOJfWRuWEbj0RiwBmnueFsrCZ7m','2026-05-23 19:42:38.212412',51),(38,'2026-05-23 19:47:13.842662','sabrinaantonioli5@gmail.com',1,'Sabrina Antonioli','$2a$11$9iaJSnj5AClU7NxvF0g0De5XggPRMQnMMPQwaklX5NRmMh6oxTRq2','2026-05-23 19:47:13.842663',52),(39,'2026-05-23 19:49:45.263671','kallencmf@gmaul.com',1,'Kallen CHRISTIANY Miranda Ferreira','$2a$11$TpzMTnY5F8JsrjnRLy8nsei2SzKnkSMJSxI2pzAkgm79e4cRbsT9u','2026-05-23 19:49:45.263672',53),(40,'2026-05-23 19:51:28.002045','bellopamela@gmail.com',1,'Pamela Bello','$2a$11$014Z.sw5DLWmr8tfl72bq.t2khuUCYWnjG3UvaO..DpRkSMx4bn4m','2026-05-23 19:52:31.697981',54),(41,'2026-05-23 19:54:47.845788','pacarzino@gmail.com',1,'Paola Carzino ','$2a$11$UWGD4YBhM0nltSzL/yrNhuQwEdFFpFcnwJt9SR4aOiXNOzzQHy/n.','2026-05-23 19:54:47.845788',55),(42,'2026-05-23 20:00:42.668104','lahokama@yahoo.com.br',1,'Larissa Hokama ','$2a$11$U6iyh2Lf9lR1FihKwQEJ6e65q6dH5IpPAoWbts9kehKv0j6K/PlYa','2026-05-26 21:40:53.024705',56),(43,'2026-05-23 20:01:55.123668','carolinebrando@gmail.com',1,'Caroline Silva Brandão ','$2a$11$G.akLbMBBuIZsdIG2tU6jOhmamR.wGTRihXTGVLdc73fqh1U5s2ee','2026-05-23 20:01:55.123668',57),(44,'2026-05-23 20:03:06.852735','patriciacorrea.grhucsal@gmail.com',1,'PATRICIA CORREA DE BRITO ','$2a$11$T6EdakIHCZpb3lZP9FUyheUEhasJ/BPAB/WT2OUyFt/9gd90QzjR.','2026-05-23 20:03:06.852735',58),(45,'2026-05-23 20:06:03.671018','neucivianaolive@gmail.com',1,'Neuci Oliveira ','$2a$11$T5T2o2EbKZm/ZBw0Wfu9LuRMsCOt0VceNVHr4h8I/NVd/6RFzKv92','2026-05-23 20:06:03.671019',59),(46,'2026-05-23 20:06:15.318638','hawyankannik@gmail.com',1,'Nicholle Hawyanka','$2a$11$KXUY.2Pq4p9Fc1pUq.VG9uHyexk/ToQrxKLBIEetJkktM8avZBKNa','2026-05-23 20:06:15.318639',60),(47,'2026-05-23 20:07:57.646307','jupenaloza@gmail.com',1,'Juliana Alejandra Penaloza Kozak ','$2a$11$tk8.6QXZNLBb5I6jaf8ud.LugN2Mu4SnUFBh9qhmV.XpQDHgBPR5G','2026-05-23 20:07:57.646332',61),(48,'2026-05-23 20:09:09.614607','luana_fidelis@hotmail.com',1,'Luana Fidelis da Silva Stanislavski ','$2a$11$twaHAhfmswt/7pv1Udm8Y.j1P/mI4vejice3DVc.jfFlfQXoJBOIS','2026-05-25 17:49:09.974806',62),(49,'2026-05-23 20:13:40.520690','neticia4@hotmail.com',1,'Carla Letícia Mendes','$2a$11$GdQKrkE3TpcOvKZnOGXF4.qz7sg2B6hEfAr3UtiMW2giPbMPi3CDu','2026-05-23 20:13:40.520690',63),(50,'2026-05-23 20:18:11.712334','liginhateixeira@hotmail.com',1,'LIGIA OLIVATTO RODRIGUES TEIXEIRA','$2a$11$gJbsY2Ryny.wpOMVcCyz2Ol2apZtfc.DqKXQTkKGimOEMR84YwIcS','2026-05-23 20:18:11.712335',64),(51,'2026-05-23 20:19:11.507352','souusa.rodrigues@gmail.com',1,'Fernanda Rodrigues de Sousa ','$2a$11$nloubLlYmctNODwWXdpuaOqw8KPqNfCDP67xU1hqys/jrXGJ3QNAK','2026-05-23 20:19:11.507353',65),(52,'2026-05-23 20:33:09.183575','nicollesartori@hotmail.com',1,'Nicolle Roxo Sartori','$2a$11$k4df/zaih7X5lMFriWORj.SIrX6GV6iSBtSadG8Ykgvws0MiiF1m.','2026-05-23 20:33:09.183601',66),(53,'2026-05-23 20:39:31.132538','molagra_karoline@hotmail.con',1,'Môlagra Karoline de Goes','$2a$11$A.mYPprbrXn4FrFvPppIfumzOQK7jHcRvnbZfOaRn4QoelDjeeCEK','2026-05-23 20:39:31.132538',67),(54,'2026-05-23 20:48:00.706647','myxamorim@gmail.com',1,'Michelly de Amorim Silva paschoal','$2a$11$d2dfdJPDvq0OXNUe3c.yk.xPFvXaIRwiZlRVljFSLLEyymQzqJCeu','2026-05-23 20:48:59.630154',68),(55,'2026-05-23 20:48:02.798677','maria.kz@hotmail.com',1,'Maria Júlia Corrêa Lima ','$2a$11$dE9uLEPCQh9u1eTRmTYQO.fn2SyooRnDuOpoJE.dGn/.87wHZfC66','2026-05-23 20:48:02.798678',69),(56,'2026-05-23 20:49:36.391436','adrianaamello@hotmail.com',1,'Adriana Antunes de mello ','$2a$11$h.21tc0.el4UWv1.5Zh12u5QJUxo7Icwykze6Gsp/1ccEJp/y0q1S','2026-05-23 20:49:36.391437',70),(57,'2026-05-23 20:53:41.584617','drasabrina_oliveira@hotmail.com',1,'Sabrina Oliveira do Nascimento ','$2a$11$ROQr8qS6SvATgnv.VaEbsuYBGwssfHOk8h6Z1VfPxezfT7K8pZVUe','2026-05-23 20:53:41.584634',71),(58,'2026-05-23 21:02:31.075041','leandroeletrica1@hotmail.com',1,'Francine peres vefago ','$2a$11$fDG9WWpTThcxPCAz.YtZaum0gTrLu.5Lyw12qwx86FQ78D3vDjjEO','2026-05-23 21:02:31.075063',72),(59,'2026-05-23 21:04:18.365202','ana-paula-2608@hotmail.com',1,'Ana Paula Rosa dos Santos Cardozo ','$2a$11$zUcYYCHUgV4D/oYLDlDzbeg2rmecHqf.mtrLoysw7KHZLGJYPNdJ2','2026-05-23 21:04:18.365220',73),(60,'2026-05-23 21:06:07.526646','paty.gil@hotmail.com',1,'Patricia Gil Martins dos Santos ','$2a$11$vmsP1d.nVsR3vZqxZUVWzu9/mX5kWFw5nuB.WH3b2WEMqu2oEdH5W','2026-05-23 21:06:07.526647',74),(61,'2026-05-23 21:15:48.737717','telmathomazf@hotmail.com',1,'Telma Thomaz ','$2a$11$fbxLEN2I9CncpULa.GOB/.m8sjQQ1/mi/WFk2zNMhsSYB5NTnDYEy','2026-05-23 21:15:48.737717',75),(62,'2026-05-23 21:16:42.237334','luzialitvin@yahoo.com.br',1,'Luzia Litvin','$2a$11$yKRfBgUPWD0kJcz878FXxe2ES85cDV6djhqPhu8nGj3b4sJDCutWe','2026-05-23 21:16:42.237335',76),(63,'2026-05-23 21:19:32.570175','kkvieira@gmail.com',1,'Karin Chiuchetta ','$2a$11$CWo/iSHTJeKXLg9msuVU6us49reiFDMUlwN7z1CLZl9VDfFE/gr1S','2026-05-23 21:19:32.570175',77),(64,'2026-05-23 21:22:27.044688','amanda.teixeira8@icloud.com',1,'Amanda Gelenski Teixeira ','$2a$11$DZyHO1siSqkmDknVzVik..A6.yCPTfPLnusOp1bUhLTP1Mr/fF64y','2026-05-23 21:22:27.044688',78),(65,'2026-05-23 21:23:58.975239','aretusamoraes@hotmail.com',1,'Aretusa Moraes','$2a$11$Ht1QtXz1FX83F7zNHX5PMuVz5XBWDWtzqc6tdF67RVq0t2FSL6ZvO','2026-05-23 21:23:58.975239',79),(66,'2026-05-23 21:25:08.385738','michellestempniak@hotmail.com',1,'Michelle stempniak','$2a$11$Edo7X2yMRrsRZ8hqtKb1vOOvSDXeVhf31CqqBIHytz9g.u3dmNyoK','2026-05-23 21:25:08.385739',80),(67,'2026-05-23 21:26:03.153751','irasarges@hotmail.com',1,'Iraci souza de sarges gavron ','$2a$11$RQvOL4mMuTxB7xd7hQWE8O4/GL.6NpV4TtGE4zXtWXrxwnYzFmHqW','2026-05-23 21:26:03.153752',81),(68,'2026-05-23 21:27:44.688493','elisangela-lima@hotmail.com.br',1,'Elisângela lima','$2a$11$qldcRkB2tGJdh6r2zkDw7udzsA51pZAuKhabq6fwMoQhKp0Ta4lSG','2026-05-23 21:27:44.688493',82),(69,'2026-05-23 21:31:10.174652','naanobasam@hotmail.com',1,'Ana Lucia Silva de Oliveira ','$2a$11$9IgEbDIQthTdI6URro4XYeMo0XunYtjLuRzCImi9d9hDowGAkJ0JC','2026-05-23 21:31:10.174653',83),(70,'2026-05-23 21:43:48.877014','carolzinha_0411@hotmail.com',1,'Ana Carolina Ferreira de Sá Melo','$2a$11$tQ7bAdCj8mbC1GMEdNynL.w8.9f1VN3OSjoxbjVVNlhrsCAMkDqJS','2026-05-23 21:43:48.877015',84),(71,'2026-05-23 21:45:05.742440','caroline.schossler@gmail.com',1,'Caroline schossler ','$2a$11$hfMgYARUSQR2GNubnloiPOkBsB.9Jo/cCSFkzcq8ubp3WfRrMRqTa','2026-05-23 21:45:05.742441',85),(72,'2026-05-23 21:46:06.148034','karla.fernanda.benetti@gmail.com',1,'Karla Fernanda Gomes Benetti','$2a$11$0TDgmNC4HhKMFKNpp7W6Dub9dCXKNiOXoYbar/PIAniEaMo867IR.','2026-05-23 21:46:06.148035',86),(73,'2026-05-23 22:00:20.670067','beatrizcs28@outlook.com',1,'Beatriz Cavalcante da Silva ','$2a$11$d/GsvfALyCv6hSmd1sILteuy.kkGLmjy9BPh.hPlVJtz8iqE9TLwa','2026-05-23 22:00:20.670068',87),(74,'2026-05-23 22:06:29.418121','rsafanelli@hotmail.com',1,'Rafaella Safanelli ','$2a$11$D/ndWXzrGNbhd27KiWSvnu9aDYC0JTTbRHhdBnyB3mPtj8RDIXQ7K','2026-05-23 22:07:17.250038',88),(75,'2026-05-23 22:10:43.832794','ranchil.pati@hitmail.com',1,'Patricia Cristiane de Almeida Ranchil','$2a$11$t/BMzjBUo4UYfXBOCir8nebYKnR4lDHQzRwCdhMvV7a4sLEAoMgFS','2026-05-23 22:10:43.832795',89),(76,'2026-05-23 22:30:06.903230','adrialmeida01@gmail.com',1,'Adriele Pires  de Almeida ','$2a$11$PcXlT1Ov/1rVGpP7mGWkcegt6WayKX.7fcOmFF4mP9Xk3T9XNumGG','2026-05-23 22:31:16.227505',90),(77,'2026-05-23 22:32:07.278765','saralourenco001@gmail.com',1,'Sara Lourenço ','$2a$11$V2OSIAvuA9M8A6c6QoXaZuAufyDiHkoHn8dxFtmtdUAKTeDLfXnze','2026-05-23 22:32:07.278765',91),(78,'2026-05-23 22:35:56.793949','daibrasill@hotmail.com',1,'Daiane Brasil Dutra ','$2a$11$lzjrbdzmy5fk0IhCKYur9uCgwzG1NlkjkICgA0WIeoMYGgTl16NQG','2026-05-23 22:35:56.793950',92),(79,'2026-05-23 22:49:45.843791','scheilacarvalhodosreis@gmail.com',1,'scheila Carvalho Dos Reis','$2a$11$t75ISNXrBAhvnOZq9DJzeumC5/5PsZj8TYVVXeHyWltip7lcMxA8q','2026-05-23 22:49:45.843791',93),(80,'2026-05-23 22:58:15.044335','debo_cris_j@hotmail.com',1,'Débora Cristine Jurkewicz','$2a$11$Rv1m1.p3Cu8q6GBoTaC55OH7s74eNcydTUu6UOp50t3oI2T9lxw7y','2026-05-23 22:58:15.044336',94),(81,'2026-05-23 23:07:06.664411','olivia.santos.ojms@gmail.com',1,'Olivia Jaqueline Moreira dos Santos','$2a$11$.S1APd9Nv87isikcvMLnEOOvpn/wtrNQZuHJa8rq/fmxTHHM6zgvy','2026-05-23 23:10:44.837969',95),(82,'2026-05-24 00:24:07.599278','dani.uriques93@gmail.com',1,'Daniela Ouriques de sousa','$2a$11$Ia.s5XGSnLAFYsJMm9bC6uSA.ADKd1/kOWjERMY1Lyf1/DC2I1kPC','2026-05-24 00:24:07.599279',96),(83,'2026-05-24 12:17:42.102573','amandarocha_08@hotmail.com',1,'Amanda Rosa da Rocha','$2a$11$Xf6sKJ9CqO4ZlYBupXyD..U/NjvojzfKeVmRRlxAmsbUbj5asEmSe','2026-05-24 12:18:28.494787',97),(84,'2026-05-24 16:14:31.485072','suhscotini@gmail.com',1,'SUELEN SCOTINI','$2a$11$hBIJTAtn3YIY0vfQuXDUvOPVwwvzo81TwpcOVBHWzReloJoFoIWW2','2026-05-24 16:14:31.485072',98),(85,'2026-05-24 16:19:41.785577','mnk.fran@gmail.com',1,'Monique Alves ','$2a$11$vfo4hShXkI..BiVjKO5zO.u6m2.WrJRXMZEcpdDkR55dJRqvLmZmu','2026-05-24 16:19:41.785577',99),(86,'2026-05-24 17:05:07.475085','wesleyhenri@icloud.com',1,'Wesley henrique dos santos ','$2a$11$/5zS1p4V.gWk7V1hysCvEulsMy6cxIJGClZCDPGAAZzToTVdtsZgu','2026-05-24 17:05:07.475085',100),(87,'2026-05-24 17:19:51.784637','eduardadeschk@hotmail.com',1,'Maria eduarda Deschk ','$2a$11$1kGy96QbdPmRDX6yVWz4ZuzjWi8CAcqkhlzfA0koWeY5/qQxrZp0q','2026-05-24 17:19:51.784637',101),(88,'2026-05-24 19:22:48.786675','barachoiolanda@gmail.com',1,'Iolanda Baracho de Oliveira','$2a$11$y18qK61uN.GK/yo1E/8iROXz9yBFVuc8kQaqgwL2bu8kmdFiVzpUK','2026-05-24 19:22:48.786676',102),(89,'2026-05-24 20:14:09.750472','annebarbosam@gmail.com',1,'Anne Mery Barbosa Martins','$2a$11$kM9SetlC44iuGpDHsf2M7.hPoG7azkvcOxrbo819q9Qz.HJ2z4KZC','2026-05-24 20:14:59.843509',103),(90,'2026-05-24 20:53:49.273999','caamimarin@hotmail.com',1,'Camila Marin @','$2a$11$Yyft/ehd4JA6dsbEOPkz3efyUTthTkkvRYoKziVeIdRq7pc9LWg1i','2026-05-24 20:53:49.274000',104),(91,'2026-05-24 22:03:52.128287','celine.pente@gmail.com',1,'Olinda Penteado','$2a$11$sZyQZDWlCo25Fc8sqfAd0ehfHKdWUY4vXejhd5tcYLN.syZGH0V86','2026-05-24 22:03:52.128288',105),(92,'2026-05-24 22:29:29.097509','alessandrabrito94@hotmail.com',1,'Alessandra Brito Nanci','$2a$11$WgqzRNt/guy1zNj0xQ3OWuW533Ar19.6j4cVJSQL6BlJNWon6R06m','2026-05-24 22:29:29.097510',106),(93,'2026-05-24 22:44:11.775524','monikypedagogia@gmail.com',1,'Moniky Carla mohr ','$2a$11$pRUh4ihiMvMvjOPVYAUU1OGe/tiRuCvvho7GYKpOBYkJMhWMD120K','2026-05-24 22:44:11.775524',107),(94,'2026-05-24 22:56:53.542177','leticiamarcon2@gmail.com',1,'Letícia Marcon ','$2a$11$B9IE0XPfAgXKzqydeYIyheZiN9W3ruEut6ZptHeshcJNQZkQ.qxe6','2026-05-24 22:56:53.542178',108),(95,'2026-05-24 22:58:45.653651','carolinebchagas@gmail.com',1,'Caroline Buch Chagas ','$2a$11$4WFv.aPQRwmiMi/ToT/ZhupuGtio7vgJ3e1oCTFC.R7KhgYyVN2W6','2026-05-24 22:58:45.653651',109),(96,'2026-05-24 22:59:47.859007','keicymiguelloretti@gmail.com',1,'Keicy Loretti ','$2a$11$5Jox3.4trGU/6Kk8htl3fegtUrigP2vGqtENkr4Cm3gOywnTDvCSO','2026-05-24 22:59:47.859008',110),(97,'2026-05-25 00:15:53.316208','cacau5br@gmail.com',1,'Catia Simone Fernandes Machado ','$2a$11$WIRR4DxdYlttg5Pwga4hHu9hvbK2vB.zTu0hgFxogtv7aC6pZSVUW','2026-06-16 13:50:45.568732',111),(98,'2026-05-25 01:16:14.897130','flaviaharckbart@gmail.com',1,'Flávia Harckbart de Oliveira ','$2a$11$G6JiEyBMgAf4Hb/id.390utAo7fRHU94eXVCJa0h7QE6xE3251AmK','2026-05-25 01:16:14.897131',112),(99,'2026-05-25 09:53:03.712079','tbruna225@gmail.com',1,'Bruna Thays Venancio ','$2a$11$LQrMlvqhPRogYFBGt8vodOWS9OQvGn3/WjWaMBoZ9e4Zt89.nMpk6','2026-05-25 09:53:03.712079',113),(100,'2026-05-25 11:00:59.787846','silvianes.freitas01@gmail.com',1,'Silviane dos Santos Freitas ','$2a$11$ojxAKQDaz7KPbgnwZ4eVt.p3VSasbDS2qRYWHfvq/4sKoFgVXZLxi','2026-05-25 11:00:59.787846',114),(101,'2026-05-25 11:18:05.947585','fatisonia@gmail.com',1,'Sônia Gai Coimbra ','$2a$11$.mvJdYz0FymALNDiW01xOumT9Ow4SowB6zzhJJczokceLvebnACY6','2026-05-25 11:18:05.947586',115),(102,'2026-05-25 11:59:14.151446','thamirishartmann92@gmail.com',1,'Thamiris Hartmann','$2a$11$u4l62KIymMaLc3Xpn2.6bOWLl7kzW/6X3YUewdq6hOtiSwWSPedzO','2026-05-25 11:59:14.151447',116),(103,'2026-05-25 12:15:55.198463','Lidi_luz@hotmail.com',1,'Lidiane Lara da Luz','$2a$11$ZILwpBjI3XLFuuEDTqwDc.2ieOY.ZiMjlIDh19qhP/9rbXBVjZ9aO','2026-05-25 12:15:55.198463',117),(104,'2026-05-25 12:30:36.192982','farmajanicekrauss@gmail.com',1,'Janice Malicheski Krauss ','$2a$11$xS/xT.la3WOJKLSSD.KEzeTb2gIJQ/OogK3kuI7wAqBkN7PjfaFVO','2026-05-25 12:30:36.192982',118),(105,'2026-05-25 13:27:25.060641','vanessa.filipini@yahoo.com.br',1,'VANESSA REINSTEIN ALNOCH','$2a$11$s/WHdVtOC4bdQdSwQgzWjuQQFZa1V9mV.cQUzt.VrAbn0C.x/F9CO','2026-05-25 13:27:25.060642',119),(106,'2026-05-25 13:49:25.136364','lisi.schell@hotmail.com',1,'Lisiane dos Santos Schell','$2a$11$GrI7orgcTOxm0OOt19bjeO7tFw9ho1ILXGoebwgO09SWb1ADSKe72','2026-05-25 13:49:25.136364',120),(107,'2026-05-25 15:38:27.747268','daianekujbida@hotmail.com',1,'Daiane dos Santos Kujbida ','$2a$11$msLlvr9HARXcSTQSz5mTyuCDu0XZYRHrISjWMKwLzeA7MgeDp2hFe','2026-05-25 15:38:27.747269',121),(108,'2026-05-25 15:46:35.821854','louisepeixotogomes@gmail.com',1,'Louise Peixoto Gomes','$2a$11$kjXHcgwp0hL4R135wDmD/urmj1T.pvD.AETg/bh1T1OQYLmCMb1SK','2026-05-25 15:46:35.821855',122),(109,'2026-05-25 15:47:25.844592','twardowskiizabela74@yahoo.com',1,'Izabela dos Santos Twardowski ','$2a$11$Di3l8PARInz2RHs/L1ezL.Yt5uhYgufr0TdJmp4wUBGfYRFO74YwG','2026-05-25 15:47:25.844592',123),(110,'2026-05-25 15:59:16.009832','julianaalves_ml@hotmail.com',1,'Juliana Alves Guedes','$2a$11$ixpDdYMC6oKQOYuun5bVvOdpBWtXWyhM0CCCxLcMVGfcm4l57FNKO','2026-05-25 15:59:16.009832',124),(111,'2026-05-25 17:40:04.164388','pri.bijoux@hotmail.com',1,'Priscila Martins ','$2a$11$vD4cP54OoE57pPtHrx.HwuF7zzK4cp9P6ygD2ptjq8W80sNHBs3bi','2026-05-25 17:40:04.164415',125),(112,'2026-05-25 17:40:47.860937','dani77_rosa@outlook.com',1,'Daniela Fernandes Rosa ','$2a$11$YAmZhcUXr0oMGRr.09W6muoMkj2OecFHOVspgtZNqzyf4RqHzySey','2026-05-25 17:40:47.860937',126),(113,'2026-05-25 17:42:04.055985','priscilabonaccorsi@yahoo.com.br',1,'Priscila bonaccorsi ','$2a$11$9BLltgd.7rNo9Wx1qdTx1uyWqTEckPQrR81x5VVIYPUveLdHTSjgq','2026-05-25 17:42:04.055986',127),(114,'2026-05-25 17:44:42.081163','thaislmiranda@hotmail.com',1,'Thais Priscilla Leite de Miranda Mendes ','$2a$11$bwi2jwJcnNHX9v10LmgX.eRIiT3R4b3x1vL/B.tLTpdBpIn.h7Bw6','2026-05-25 17:44:42.081163',128),(115,'2026-05-25 17:44:52.795029','thaishss@gmail.com',1,'Thaís Helena dos santos soares ','$2a$11$3ju/u/3GBx7YVmIq9xDsz.r9pmmD7ZfbJQzEn90LFcX1PmZJDEsCm','2026-05-25 17:44:52.795030',129),(116,'2026-05-25 17:45:09.556365','teacherlediane@gmail.com',1,'Lediane Manfé de Souza','$2a$11$bkd90qm74yqYLbCBbIZV1.ppI81Og1p7bFZE9iaCp/JuIK1U1Ctx.','2026-05-25 17:45:09.556366',130),(117,'2026-05-25 17:47:18.593571','angelicaferretti@yahoo.com.br',1,'Angélica Ferretti Martins','$2a$11$XQEVuY2ev68ixMXRy2PN6OS6mJvrEQEFGv1MEbvZOKWyNt7BA8ZiS','2026-05-25 17:47:18.593572',131),(118,'2026-05-25 17:47:33.699763','paula2311ana@gmail.com',1,'ANA PAULA ALEIXO','$2a$11$720k/FPBrmzM6S7WfVQrQ.ajgapO1CNmunCVZPk8Wc61KiJYz70TO','2026-05-25 17:47:33.699763',132),(119,'2026-05-25 17:48:05.171015','claudiareni.cc@gmail.com',1,'Claudia Reni Cardoso ','$2a$11$ff5cyfF2KWN1UkvdJ1cy2OTFeOR3EUoonimF2m10jFKrYR3LvE7q2','2026-05-25 17:48:05.171016',133),(120,'2026-05-25 17:50:59.385570','milabenetti@gmail.com',1,'Camila Benetti Birk','$2a$11$G5XfRKy9LCqmXx/u5T4peevfQzWvmufySCH5C67pcf8AlPC8SUXbG','2026-05-25 17:50:59.385571',134),(121,'2026-05-25 17:51:00.301473','anapaulasouzz89@gmail.com',1,'Ana Paula Pirolli','$2a$11$DPv5nxarLX4Wi2hUuD/E5eELuz2McrVej8nbKHElWqj1hcgvio.hK','2026-05-25 17:51:00.301474',135),(122,'2026-05-25 17:51:44.052345','carla.andrada@gmail.com',1,'Carla Andrada','$2a$11$nHgn1AoiGy7EIaoO2m/I/uT1VlqWYE3B6adjAucCER.ymauwfZ4rq','2026-05-25 17:51:44.052346',136),(123,'2026-05-25 17:55:17.571140','bacolonetti@gmail.com',1,'Bruna Alves Colonetti Nunes','$2a$11$GB3XvAqorddZxi87xJb0ie/Zo737g2I9iSHkM7f.gzCwl9ewPLYha','2026-05-25 17:55:17.571140',137),(124,'2026-05-25 17:59:17.260793','deboragoncalves.dgs@gmail.com',1,'Débora Gonçalves Jientara ','$2a$11$VmpW/B5W87iqcFudTX77l.0u7UXiHWprR9gzMeIgDtboFiq6FFE9G','2026-05-25 17:59:17.260793',138),(125,'2026-05-25 18:04:20.130577','rjjvmp@gmail.com',1,'Regiane Sousa ','$2a$11$g8ODQc.XNipayFmlPJXwX.6wWvkhlBlcU5YCC8S34zfrgMFvAljHq','2026-05-25 18:04:20.130578',139),(126,'2026-05-25 18:04:21.129456','giu.marmorariageogran@gmail.com',1,'Giuliana Delaneza ','$2a$11$VCeu1ummH4RecW9yCA5bm.3tAikCI8M6j2CR6C8uYS0.05hOEqfR6','2026-05-25 18:04:21.129457',140),(127,'2026-05-25 18:17:39.984453','andressaxscarrijo@hotmail.com',1,'Andressa Souza','$2a$11$G1qBtNYKBTecAHIkhEcJ0e5pC.FSGLraD5x2u/F7Sq9k62X8jSSJO','2026-05-25 18:17:39.984454',141),(128,'2026-05-25 18:28:07.021218','raquelbqpimenta@hotmail.com',1,'Raquel Pimenta de oliveira','$2a$11$ZsebzYnlokdLWKvX0gI5.OUSP7yYf4TbOCFHD11IQD4EiIZArgcxW','2026-05-25 18:28:07.021219',142),(129,'2026-05-25 18:47:16.586994','priscila.mvespoli@gmail.com',1,'Priscila Montoya Coutinho','$2a$11$0abWDoK68BrrLrDyJzO7heOqdgyJ/BnPZsxaqNHHNIXgHuC1Mdydm','2026-05-25 18:47:16.586994',143),(130,'2026-05-25 18:49:40.239550','magdecarli@gmail.com',1,'Magda Regina Ferreira De Carli','$2a$11$KmMc33GIb0m8FzIBOnLqZ.nylji948R15tsXYL6LGdADkkxkFcCOK','2026-05-26 02:06:49.001930',144),(131,'2026-05-25 18:51:22.129919','cassia.i.balan@gmail.com',1,'Cassia Balan','$2a$11$Plsivxfp.qnIlwohlD.sE.a68jhZCOWJyJzgk6TqSCQ6V5qbW6u0.','2026-05-25 18:51:22.129920',145),(132,'2026-05-25 18:53:08.217978','arianyprebonato@gmail.com',1,'Ariany Rebonato ','$2a$11$exMUZUz.wQa/yYuLrr0nQeTMwBfhunDX3DAAuUEPdM6Ai9iHCpTzy','2026-05-25 18:53:08.217979',146),(133,'2026-05-25 18:58:49.846799','kulikanne@gmail.com',1,'Anne Kulik','$2a$11$nMeAQppneo2MjXagqKv/LOwksWWe8.59vGDPg0dUQiS.DQgXhoeaO','2026-05-25 18:58:49.846800',147),(134,'2026-05-25 19:11:28.688506','paulinha_filipiak@hotmail.com',1,'Ana Paula Filipiak ','$2a$11$zI./f7G85PLDpmXaUsNJ1eKteRwDUt5AlyejxiwwyUBz9hD3FJYy2','2026-05-25 19:11:28.688507',148),(135,'2026-05-25 19:17:30.696924','jaquezanquini@hotmail.com',1,'Jaqueline Marcato Zanquini ','$2a$11$LBB2dWNGvcpjgfXFnvPc1.z7tFo4lU1oCaLAjc4uXcupi2d4.o086','2026-05-25 19:19:26.208674',149),(136,'2026-05-25 19:20:03.940526','ana.azzolini@gmail.com',1,'Ana Azzólini','$2a$11$VrLl2sa35rQapmqJC4ixeuNw42UDOdpSsnf2jN/8rxnPCBAsw.vIe','2026-05-25 19:20:03.940527',150),(137,'2026-05-25 19:21:39.567492','hrnng91@gmail.com',1,'Samantha Hornung ','$2a$11$kQeT2codARc5n73CK0FW4./QzTbHaYYZu6.XVR9z7GAOb6c9YX2l.','2026-05-25 19:21:39.567493',151),(138,'2026-05-25 19:34:14.534692','elianebenardi10@gmail.com',1,'ELIANE BERNARDI','$2a$11$lczHi9JKscaAsS32ux33heSio3HO0cL7BDlMymhKuFiTlPRLiEUoy','2026-05-25 19:34:14.534692',152),(139,'2026-05-25 21:37:46.035695','marlivjsouza@gmail.com',1,'Marli Terezinha Pinto','$2a$11$etM.3mwbtFG6.dGdZVc3FOPE.poAI2AaqIGIVQH.TZ5zQVDOSpbTS','2026-05-25 21:37:46.035696',153),(140,'2026-05-25 22:12:50.129925','carolina.correasilva@outlook.com',1,'Ana Carolina Correa Silva','$2a$11$SjfLtUmui7JtHNWO2HRvSOOvHBNotKQKazNXPeDp4b4D9XO7laL5u','2026-05-25 22:12:50.129926',155),(141,'2026-05-25 22:28:36.456601','liliakarpinski68@gmail.com',1,'Lilia Marcia Karpinski ','$2a$11$yJMSlqDFqgoR75BV8t/B3u3QhUmkTJs7bPgV5NbWt.78c4n0Q13rq','2026-05-25 22:28:36.456641',157),(142,'2026-05-26 01:11:08.504308','lu.tinkerbell@gmail.com',1,'Luciana Mitsue Nagamati Kido','$2a$11$kEBUIOXXKUW1wrVsFm7G6Ony01tdvMNdByVd5wqQE4D.A3My0fWlq','2026-05-26 01:11:08.504333',158),(143,'2026-05-26 09:57:34.288122','natanepires8@gmail.com',1,'Natane Pires','$2a$11$zmpvO/UOt5APc0XXn8uUQOirndhpScW5cfHXpiAtmOZ1ZnRVOnZKC','2026-05-26 09:57:34.288142',159),(144,'2026-05-26 10:17:03.471761','carolline.manganelli@hotmail.com',1,'Caroline manganelli nagatani','$2a$11$.aMLN7o.72p2nP.GHnfukeoax61jJvznEGA4vMV9DdrqOgwho4dH.','2026-05-26 10:17:03.471761',160),(145,'2026-05-26 11:21:11.479847','vi_chamma2@hotmail.com',1,'Vyvian Chamma','$2a$11$FP1Xlo6haY/Q89z5ehsDOOTYjbupZkLytb/Gd2uIPTFAGGbm8Y0nC','2026-05-26 11:21:11.479848',161),(146,'2026-05-26 17:45:48.823505','nolibos.phi@gmail.com',1,'Juliana Baum Nolibos Leffa','$2a$11$EeqkNyivS5.B1QBM4Nw/s.483xpE6KGLBsKDMJ20nRjZv/BNW71VG','2026-05-26 17:48:32.105431',162),(147,'2026-05-26 18:35:17.347840','flaviacarvalho19@gmail.com',1,'Flavia Carvalho de lima','$2a$11$suJqBnJJMXiGABY7Ubg5PO.HLBmaiO9Ay/qyrzbG7mhJo74ilyOWu','2026-05-26 18:35:17.347845',163),(148,'2026-05-28 12:47:15.181991','luferraz78@gmail.com',1,'Luciana Ferraz de Oliveira ','$2a$11$81q5/XDCmBG.vhMtL3QGge9ujFkB56rkqchRiJfpFLAlDcmsOZZhi','2026-05-28 12:47:15.182017',164),(149,'2026-05-28 20:36:44.135150','angelradol@yahoo.com.br',1,'Angela Radol','$2a$11$1rvJizGRf6brJjeVW1u.r.d7tr/28gKAnFxO7MwyBR3Q58Vu4Ps5K','2026-05-28 20:36:44.135168',165),(150,'2026-05-29 01:52:53.977231','m.viliane@hotmail.com',1,'MARIA VILIANE WACHAK','$2a$11$xCGqlH8ZpEId2SDmGAu2CusVhR9PjaQhPC9RV/IvqalArZAKDEgV6','2026-05-29 01:52:53.977232',166),(151,'2026-05-29 02:29:46.214295','elanaschmitz@hotmail.com',1,'Elana Schmitz ','$2a$11$JCdhB5Us.mamnzWHIqw6wu.wHNkdtEOiZdOjbXFShDypvNQOQEgyS','2026-05-29 02:29:46.214296',167),(152,'2026-05-29 17:15:11.302230','erikafoppel@gmail.com',1,'Erika Moreira Föppel','$2a$11$xq2hxrly7uySEOYNbz6mSeZ1ycTUFt8XCLvi3m.40Xj.0BdzkD2Qa','2026-06-09 20:54:58.387096',168),(153,'2026-05-30 16:55:47.777827','dramariangelaescobar@gmail.com',1,'Mariângela Escobar Gonçalves','$2a$11$6k1hdx62iO.nEdxsGuUymeh3yTAzmtFoE7LxSLY1I7TWspV8ex09G','2026-05-30 16:55:47.777851',169),(154,'2026-05-31 01:13:38.717806','anapicoli01@gmail.com',1,'Ana Gabriela Locatelli Picoli ','$2a$11$UeZPkbyBUhWBUBIQ66yku.UbLVFj0lHVRWDoelP0C12ATjpRS/3hC','2026-05-31 01:13:38.717826',170),(155,'2026-06-01 00:55:24.017318','mario@trxassessoria.com.br',1,'Mario sergio massaki kimura','$2a$11$WLYFcbJUweZfYoguoGd3/uOtdWOQU4c5aDC9rriST2cs8pZqGrjey','2026-06-01 00:56:23.519503',171),(156,'2026-06-01 15:44:32.541367','adilio.oliva@gmail.com',1,'Adílio Borges Oliva ','$2a$11$.kLkuHwh2UhkeO.cQ8UnW.hLnNUU0udrdJ7cFyNnN6LfIdgS81cFu','2026-06-01 15:44:32.541394',172),(157,'2026-06-01 16:43:47.983151','semmerju@gmail.com',1,'Juliana semmer ','$2a$11$7DDlX1j0JHfJQ5Q0bhO0uOJwcsoZcCT7b5C.vgBo9KxiEjX8Z7qV.','2026-06-15 17:35:13.562399',173),(158,'2026-06-01 18:33:48.885639','eduardapzz@hotmail.com',1,'Eduarda Pozzo Ribeiro ','$2a$11$LaYfMFG9oB7ei/zrhWqEweFmGGr8CnB3s/RNMUJ27BG9.EJT.tdiK','2026-06-01 18:33:48.885639',174),(159,'2026-06-01 18:35:29.515728','claudiapassari@gmail.com',1,'Claudia Lima da Silva Passari','$2a$11$LMMZwa43QMpHMLJl9Ex9yufWyZURYWdUG8TE28mMiudi/vJ6vSDwS','2026-06-01 18:35:29.515728',175),(160,'2026-06-01 18:36:07.880873','va.fachinello@gmail.com',1,'VANESSA FACHINELLO SCOTINI','$2a$11$4cS1A5ZbzSbSdl2B9bEvrufUVrgDiOm50zEiBOfLPm7EmLadj9Rta','2026-06-01 18:36:07.880873',176),(161,'2026-06-01 18:37:29.117190','angelamc.ventura@hotmail.com',1,'Ângela Maria Carneiro ','$2a$11$eFSdH4PEUHKRnHBOGpBjZ.xwasgtw5QBZUzB53lwpJJHJWttq6C6S','2026-06-01 18:37:29.117190',177),(162,'2026-06-01 18:40:59.698597','lilian.linke@santander.com.br',1,'Lilian Maria Muller linke ','$2a$11$27kX2vdoJZyRGJEzVHgkMeAX6DPJTnrFc9iiB969G3orL/nERfmgy','2026-06-01 18:42:33.362997',178),(163,'2026-06-01 18:52:29.754661','anamarascki12@hotmail.com',1,'Ana Carla Cravo Marascki ','$2a$11$gCZR50y1HhlOAG4ReciHO.DKPCp8knUT1g.M7IOkiNBCmKR.OTuJ2','2026-06-01 18:53:31.847138',179),(164,'2026-06-01 19:02:04.066891','giselli.ivancheski@hotmail.com',1,'Giselli Ivancheski ','$2a$11$r5gjC4YYS3hY4v4r3Tdp3OxEh4oNldvfQHrHT9f0r4LPd/nVgXHYW','2026-06-01 19:02:04.066892',180),(165,'2026-06-01 19:14:02.829904','hshileid@gmail.com',1,'Hellen Shileid','$2a$11$VTvH1lMy84vuEk0lS4HWp.8wXz49WTdktFKDLlGZy9/Z8evG0UUPG','2026-06-01 19:14:02.829905',181),(166,'2026-06-01 19:23:06.284613','evelinerodrigues@yahoo.com',1,'Eveline Batista Rodrigues','$2a$11$KJibQF69cLYrtOfcERBNuu1tiL4q/LAIWOkEyg.FBg/yGCUPF1e.y','2026-06-01 19:23:06.284614',182),(167,'2026-06-01 19:42:00.280642','fabio.fukamachi@gmail.com',1,'Fábio Fukamachi ','$2a$11$w7mcEBOtpZivnVP0FBnAD.9v/BL5ePKElBFdGCgVonSR07bOfKlde','2026-06-01 19:42:00.280643',183),(168,'2026-06-01 19:58:11.178494','frantoniello@gmail.com',1,'Francieli Toniello','$2a$11$F.ajp81HxFgDLXUAfa9Wc.zPcFflGQoBAx0EG5D6Awh8Js4mV3tIC','2026-06-01 19:58:11.178495',184),(169,'2026-06-01 20:04:08.825692','suliane_1999.03@hotmail.com',1,'Suliane Quadros ','$2a$11$9PM/CkrdBgiss8azN4BvkuoivhV23Z9UsP5YtTd7J1q1pL2LIRIa.','2026-06-01 20:06:13.141332',185),(170,'2026-06-01 20:57:18.642361','caroline.kretzmann01@gmail.com',1,'Caroline Martin Kaufmann','$2a$11$Em7hV.vjez36s/pr9NL.nO9OaJyLuv2qc9TzxA48onXlt.VxfDC9u','2026-06-01 20:57:18.642362',186),(171,'2026-06-01 22:10:33.223355','arqjanainamesquita@gmail.com',1,'Janaína Mesquita ','$2a$11$O9f/3bw9f6FD9jZRmpg/yuTZhVYLIvTZ5w6Vsgco3xAt8dbjf8f3O','2026-06-01 22:10:33.223356',187),(172,'2026-06-02 11:34:02.885757','ligia.manu@hotmail.com',1,'Ligia Cordova','$2a$11$fzg6UtqOz3phwt0eYlv5cucjWK3xT5gxsuDwGTrC6cI95if0xeXsO','2026-06-02 11:34:02.885782',188),(173,'2026-06-02 13:13:58.027288','najlachamma@hotmail.com',1,'Najla Chamma','$2a$11$fr8ob8KmL670ljhWNbXjsO..mYwzPgPlcAaEzkqJnslHqZ7DjX3jW','2026-06-02 13:13:58.027288',189),(174,'2026-06-02 13:15:52.230853','hamiltondefreitas@yahoo.com.br',1,'Hamilton de Freitas Cunha','$2a$11$ae47wo3kqje.FXPYaMnYautq0gEoi9WhBwhztQe7vUfpw.DNn.Pda','2026-06-02 13:15:52.230853',190),(175,'2026-06-03 10:45:15.049466','jessicaferraz92@hotmail.com',1,'Jessica Ferraz Pujol','$2a$11$QogK.lSegMy6Y8w5bNylJOmQFFf36Jum1/uXUrUb8GZ21D/iRJLEe','2026-06-03 10:45:15.049503',191),(176,'2026-06-05 17:20:47.297140','nadia_bergamo@yahoo.com.br',1,'NADIA CRISTINA MARCHETTI BERGAMO MANSINI','$2a$11$BJwf9ielXjWZjMD6Ex028OTRXkZh9bc1KcM1u0jrOd6q8Whv99hli','2026-06-05 17:20:47.297165',192),(177,'2026-06-08 16:39:35.366386','sahjoenck@gmail.com',1,'Sayane Joenck','$2a$11$nn8zf8LAEuRCz5S.U28ZSOsLY22oHdzulmbNGLWa/TgCH2OedLON6','2026-06-08 16:45:03.019967',193),(178,'2026-06-08 16:47:42.184427','ydalmismontero182@gmail.com',1,'Ydalmis arleira montero bolan̈os','$2a$11$mzNZXdjQgClM5G/PdNBPgeA.0iQGqC/17uhdE5OG6.vshJ5zExdX.','2026-06-08 16:47:42.184427',194),(179,'2026-06-08 17:40:34.770512','bruninha_montovani@hotmail.com',1,'Bruna Flávia Montovani ','$2a$11$WXFcc9DHqd6QzwTBGA5G.u1ZvlFxpLSnR3AoskkDlpTd0rPQhFDU.','2026-06-08 17:40:34.770513',195),(180,'2026-06-08 17:41:55.088186','leticia.schwaderer@gmail.com',1,'Leticia Hoss Schwaderer ','$2a$11$hJA2ovYjVeUTmrObp/UoCONNhT1Ssr6pCj9GERgvdbAMF/oV3c8nm','2026-06-15 17:14:56.203832',196),(181,'2026-06-08 19:50:53.530152','vcmsfono@yahoo.com.br',1,'Vanessa C M Silva','$2a$11$KJjc5dR.TPyJdUz8g52C3.OsGdSZMPKADHv0BK573965rfuIaEvGK','2026-06-08 19:50:53.530153',197),(182,'2026-06-09 18:54:05.393859','ggranatto@icloud.com',1,'Gabriela Granatto ','$2a$11$1ERzC8mj1IUTzSw.C7hZ3eQzXXmfBvzzfEJeu3Dv9mddkWRZ4E7Yu','2026-06-09 18:54:05.393878',198),(183,'2026-06-09 19:05:56.283505','camila.azevedo111@gmail.com',1,'Camila Lima de Azevedo','$2a$11$7rjcQ1CcxhsyqdsOVUF4jey661Js/MTMnDGk3UbqkjY3lcKn9MBwK','2026-06-09 19:05:56.283506',199),(184,'2026-06-09 19:52:50.718046','21.caroline9@gmail.com',1,'Caroline Guilherme Pinto ','$2a$11$2VbHkQ08OanZbnTWFj.y8ewprN.B/jWhZ/13BddFVHrRi/T3iL9M.','2026-06-09 19:52:50.718047',200),(185,'2026-06-09 19:54:40.890262','adrianaricarda81@gmail.com',1,'Adriana Ricarda da Silva','$2a$11$a4UvFz2DtRlNEBgCHL.Zh.4g6N2BYDKZ8b2ZgaEdpOZLU4LFPlQ.a','2026-06-09 19:54:40.890263',201),(186,'2026-06-09 20:37:38.605623','lucianapaulas123@gmail.com',1,'Luciana De Paula','$2a$11$hpmow0ZI2DqPwazE7LhQ8.9SA6lielocLr3MbFAfHigCsUvfe8rii','2026-06-09 20:37:38.605624',202),(187,'2026-06-09 23:44:04.988954','Miriaseixas@gmail.com',1,'Miria Cassol Seiixas','$2a$11$uxwjmMt4wPwEhU.uquWMMuaqJtlt6ucri9xvP5HoORK5OQiplfFha','2026-06-09 23:44:04.988955',203),(188,'2026-06-10 02:50:29.436619','franppereira00@gmail.com',1,'Francine Fernandes Pereira ','$2a$11$sTE4bEb8IpSJqNKEHaDjq.CAlhuPnrOyvELIDNgLNm9qoq/OT89c.','2026-06-10 02:50:29.436619',204),(189,'2026-06-10 11:43:45.641952','tuanecustodioam@gmail.com',1,'Tuane Custódio Américo ','$2a$11$QbnukDqZgjdCNsTAfHCWjOxMjqj/IZOzTSepH2iTv.ldFzRzLk8p2','2026-06-10 11:43:45.641970',205),(190,'2026-06-10 21:36:58.807712','angela_piaia@hotmail.com',1,'Angela Carla de Souza Ferreira Piaia ','$2a$11$3xnbATL08Ts3kKZkRtgkKOLFcaAh18ZRzVZkhXFFeJRYkRpkKCGSm','2026-06-10 21:36:58.807713',206),(191,'2026-06-10 23:48:19.227611','pollyana.alencar@gmail.com',1,'Pollyana Alencar dos Santos Maia ','$2a$11$U7I1CdRWtlbDdqggD/j2aebGOKOcnxaWId.sRlWUQCDpU./1/mREK','2026-06-10 23:48:19.227611',207),(192,'2026-06-11 02:40:26.087669','silvana.yoga@hotmail.com',1,'Silvana De Almeida Rodrigues Elias','$2a$11$zsfAgt7fms8H27.MxyZuveAWaj3MsU5G/ptR4KzOVZhqsiomwQOwC','2026-06-11 02:40:26.087670',208),(193,'2026-06-12 13:47:38.008369','fernanda_morimoto@hotmail.com',1,'Fernanda Morimoto','$2a$11$YTlgxxzTPIHrS6tShewko.Xg.jc5ux9OOk93F.3jJXc96/hQapq/6','2026-06-12 13:47:38.008396',209),(194,'2026-06-15 17:33:20.285485','jonathanortiz2007@gmail.com',1,'Jonathan Silva Ortiz ','$2a$11$Uf5I5c4VYzuk0jINu2KmTeJkNG77Uzaj14MflVuC0ru41yEX7sEWO','2026-06-15 17:40:43.355611',210),(195,'2026-06-15 17:36:34.513541','ketlinbordinmanfroi@gmail.com',1,'Kétlin Bordin manfroi','$2a$11$XNZSFZv1G53qFrbG8CNhxOtbS82zP7zhwOHwz3juYcrJyjzoOe70K','2026-06-15 17:36:34.513541',211),(196,'2026-06-15 17:36:34.772670','tatigrandotti@gmail.com',1,'Tatiane Grandotti ','$2a$11$RZNwZ6W.Yqa.0pCEi2KTweEh2fpbHNiuuPi7k7f.rYT7LJPvxsa2C','2026-06-15 17:36:34.772671',212),(197,'2026-06-15 17:37:25.652235','silvinhoadv@gmail.com',1,'Silvio Lara Junior','$2a$11$f7dO2ODppZCknBb4uhyzXuxGUg9zIlFldQpkWDHAjizKLz6qVSLd.','2026-06-15 17:38:06.031088',213),(198,'2026-06-15 17:38:40.326903','meiraandreia8@gmail.com',1,'Andréia da Silva Meira Brunetti ','$2a$11$UVP2GFhn25wAa39QD6vvQuzXtg.aRfby74RxPu6qKaecC1zafSCqm','2026-06-15 17:38:40.326903',214),(199,'2026-06-15 17:38:57.208241','deschmittt78@gmail.com',1,'Débora Geovana Schmitt','$2a$11$jm84.e408DfvW14nvWk7vOR9x4c/s/n2w5GHb2rSUGLC.vQDA.c3m','2026-06-15 19:05:12.727053',215),(200,'2026-06-15 17:40:12.575393','camiladloiola@gmail.com',1,'Camila Loiola','$2a$11$Q.9LabFdYy3zkiejdsjyKeTYir74XmqDRQhYvp5S/cM5VqsDzDN8y','2026-06-15 17:40:41.002164',216),(201,'2026-06-15 17:48:06.335107','nathany-mantoan@hotmail.com',1,'Nathany Thayse Mantoan Naliato','$2a$11$mPX/y3t5ESeJGN5XZTB/8uohjZchZZ.fPeb6QcbW88eI2fGNVP48S','2026-06-15 17:51:05.149644',217),(202,'2026-06-15 17:49:20.300404','cris_cristina2802@hotmail.com',1,'Djenane Cristina de Almeida ','$2a$11$xtNob3CtbeyAVYsfJqfwauZQ9XJeEN4/cUCPelcPhZdvT1kmczZuO','2026-06-15 17:49:20.300405',218),(203,'2026-06-15 18:43:49.757970','eng.francielefigueredo@gmail.com',1,'Franciele Zarembski','$2a$11$4Pncc7KFZtZEFqvnfHYlqOesA4dmxxSQFIB9/MYCSkc/64fqfaDD.','2026-06-15 18:43:49.757970',219),(204,'2026-06-22 15:07:29.800672','priscilalima.costa@icloud.com',1,'Priscila Maria Silvério de Lima Costa Mori ','$2a$11$BTagLvgAGilg/YvDtD32zOftKSk1V5FCuGo3AGYLOuSmvfD1ss9xi','2026-06-22 15:07:29.800698',220),(205,'2026-06-22 20:01:01.387301','profegeo3005@gmail.com',1,'GEOVANNA DE OLIVEIRA ALBERTI','$2a$11$MkPc4WXie7/f4HQMLjnlgeu7pp8hgzXjTh2/iZLQpU1juwIvpC54e','2026-06-22 20:01:01.387332',221),(206,'2026-06-22 20:03:08.606599','monicalug@yahoo.com.br',1,'Mônica Candida Lugão Moraes ','$2a$11$brBFymKDY09T6yTIA6OPZ.89C801vNacmWn27WHs9eGb.sHZQN0re','2026-06-22 20:15:09.107727',222),(207,'2026-06-22 20:04:45.947932','c.krausee@live.com',1,'Caroline Gabriela Krause','$2a$11$Y86qJbz6UtsOV4bGvXzNsehSFSVxviLFX20xaOguPQwZf.VbZ2i56','2026-06-22 20:05:12.787307',223),(208,'2026-06-22 20:04:47.633776','costadaisy494@gmail.com',1,'Daisy Antunes Costa ','$2a$11$oRE0wJUEhObkBe1Ja4p/W.7WMythtzgFctFEUAVb/D7O7nWAesHQq','2026-06-23 11:54:11.574145',224),(209,'2026-06-22 20:05:32.053597','luiza_delle6@hotmail.com',1,'Luiza Delle ','$2a$11$HM.ogymH6XvKc9nDLpNEte4RFpYHMR.aRp4YMgxFz1XCcHRzdwiy.','2026-06-23 15:54:51.332613',225),(210,'2026-06-22 20:10:08.483646','leticialima6743@gmail.com',1,'Letícia Francisco de Lima ','$2a$11$4njyi4n5EXc7FWhzADqUSOcIshJjZF/q00A9QvnDZ2P35jQYHYkGS','2026-06-22 20:12:05.937194',226),(211,'2026-06-22 20:25:14.731410','michele.michels@gmail.com',1,'Michele Vicente Michels Baptista ','$2a$11$MB18DXULEzu0dDzEFE/ixO9ZcGtL0hQN/yERgvlvBLbTv/QTIn7ZO','2026-06-22 20:25:14.731411',227),(212,'2026-06-23 00:15:09.563329','jessiekubis@outlook.com',1,'Jessie Miranda Kubis ','$2a$11$cqXua9dUtCMZ06JYPe2tLeD5hmHDpOrMLCnnHLnjOpdrSTNkzNUP6','2026-06-23 00:15:09.563356',228);
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserRole`
--

DROP TABLE IF EXISTS `UserRole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserRole` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IX_UserRole_user_id_role_id` (`user_id`,`role_id`),
  KEY `IX_UserRole_role_id` (`role_id`),
  CONSTRAINT `FK_UserRole_Role_role_id` FOREIGN KEY (`role_id`) REFERENCES `Role` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_UserRole_User_user_id` FOREIGN KEY (`user_id`) REFERENCES `User` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserRole`
--

LOCK TABLES `UserRole` WRITE;
/*!40000 ALTER TABLE `UserRole` DISABLE KEYS */;
INSERT INTO `UserRole` VALUES (13,14,5,'2025-10-28 02:20:36.396036'),(14,4,5,'2025-12-16 15:58:11.302907');
/*!40000 ALTER TABLE `UserRole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Venda`
--

DROP TABLE IF EXISTS `Venda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Venda` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Quantidade` int(11) NOT NULL,
  `ValorVenda` decimal(65,30) NOT NULL,
  `Desconto` decimal(65,30) DEFAULT NULL,
  `ClienteId` int(11) NOT NULL,
  `ProdutoId` int(11) NOT NULL,
  `CodigoLive` int(11) DEFAULT NULL,
  `OrigemID` int(11) DEFAULT NULL,
  `OrdemVendaLive` int(11) DEFAULT NULL,
  `LiveId` int(11) DEFAULT NULL,
  `DataAlteracao` datetime(6) DEFAULT NULL,
  `DataPagamento` datetime(6) DEFAULT NULL,
  `DataVenda` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_Venda_ClienteId` (`ClienteId`),
  KEY `IX_Venda_ProdutoId` (`ProdutoId`),
  KEY `IX_Venda_OrigemID` (`OrigemID`),
  KEY `IX_Venda_LiveId` (`LiveId`),
  CONSTRAINT `FK_Venda_Live_LiveId` FOREIGN KEY (`LiveId`) REFERENCES `Live` (`Id`),
  CONSTRAINT `FK_Venda_Origem_OrigemID` FOREIGN KEY (`OrigemID`) REFERENCES `Origem` (`Id`),
  CONSTRAINT `FK_Venda_Pessoa_ClienteId` FOREIGN KEY (`ClienteId`) REFERENCES `Pessoa` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_Venda_Produto_ProdutoId` FOREIGN KEY (`ProdutoId`) REFERENCES `Produto` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Venda`
--

LOCK TABLES `Venda` WRITE;
/*!40000 ALTER TABLE `Venda` DISABLE KEYS */;
/*!40000 ALTER TABLE `Venda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VendaPdv`
--

DROP TABLE IF EXISTS `VendaPdv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VendaPdv` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Codigo` varchar(50) DEFAULT NULL,
  `ClienteId` int(11) DEFAULT NULL,
  `Status` varchar(20) NOT NULL,
  `DataVenda` datetime(6) NOT NULL,
  `ValorBruto` decimal(65,30) NOT NULL,
  `Desconto` decimal(65,30) DEFAULT NULL,
  `ValorLiquido` decimal(65,30) NOT NULL,
  `Observacao` varchar(500) DEFAULT NULL,
  `UsuarioId` int(11) DEFAULT NULL,
  `CaixaId` int(11) DEFAULT NULL,
  `DataAlteracao` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_VendaPdv_ClienteId` (`ClienteId`),
  CONSTRAINT `FK_VendaPdv_Pessoa_ClienteId` FOREIGN KEY (`ClienteId`) REFERENCES `Pessoa` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VendaPdv`
--

LOCK TABLES `VendaPdv` WRITE;
/*!40000 ALTER TABLE `VendaPdv` DISABLE KEYS */;
/*!40000 ALTER TABLE `VendaPdv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VendaPdvItem`
--

DROP TABLE IF EXISTS `VendaPdvItem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VendaPdvItem` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `VendaPdvId` int(11) NOT NULL,
  `ProdutoId` int(11) DEFAULT NULL,
  `DescricaoItem` varchar(200) NOT NULL,
  `Quantidade` decimal(65,30) NOT NULL,
  `PrecoUnitario` decimal(65,30) NOT NULL,
  `DescontoValor` decimal(65,30) DEFAULT NULL,
  `DescontoPerc` decimal(65,30) DEFAULT NULL,
  `Total` decimal(65,30) NOT NULL,
  `CodigoEstoque` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_VendaPdvItem_ProdutoId` (`ProdutoId`),
  KEY `IX_VendaPdvItem_VendaPdvId` (`VendaPdvId`),
  CONSTRAINT `FK_VendaPdvItem_Produto_ProdutoId` FOREIGN KEY (`ProdutoId`) REFERENCES `Produto` (`Id`),
  CONSTRAINT `FK_VendaPdvItem_VendaPdv_VendaPdvId` FOREIGN KEY (`VendaPdvId`) REFERENCES `VendaPdv` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VendaPdvItem`
--

LOCK TABLES `VendaPdvItem` WRITE;
/*!40000 ALTER TABLE `VendaPdvItem` DISABLE KEYS */;
/*!40000 ALTER TABLE `VendaPdvItem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VendaPdvPagamento`
--

DROP TABLE IF EXISTS `VendaPdvPagamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VendaPdvPagamento` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `VendaPdvId` int(11) NOT NULL,
  `FormaPagamentoId` int(11) NOT NULL,
  `CondicaoPagamentoId` int(11) DEFAULT NULL,
  `Valor` decimal(65,30) NOT NULL,
  `Observacao` longtext DEFAULT NULL,
  `TransacaoId` longtext DEFAULT NULL,
  `DataRegistro` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_VendaPdvPagamento_CondicaoPagamentoId` (`CondicaoPagamentoId`),
  KEY `IX_VendaPdvPagamento_FormaPagamentoId` (`FormaPagamentoId`),
  KEY `IX_VendaPdvPagamento_VendaPdvId` (`VendaPdvId`),
  CONSTRAINT `FK_VendaPdvPagamento_CondicaoPagamento_CondicaoPagamentoId` FOREIGN KEY (`CondicaoPagamentoId`) REFERENCES `CondicaoPagamento` (`Id`),
  CONSTRAINT `FK_VendaPdvPagamento_FormaPagamento_FormaPagamentoId` FOREIGN KEY (`FormaPagamentoId`) REFERENCES `FormaPagamento` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_VendaPdvPagamento_VendaPdv_VendaPdvId` FOREIGN KEY (`VendaPdvId`) REFERENCES `VendaPdv` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VendaPdvPagamento`
--

LOCK TABLES `VendaPdvPagamento` WRITE;
/*!40000 ALTER TABLE `VendaPdvPagamento` DISABLE KEYS */;
/*!40000 ALTER TABLE `VendaPdvPagamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `__EFMigrationsHistory`
--

DROP TABLE IF EXISTS `__EFMigrationsHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `__EFMigrationsHistory` (
  `MigrationId` varchar(150) NOT NULL,
  `ProductVersion` varchar(32) NOT NULL,
  PRIMARY KEY (`MigrationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `__EFMigrationsHistory`
--

LOCK TABLES `__EFMigrationsHistory` WRITE;
/*!40000 ALTER TABLE `__EFMigrationsHistory` DISABLE KEYS */;
INSERT INTO `__EFMigrationsHistory` VALUES ('20240120142739_inicial08','8.0.1'),('20240120154839_change_pessoa_fk_at_usuario','8.0.1'),('20240121164420_add_nickname_at_pessoa','8.0.1'),('20240121222638_add_datainclusao_at_pessoa','8.0.1'),('20240122190530_add_origem_notnull_at_venda','8.0.1'),('20240124010506_add_table_grupo_fk_grupo_at_produto','8.0.1'),('20240124012817_change_codigolive_from_produto_to_venda','8.0.1'),('20240124013930_remove_preco_venda_at_produto','8.0.1'),('20240124023557_add_dataoperacao_at_venda_v3','8.0.1'),('20240126023710_change_tb_vendaV4','8.0.1'),('20240126232438_change_tb_venda_PrecoVendaToValorVenda','8.0.1'),('20240211012708_tb_live_add_tb_venda_fld_ordemlive','8.0.1'),('20240211013511_tb_live','8.0.1'),('20240211013825_tb_live_change_titulo_string_50','8.0.1'),('20240211014601_tb_venda_add_fk_liveid','8.0.1'),('20240306010123_tbl_produto_add_codigolive','8.0.1'),('20240415212355_add_pessoapertence_datacompra_tb_produto','8.0.1'),('20240415225126_tbl_produtos_alter_origem_char_to_varchar','8.0.1'),('20240508163810_tbl_produto_add_dt_alteracao_userModificacao','8.0.2'),('20240508164251_tbl_produto_add_alter_usuModificacao_nonnullable','8.0.2'),('20240509120442_tbl_PessoaStatus_ProdutoStatus','8.0.2'),('20240509120837_tbl_PessoaStatus_ProdutoStatus_del_tbl_status','8.0.2'),('20240509121038_tbl_ProdutoStatus','8.0.2'),('20240509124731_field_status_to_tbl_Produto_tbl_Pessoa_nullable','8.0.2'),('20240509125030_alter_field_status_to_tbl_Produto_tbl_Pessoa_non_nullable','8.0.2'),('20240510163152_tbl_marca','8.0.2'),('20240513155915_field_dtvenda_dtpgt_dtalt_usumod_tbl_venda','8.0.2'),('20240513160407_del_dtoperacao_tbl_venda','8.0.2'),('20240513160951_field_dtvenda_dtpgt_dtalt_usumod_tbl_venda_v2','8.0.2'),('20240513162209_pk_live_tb_venda','8.0.2'),('20240520170102_add_dt_usu_mod_tb_live','8.0.2'),('20240520170240_remove_null_usu_mod_tbl_live','8.0.2'),('20240520170332_dt_alteracao_non_nullable_tbl_live','8.0.2'),('20240625192217_tbl_arremate_add','8.0.2'),('20240625192901_tbl_arremate_add_v2','8.0.2'),('20240626002613_tbl_arremate_add_liveid','8.0.2'),('20240715175005_tb_estoque','8.0.2'),('20240715182350_usu_dt_mod_to_tb_estoque','8.0.2'),('20240715182731_alt_usu_prod_tb_estoque','8.0.2'),('20240715182902_del_prod_fk_produto','8.0.2'),('20240715182957_prod_fk_tb_estoque','8.0.2'),('20240715220158_del_codigo_estoque_tb_prod_add_cod_estoque_to_tb_estoque','8.0.2'),('20240808181107_add_ValorArremate_at_arremate_PrecoVenda_at_Produto','8.0.2'),('20240825015517_tb_produto_add_sexo','8.0.2'),('20240830000021_change_codigolive_from_tb_produto_to_tb_arremate','8.0.2'),('20240830001608_change_tbl_produto_sexo_to_genero','8.0.2'),('20240830002222_add_tb_produto_add_perfil','8.0.2'),('20240915201117_add_ProdutoPefil_ProdutoCategoria_Alter_Marca_To_ProdutoMarca','8.0.2'),('20240915203808_add_ProdutoPefil_Alter_Marca_To_ProdutoMarca_Alter_Grupo_To_ProdutoGrupo','8.0.2'),('20240915204952_add_ProdutoPerfil','8.0.2'),('20240926214908_ad_tb_PessoaGenero_PessoaPerfil','8.0.2'),('20250306012431_tbl_produto_remover_pessoapertence','8.0.2'),('20250309010510_tb_produto_chave_grupoid_ProdutoGrupo','8.0.2'),('20250313154922_tbl_pessoa_remove_Sexo','8.0.2'),('20250313155147_tbl_pessoa_add_PessoaGenero','8.0.2'),('20250313155515_tbl_pessoa_add_PessoaGenero_notnull','8.0.2'),('20250405185026_add_tb_Endereco','8.0.2'),('20250405220331_add_tb_TipoEndereco','8.0.2'),('20250409200923_tb_pessoa_add_cpf_e_rg','8.0.2'),('20250410132703_tb_pessoa_add_obs','8.0.2'),('20250410162416_tb_end_add_observacoes','8.0.2'),('20250411155422_tbl_produtos_add_condicao','8.0.2'),('20250421215938_tb_PedidoStatus_tb_FormaPagamento_tb_CondicaoPagamento','8.0.2'),('20250421221945_tb_PedidoStatus_tb_FormaPagamento_tb_CondicaoPagamentoV2','8.0.2'),('20250421222216_tb_Pedido','8.0.2'),('20250421222356_tb_PedidoProduto','8.0.2'),('20250519134142_tb_Pedido_endereco_entrega_nullable','8.0.2'),('20250519140200_tb_Pedido_data_alteracao_notnull','8.0.2'),('20250519225522_tb_Pedido_PedidoCodigo_IsUnique','8.0.2'),('20250520004855_tb_PedidoProduto_dataAlteracao_notnull','8.0.2'),('20250625021137_add_tb_ComentarioLive','8.0.2'),('20250627011127_tb_live_session_alt_comentario_live','8.0.2'),('20250628235012_tb_comentariolive_del_livesessionid','8.0.2'),('20250628235452_tb_comentariolive_add_livesessionid_long','8.0.2'),('20250807211024_alt_usuarios_user','8.0.2'),('20250807211554_alt_usuario_to_user','8.0.2'),('20250807212312_RBAC_Tables','8.0.2'),('20250807212950_User_Collections','8.0.2'),('20250807213223_User_Clean','8.0.2'),('20250807213641_User_Full','8.0.2'),('20251026213625_AddPessoaToUser','8.0.2'),('20251027102248_tbUser_PessoaId_nonNullable','8.0.2'),('20251027102508_tbUser_PessoaId_nonNullable_V2','8.0.2'),('20251103210920_tb_Arremate_ProdutoId_Nullable','8.0.2'),('20251103221621_tb_Arremate_Add_DescricaoManual','8.0.2'),('20251104010755_tb_PDV_Initial','8.0.2'),('20251104020333_seed_FormaPagamentoConfigPDV','8.0.2'),('20251104103855_seed_FormaPagamentoConfigPDV_Fill','8.0.2'),('20260102203921_AddNfceTables','8.0.2'),('20260614212009_AddEnvioLoteMap','8.0.2');
/*!40000 ALTER TABLE `__EFMigrationsHistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_enviolote_map`
--

DROP TABLE IF EXISTS `tb_enviolote_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_enviolote_map` (
  `TransacaoId` varchar(255) NOT NULL,
  `EtiquetaId` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Nome` varchar(255) NOT NULL,
  `StatusPagamento` varchar(50) NOT NULL,
  `StatusSuperfrete` varchar(50) NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`TransacaoId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_enviolote_map`
--

LOCK TABLES `tb_enviolote_map` WRITE;
/*!40000 ALTER TABLE `tb_enviolote_map` DISABLE KEYS */;
INSERT INTO `tb_enviolote_map` VALUES ('01f3603955d0435ba733912dfa50319c','w13DEFttc4Evbqvd7xDC','fabio.fukamachi@gmail.com','Fábio Fukamachi','Aguardando','Carrinho','2026-06-15 14:12:41.313435'),('056d5c51bb914d8ca92c40ffa2e7b503','0UWY54FxPPco85IkSTdS','cris_cristina2802@hotmail.com','Djenane Cristina de Almeida','Aguardando','Carrinho','2026-06-18 08:18:54.047386'),('058633a72d4c4b52ba8adf5401181664','XkqiyxiPhVDStS5M1pLx','molagra_karoline@hotmail.con','Môlagra Karoline de Goes','Aguardando','Carrinho','2026-06-25 10:48:48.318905'),('0a7686e971bd407e828bf1c8e29b6095','9G1HuBvzGOfUBdhl0sYh','leandroeletrica1@hotmail.com','Francine Peres Vefago','Aguardando','Carrinho','2026-06-25 10:48:44.760602'),('104a00a0b3a4443faf22b81bb2a739c5','UI8rnLi41n5n5mMqPHFo','tuanecustodioam@gmail.com','Tuane Custódio Américo','Aguardando','Carrinho','2026-06-15 14:12:43.007484'),('13095a49cca54eb9830dbb199ab5662b','TsS55kRQ12NPotQZCG6T','angela_piaia@hotmail.com','Angela Piaia','Aguardando','Carrinho','2026-06-18 08:18:47.660277'),('154bdd1a329c41229a601f7d2252eb70','qQuNQE5DlEt9kcUHH1v8','carolina.correasilva@outlook.com','Ana Carolina Correa','Aguardando','Carrinho','2026-06-18 08:18:58.286614'),('160e394b61034ad2931a152d1f39b26e','phWjveLEioK5iTf8aTOJ','Lidi_luz@hotmail.com','Lidiane Lara da Luz','Aguardando','Carrinho','2026-06-15 14:12:47.112373'),('1951410469294b109cffd1485f0dc0a0','aYBaAQMz92iA5ANDv05j','nathany-mantoan@hotmail.com','Nathany Thayse Mantoan Naliato','Pago','Erro Checkout','2026-06-18 08:18:53.114188'),('219a21d653144475a57317d3a8a4f5b6','QwqTo2JO8Mehrp2aDHgn','cacau5br@gmail.com','Catia Simone Fernandes Machado','Aguardando','Carrinho','2026-06-18 08:18:45.744808'),('2aff170567b440558709e614182df073','p0NfbBK6RhjfAQoHabGE','adilio.oliva@gmail.com','Adílio Borges Oliva','Aguardando','Carrinho','2026-06-25 10:48:47.409595'),('2c614c36a0824a1ead10bc59b6ed8a3f','fDzZskCV73YVbl8fWBTN','teacherlediane@gmail.com','Lediane Manfé de Souza','Aguardando','Carrinho','2026-06-15 14:12:51.345382'),('2d93f72918d84c58afc7b47dc3d04e71','jDI5mEaGoRrS8lNHkTCa','monicalug@yahoo.com.br','Mônica Candida Lugão Moraes','Aguardando','Carrinho','2026-06-25 10:48:50.560279'),('2fc8feef87e440edba53784bf3587845','ucSWc26MfsXLVW6ORMXE','thamirishartmann92@gmail.com','Thamiris Hartmann','Aguardando','Carrinho','2026-06-18 08:18:56.382680'),('30916bebfdce4a529a0b2cb31b49d1a6','ElNis0ii7Gtn2tzednPs','bacolonetti@gmail.com','Bruna Alves Colonetti Nunes','Pago','Liberada','2026-06-25 10:48:37.220542'),('314ef52de982416695c557323a38286f','B57KQrASYzlLERW4avfk','semmerju@gmail.com','Juliana Semmer','Aguardando','Carrinho','2026-06-18 08:19:02.080538'),('369e95e86dd44e82822158c13fc4549c','hA5uTTHT7zBS6uJiFX3j','eng.francielefigueredo@gmail.com','Franciele Zarembski','Aguardando','Carrinho','2026-06-15 15:52:11.998049'),('39b49d4ddaf346a09622fd3fa2c01ae1','PEWS66sfl7WqheqQWNQE','ketlinbordinmanfroi@gmail.com','Kétlin Bordin Manfroi','Pago','Liberada','2026-06-25 10:53:42.103478'),('39ee010df4fe4d24ba602f39cf5cbcbd','ePWyCLAM4kts8l0dr9xO','c.krausee@live.com','Caroline Gabriela Krause','Aguardando','Carrinho','2026-06-25 10:48:43.541324'),('3f5abf7ae65f4a55b4918c29caeb4460','t1J3MsC6J1vsffZ9fPtG','amdeschk@hotmail.com','Ana Maria Deschk','Pago','Erro Checkout','2026-06-15 14:12:36.723048'),('43577c46ef984040b1bdab9dfc6e8f58','yzleT2Mmq9SUHbEIsdC6','luferraz78@gmail.com','Luciana Ferraz de Oliveira','Aguardando','Carrinho','2026-06-15 15:33:05.326279'),('4ddd4cddfe4b4b85b1ee44f17807f0c7','CzSQ60M3Y3VEtJ62nKMx','sabrinaantonioli5@gmail.com','Sabrina Antonioli','Aguardando','Carrinho','2026-06-15 14:12:39.958956'),('4e04e4e3d41c4e8daaf9301e24730519','bDqWLlEgsJ8CEjrxjgD9','adilio.oliva@gmail.com','Adílio Borges Oliva','Aguardando','Carrinho','2026-06-18 08:19:02.871228'),('512c8eba225b4a35a9e1638b14b1788b','3dHsnJyfKm6ZWV6u5lqp','meiraandreia8@gmail.com','Andreia da Silva Meira Brunetti','Aguardando','Carrinho','2026-06-18 08:18:44.840803'),('52a2e24b6be94d7898dfe48f2c480f28','x3SvE7jEYAPq94UnuTqu','eduardo.cwbnet@gmail.com','Eduardo Rocha','Pago','released','2026-06-14 18:52:40.323129'),('53b8526c18b04eb0a2220f22d2fe6bad','yjZwt7eODkUtRXSfgihu','fernanda_morimoto@hotmail.com','Fernanda Morimoto','Aguardando','Carrinho','2026-06-15 15:33:07.870777'),('580f02a637124e59ad09f525c9d03ec3','PyvkYl9NDEchHubvrnON','franppereira00@gmail.com','Francine Pereira','Aguardando','Carrinho','2026-06-15 14:12:54.577236'),('594650cde0d8435bb09642d43334e6ae','CCEesvldDiPwIdSTXdPh','vanessa.filipini@yahoo.com.br','Vanessa Reinstein Alnoch','Aguardando','Carrinho','2026-06-18 08:18:43.457844'),('59d6b2aaeab44064bf6f8e7b29a424ce','bpQsx6401LPundvKDX49','costadaisy494@gmail.com','Daisy Antunes Costa','Aguardando','Carrinho','2026-06-25 10:48:52.996921'),('5b1312df26384104aea0165a2f2ae938','3Px6UqfQI6wcEcYICHPy','ydalmismontero182@gmail.com','Ydalmis Montero','Aguardando','Carrinho','2026-06-15 14:12:43.799139'),('5b6ed56b53534a958f1bc17936d95e30','xOEuPQLaWbNxlXdhOpKT','flaviaharckbart@gmail.com','Flávia Harckbart de Oliveira','Aguardando','Carrinho','2026-06-18 08:19:00.813991'),('5bde9ecc5bee4cc9bf50055a4e263a56','9EegYId8YHZxFYgFHcWk','arianyprebonato@gmail.com','Ariany Rebonato','Aguardando','Carrinho','2026-06-15 14:12:56.207187'),('5ce1475e94934bb0940d7269e1b1d6a1','70Q5guB25z26wOeZVRlf','pollyana.alencar@gmail.com','Pollyana Maia','Aguardando','Carrinho','2026-06-15 14:12:53.669007'),('6470f89c40ba4463b98d1aa41a1516b7','1n2mL3dOZxBvqWmPjwls','silvinhoadv@gmail.com','Silvio Lara Júnior','Aguardando','Carrinho','2026-06-25 10:48:39.923332'),('66d9dad59dc24369846b8fc6b8dee144','ngOiEERlQAAQGp9XSoT4','luana_fidelis@hotmail.com','Luana Fidelis da Silva Stanislavski','Aguardando','Carrinho','2026-06-15 15:37:30.040966'),('698e4d063b3c4085b90e0cceacccea2b','GeeShOsK4w6u1pcG8bsy','louisepeixotogomes@gmail.com','Louise Peixoto Gomes','Aguardando','Carrinho','2026-06-18 08:18:49.545742'),('6a6495a9baf44a3ca34e86950ddd534c','2hFRuonJzL0h9XNT1TK1','thaislmiranda@hotmail.com','Thais Priscilla Leite de Miranda Mendes','Aguardando','Carrinho','2026-06-18 08:19:04.474496'),('6ae7e20f55b34f9bbf20c29853881e48','J08G0OA1UpX8Uucup3rI','sahjoenck@gmail.com','Sayane Joenck','Aguardando','Carrinho','2026-06-18 08:18:57.292587'),('6bc55e2c2fa34c9abc1857eb7778e29c','7YQ9jsqYaDC6mxJQiJ5n','caroline.kretzmann01@gmail.com','Caroline Kaufmann','Aguardando','Carrinho','2026-06-25 10:48:38.124919'),('6d1df772c93f4e71a6172497e06da4f6','LlTOt3wilSIXE6Fq6UKy','erikafoppel@gmail.com','Erika M Foppel','Aguardando','Carrinho','2026-06-15 14:12:48.809411'),('6f199ff7247c4662b5fbd83511dabee2','Z2zMh3X93gwDI7XOYzaO','marlivjsouza@gmail.com','Marli Terezinha Pinto','Pago','Erro Checkout','2026-06-15 14:12:37.505291'),('73243e010e2f4d2481a5ed5ddccc7f4d','tJ7FK1cwkYz1O1qAeHtX','luiza_delle6@hotmail.com','Luiza Delle','Aguardando','Carrinho','2026-06-25 10:48:41.786833'),('784086085e2d4633b16ba5a4c090f4f9','EWJiaqZBVYvf1vPDr78d','miriam_asano@hotmail.com','Miriam Asano','Aguardando','Carrinho','2026-06-25 10:48:49.254401'),('7e20efab8b2742f5a7b607c9cf1e6409','71p1wHhfGIwyyoQELn1d','jonathanortiz2007@gmail.com','Jonathan Silva Ortiz','Aguardando','Carrinho','2026-06-18 08:18:55.051224'),('7e7f36d41d2d4e3196ead5c2aa7694a8','5xaHPlcW23QYwom2eth4','daibrasill@hotmail.com','Daiane Brasil Dutra','Aguardando','Carrinho','2026-06-15 14:12:55.392561'),('806c7ca42ca547638b345c60b0dd2e88','U7IkEKcvRnkzYYHIMxGE','nadia_bergamo@yahoo.com.br','NADIA CRISTINA MARCHETTI BERGAMO MANSINI','Aguardando','Carrinho','2026-06-15 15:33:04.102016'),('84d12a209fb849d3926b3c917b31692f','D8m3yYSqVyUuMiOTUQ0m','21.caroline9@gmail.com','Caroline Guilherme Pinto','Pago','Erro Checkout','2026-06-18 08:18:52.268621'),('91ec092207654f798148092e18fba4a2','7AvY8r29riLnycVwV9yN','neticia4@hotmail.com','Carla Letícia Mendes','Aguardando','Carrinho','2026-06-18 08:18:48.501584'),('93effa35f1ca4e8297c8f5a97262374b','hehg0HwP3oNSXn6chTbq','bruninha_montovani@hotmail.com','Bruna Flávia Montovani','Aguardando','Carrinho','2026-06-15 14:12:50.427243'),('9490631ef6e244418ff4935b7754a0be','VuoDOsPMxaEwsVx71Exc','jessiekubis@outlook.com','Jessie Miranda Kubis','Pago','Carrinho','2026-06-25 10:48:40.921786'),('98d02717b1154e0db7e940fb7f9bce1c','pQ4etnvOVPQttcpEZfIC','leticialima6743@gmail.com','Leticia Francisco de Lima','Aguardando','Carrinho','2026-06-25 10:48:36.363913'),('9a4c7dbf98f64e42a0043be8d0247b41','KVyRq2waPvmqiSI4BCqC','vcmsfono@yahoo.com.br','Vanessa C M Silva','Pago','Erro Checkout','2026-06-15 15:33:06.556981'),('9a6f38809bcf47e8ae2ed8bac41dd248','89htAjsgycEb70QyUCvd','daianekujbida@hotmail.com','Daiane dos Santos Kujbida','Aguardando','Carrinho','2026-06-25 10:48:35.117597'),('a17d43969aab4c93a99c8b29eedbc0e8','QERxVuPlHQoj913kec2j','twardowskiizabela74@yahoo.com','Izabela Twardowski','Aguardando','Carrinho','2026-06-25 10:48:51.749792'),('a30ded2e402942dd931cd41049a2124c','fBs7S2l65B4es59FKtJ8','camiladloiola@gmail.com','Camila Loiola','Aguardando','Carrinho','2026-06-25 10:48:38.965934'),('a51949c9757648bd847d71f683556b9c','fpWoZACkoOmtoKZdsBly','lu.tinkerbell@gmail.com','Luciana Mitsue Nagamati Kido','Aguardando','Carrinho','2026-06-15 14:12:45.542061'),('a8425c08cabf47bca5342a94b9a84db1','mRqBWWKKL2Z71grN7PfQ','ggranatto@icloud.com','Gabriela Granatto','Aguardando','Carrinho','2026-06-15 14:12:44.740603'),('a9b16e0668bb46dca2c4b63c0a3588d3','byaozSnVCsdp4QC1QUqQ','arqjanainamesquita@gmail.com','Janaína Mesquita','Pago','Erro Checkout','2026-06-15 14:12:38.637409'),('acb2fa1471024a72a5937fe5ccfd7eee','ch2mw2f00Wq8KhTG2qJb','deschmittt78@gmail.com','Debora Geovana Schmitt','Aguardando','Carrinho','2026-06-18 08:18:46.647812'),('afa410cab6db4b2d8e96731f8c6c1e00','GdWk0tU6CwnUCdKggjqM','michellestempniak@hotmail.com','Michelle Stempniak','Aguardando','Carrinho','2026-06-18 08:18:59.103889'),('bd47136ad9d64ce396018de97d83ce33','EQsYGpAFSBvnoANlnNDc','Miriaseixas@gmail.com','Miria Cassol Seiixas','Pago','Erro Checkout','2026-06-15 14:22:53.181582'),('bd4724fb1d8f49b68410e345eedc2d07','S74fzkmqqmVCMP0QcXsc','michellestempniak@hotmail.com','Michelle Stempniak','Aguardando','Carrinho','2026-06-25 10:48:46.512390'),('bf6b65f7879448cf891f2be9244c66f0','GdIuQBxSvUY29s9mmL3O','angela_piaia@hotmail.com','Angela Piaia','Aguardando','Carrinho','2026-06-15 14:12:47.975758'),('c045fac37821427c8399da5e8b515fa5','LzqFzgmhKCLKlC8Z7Rq4','priscilalima.costa@icloud.com','Priscila Mori','Aguardando','Carrinho','2026-06-25 10:48:53.970406'),('c0fd1966e66b417ea46e4067c262bd92','0aL07VW6HjVFUgNb4XmO','tatigrandotti@gmail.com','Tatiane Grandotti','Aguardando','Carrinho','2026-06-18 08:19:03.683707'),('c745d16c24b540d5b69b6313c4b86161','BN3FZCLdKY5AvLKdeYWZ','carolinebchagas@gmail.com','Caroline Buch Chagas','Aguardando','Carrinho','2026-06-18 08:19:05.354507'),('ce5a7c5c038645038f89eac55def9802','wYCcpBx2jQF5OOKVogtW','lucianapaulas123@gmail.com','Luciana de Paula','Aguardando','Carrinho','2026-06-15 14:12:49.580881'),('ce7310352d7048788dc8ff6ae7a7147e','zNkQ4t6Vc5jUXPW9Vkg8','leticia.schwaderer@gmail.com','Leticia Hoss Schwaderer','Pago','Carrinho','2026-06-25 10:48:42.664420'),('cf6fd07d59d541a5a12edb2268bae2ad','WenyKNG4AnpQoNOkHCvW','eduardo.cwbnet@gmail.com','Eduardo Rocha','Pago','released','2026-06-14 18:27:13.974343'),('d6799de3ebe845d1a678e89cc7a307c0','frQU3uB0NOybk4jOgcPs','adrianaamello@hotmail.com','Adriana Antunes de Mello','Aguardando','Carrinho','2026-06-18 08:18:51.443689'),('df0e77a98321430883458f464663a88e','sWtBvYbwK49EUQmmNDJd','katisolek@outlook.com','Katielle Solek','Aguardando','Carrinho','2026-06-18 08:18:59.974070'),('e68b30025e014e43b4b541f583660549','1c9XN7memlJFPNFgvymR','lilian.linke@santander.com.br','Lilian Muller','Aguardando','Carrinho','2026-06-18 08:19:06.774206'),('e7d28ea204f54ea787198a37eac1ea6f','x4PfuK7BDtmSSnNN7LLm','eduardo.cwbnet@gmail.com','Eduardo Rocha','Pago','Erro Checkout','2026-06-14 18:49:10.695517'),('ea1f70c42e1942938e90195855b7fa51','O2YOF5OESwGVEhzXtRHX','amdeschk@hotmail.com','Ana Maria Deschk','Pago','Liberada','2026-06-25 10:48:33.218174'),('ec5bf07644f248b691bb55b5a36008c0','ANV8xnzLLo1MOTc6VlNK','caroline.kretzmann01@gmail.com','Caroline Kaufmann','Aguardando','Carrinho','2026-06-15 14:12:52.781289'),('ecdc4d5aa28046c593446517eb572706','jC7jvJmo4ZEwzVv8JbJH','leticia.schwaderer@gmail.com','Leticia Hoss Schwaderer','Pago','Erro Checkout','2026-06-15 14:30:30.996909'),('f5b94e5d0ac340328d24df437eb6f0eb','pwgc24NSEoiVL5Kwoe9F','profegeo3005@gmail.com','Geovanna Alberti','Aguardando','Carrinho','2026-06-25 10:48:45.620189'),('fba62f0852b845eab704bdaf6f6cc4c9','o21HPjBnVHqIaiPVQYWe','ranchil.pati@hitmail.com','Patrícia Cristiane de Almeida Ranchil','Aguardando','Carrinho','2026-06-15 14:12:42.129784'),('fd7c8cdd30664ac9a8fb92f7a15be585','xmKmkFvs5P1LVYXqcRMt','molagra_karoline@hotmail.con','Môlagra Goes','Aguardando','Carrinho','2026-06-15 14:12:35.843695'),('ffe9d5fa7f604c54bfd0629eb98b4c75','T7uIX1kyTqs8F5gu4e1o','silvana.yoga@hotmail.com','Silvana de Almeida Rodrigues','Aguardando','Carrinho','2026-06-15 14:12:46.342167');
/*!40000 ALTER TABLE `tb_enviolote_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'abrechozeira01'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-28 13:19:38
